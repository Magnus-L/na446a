"""Practice lab: how to work with a lab and its checker (made-up bakery data).

Put this folder inside your course folder (na446a-starter), open na446a-starter
in VS Code, and run one cell at a time (click "Run Cell" above each # %% line).
Fill in the two TODOs. After each step: save (Cmd+S / Ctrl+S), then run
check_practice.py with the play button. The checker reads the SAVED file.

Takes about 5 minutes. The last cell prints "Lab done".
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
# After a change: run this cell again, then the step that uses it.
DATA_FILE = "bakery.csv"       # buns sold per weekday, four weeks (made up)
# ---------------------------------------------------------------------

# %% Step 0: find the project folders from where this file is
from pathlib import Path
try:
    import pandas as pd
except ModuleNotFoundError:            # VS Code is using another Python, not the course's .venv
    raise SystemExit("pandas not found: VS Code is not using the course Python. Put this lab "
                     "folder inside na446a-starter, open na446a-starter in VS Code (File > Open "
                     "Folder), choose Python: Select Interpreter > .venv, then Restart. "
                     "See 'Common problems in class' on the Setup page.")

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE   # the lab folder
RAW = ROOT / "data" / "raw"              # read, never overwrite

# %% Step 1: load the data (done for you)
sales = pd.read_csv(RAW / DATA_FILE)
print(sales.shape)                       # expect (20, 3)

# %% Step 2: how many buns in all?
# TODO 2: make `total` = the sum of the column "buns"
total = ...
print(total)

# %% Step 3: which weekday sells most?
# TODO 3: make `by_day` = the mean of "buns" for each weekday (groupby)
by_day = ...
print(by_day)

# %%
print("Lab done")
