"""Self-check for the practice lab: which of your steps are right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_practice.py

It runs your SAVED practice_lab.py cell by cell (a cell that fails is reported
and skipped, so one error does not hide the rest), then checks each step.
It never changes your script. Unsaved changes are invisible to it: save first.
Last line printed: "N of 3 steps right." (all right: "3 of 3 steps right.")
"""
import sys
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent


def run_cells(script: Path) -> dict:
    """Run a # %% script cell by cell in one namespace, as VS Code does."""
    ns = {"__file__": str(script), "__name__": "__lab__"}
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:        # a new cell starts here
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    for i, cell in enumerate(cells):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
    return ns


def main() -> None:
    script = HERE / (sys.argv[1] if len(sys.argv) > 1 else "practice_lab.py")
    print(f"Checking {script.name} ...\n")
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()) as quiet:  # hide the lab's prints
        ns = run_cells(script)
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    truth = pd.read_csv(HERE / "data" / "raw" / "bakery.csv")   # the right answers
    results = []

    def step(name, test, hint):
        """Run one check; print OK or a friendly hint, never crash."""
        try:
            passed = bool(test())
        except Exception:                               # missing variable etc.
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    step("Step 1  data loaded",
         lambda: ns["sales"].shape == truth.shape,
         "run Step 0 and Step 1 as they are; sales should have 20 rows and 3 columns.")
    step("Step 2  total buns",
         lambda: ns["total"] == truth["buns"].sum(),
         'total = sales["buns"].sum()')
    step("Step 3  mean buns by weekday",
         lambda: (ns["by_day"].round(2)
                  .equals(truth.groupby("weekday")["buns"].mean().round(2))),
         'one value per weekday: sales.groupby("weekday")["buns"].mean()')
    print(f"\n{sum(results)} of {len(results)} steps right.")


if __name__ == "__main__":
    main()
