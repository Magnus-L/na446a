"""Self-check for the Session 2 lab: which of your steps are right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_s2.py                  checks s2_lab.py
    uv run check_s2.py my_copy.py       checks another file

It runs your lab script cell by cell (a cell that fails is reported and
skipped, so one error does not hide the rest), then checks each step.
It never changes your script. Runtime: about 2 seconds.
Last line printed: "N of 9 steps right." (all right: "9 of 9 steps right.")
"""
import sys
import time
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent


def run_cells(script: Path) -> dict:
    """Run a # %% script cell by cell in one namespace, as VS Code does."""
    ns = {"__file__": str(script), "__name__": "__lab__"}
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:        # a new cell starts here
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    for i, cell in enumerate(cells):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
    return ns


def main() -> None:
    script = HERE / (sys.argv[1] if len(sys.argv) > 1 else "s2_lab.py")
    print(f"Checking {script.name} ...\n")
    import io, contextlib
    import matplotlib
    matplotlib.use("Agg")                         # draw figures without opening windows
    with contextlib.redirect_stdout(io.StringIO()) as quiet:  # hide the lab's prints
        started = time.time()                          # files must be written by THIS run
        ns = run_cells(script)
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    cars = ns.get("cars")
    FIG = HERE / "output" / "figures"
    results = []

    def written(path):
        """True if the file exists and was written by this run of the lab script."""
        return path.stat().st_mtime >= started - 1

    def step(name, test, hint):
        """Run one check; print OK or a friendly hint, never crash."""
        try:
            passed = bool(test())
        except Exception:                               # missing variable etc.
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    step("Step 2  text column converted to numbers",
         lambda: pd.api.types.is_numeric_dtype(cars["horsepower"])
         and cars["horsepower"].isna().sum() == 4,
         'cars["horsepower"] should be a number type (float64) with 4 missing values.')
    step("Step 3  sentinel 999 turned into missing",
         lambda: ns["n_codes"] == 3 and cars["mpg"].isna().sum() == 3
         and cars["mpg"].max() < 100,
         "count the 999s first (n_codes should be 3), then use .mask() so mpg has 3 missing.")
    step("Step 4  kpl, region and high_mpg created",
         lambda: abs(cars["kpl"].mean() - 23.4459 * 0.425144) < 0.01
         and set(cars.loc[cars["origin"] == 3, "region"]) == {"Japan"}
         and set(cars.loc[cars["origin"] == 2, "region"]) == {"Europe"}
         and str(cars["high_mpg"].dtype) == "Int8"
         and cars["high_mpg"].isna().sum() == 3 and cars["high_mpg"].sum() == 154,
         "check the kpl factor, the region labels (2 = Europe, 3 = Japan) and that "
         "high_mpg is Int8 with 3 <NA>.")
    step("Step 5  `fast`: mpg above 40, highest first",
         lambda: len(ns["fast"]) == 8
         and ns["fast"]["mpg"].is_monotonic_decreasing
         and {"name", "region", "mpg"} <= set(ns["fast"].columns),
         "8 cars have mpg > 40; keep name, region and mpg; sort with ascending=False.")
    step("Step 6  `by_region` with agg",
         lambda: len(ns["by_region"]) == 3
         and ns["by_region"].loc["Europe", "n"] == 67
         and round(ns["by_region"].loc["Japan", "mean_mpg"], 1) == 30.5
         and round(ns["by_region"].loc["US", "mean_hp"], 1) == 118.9,
         "one row per region; n is the COUNT of mpg (Europe: 67), plus mean_mpg and mean_hp.")
    step("Step 7  region_mpg and gap with transform",
         lambda: cars["region_mpg"].notna().all() and len(cars) == 392
         and round(cars.loc[cars["region"] == "US", "region_mpg"].iloc[0], 1) == 20.0
         and round(cars["gap"].max(), 1) == 19.0,
         "use groupby(...)[...].transform('mean') so every one of the 392 cars gets its region's mean.")
    step("Step 8  saved to data/processed/auto_clean.parquet",
         lambda: written(HERE / "data" / "processed" / "auto_clean.parquet")
         and str(pd.read_parquet(HERE / "data" / "processed" / "auto_clean.parquet")
                 ["high_mpg"].dtype) == "Int8",
         'save with cars.to_parquet(PROC / "auto_clean.parquet") after Step 4.')
    step("Step 9  your two AI claims, each with a test",
         lambda: script.read_text(encoding="utf-8").count("# Test") >= 2
         and "Claim 1: ..." not in script.read_text(encoding="utf-8"),
         "write each claim and the one line of code that tests it (checked only for being filled in).")

    def figure_ok():
        """The figure: 3 grey bars, sorted, labelled axis, title, source, two files."""
        ax, fig = ns["ax"], ns["fig"]
        bars = [b.get_width() for b in ax.patches]
        r, g, b, _ = ax.patches[0].get_facecolor()
        return (len(bars) == 3 and bars == sorted(bars)          # sorted bars
                and abs(r - g) < 1e-6 and abs(g - b) < 1e-6      # grey
                and ax.get_xlabel().strip() != ""                # axis label
                and ax.get_title().strip() != ""                 # a title
                and any("source" in t.get_text().lower() for t in fig.texts)
                and written(FIG / "mpg_by_region.png")
                and written(FIG / "mpg_by_region.pdf"))
    step("Step 10 the figure",
         figure_ok,
         "3 sorted grey bars from by_region, an x label with the unit, a title, a "
         "source line (fig.text) and both files in output/figures/.")

    print(f"\n{sum(results)} of {len(results)} steps right.")


if __name__ == "__main__":
    main()
