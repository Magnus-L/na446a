"""Session 2 lab: inspect, fix, create, aggregate, and one figure.

Put this folder inside your course folder (na446a-starter), open it in VS Code,
and run one cell at a time (click "Run Cell" above each # %% line).
Fill in every TODO. Before you run a cell, write down what you expect.

Check your work at any time: open check_s2.py and run it (or, in the
terminal, `uv run check_s2.py`). It tells you which steps are right.

Takes about 40 minutes; finish at home if needed. The last cell prints "Lab done".
AI rule for today: lines that came from an AI get the comment  # AI:
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
DATA_FILE = "auto_messy.csv"   # the file in data/raw/
TEXT_COL = "horsepower"        # a number column that was read as text
CODE_COL = "mpg"               # a column that hides a sentinel code
SENTINEL = 999                 # the code that means "missing"
THRESHOLD = 25                 # mpg above this counts as high
# ---------------------------------------------------------------------

# %% Step 0: find the project folders from where this file is
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE   # the lab folder
RAW = ROOT / "data" / "raw"              # read, never overwrite
PROC = ROOT / "data" / "processed"       # data written by code
FIG = ROOT / "output" / "figures"        # figures written by code
PROC.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

# %% Step 1: load and check the types (done for you)
cars = pd.read_csv(RAW / DATA_FILE)
print(cars.shape)                        # expect (392, 9)
print(cars.dtypes)

# %% Step 2: convert the text column to numbers
# TODO 2a: make `hp` = TEXT_COL converted with pd.to_numeric(..., errors="coerce")
hp = ...
# TODO 2b: print the rows where `hp` is missing (name and TEXT_COL only)

# TODO 2c: put `hp` back into cars[TEXT_COL]; then print the number of
#   missing values in every column (cars.isna().sum())

# Your answer: how many values were not numbers, and what did they contain? ...

# %% Step 3: find and fix the sentinel code
# Predict first: what will describe() show as the max of CODE_COL? ...
print(cars[CODE_COL].describe())
# TODO 3a: count how many values equal SENTINEL (store the number in `n_codes`)
n_codes = ...
# TODO 3b: set those values to missing with .mask(); then print how many are missing

# %% Step 4: create variables
# TODO 4a: cars["kpl"] = mpg in km per litre (1 mpg = 0.425144 km/l)

# TODO 4b: cars["region"] = origin as text: 1 = "US", 2 = "Europe", 3 = "Japan"

# TODO 4c: cars["high_mpg"] = 1 if mpg > THRESHOLD, 0 if not, <NA> if mpg is missing
#   (type "Int8"; see Step 8 on the slides)

print(cars["high_mpg"].value_counts(dropna=False))

# %% Step 5: subset and sort
# TODO 5: `fast` = the name, region and mpg of cars with mpg above 40,
#   sorted from highest to lowest mpg
fast = ...
print(fast)
# Your answer: how many of these cars are from Japan? ...

# %% Step 6: one row per region with agg
# TODO 6: `by_region` = one row per region with the columns
#   n (count of mpg), mean_mpg (mean of mpg), mean_hp (mean of TEXT_COL)
by_region = ...
print(by_region.round(1))

# %% Step 7: a group value on every row with transform
# TODO 7a: cars["region_mpg"] = the mean mpg of the car's region (transform)

# TODO 7b: cars["gap"] = the car's mpg minus region_mpg

# Predict first: is the car with the highest mpg also the car furthest
# above its own region's mean? Then find out (hint: nlargest(3, "gap")).
# Your answer: ...

# %% Step 8: save the fixed data (types are kept in Parquet)
# TODO 8: save cars to PROC / "auto_clean.parquet"

# %% Step 9: ask an AI, then check it
# 1. Copy the OUTPUT of Steps 1 to 3 (not the data) into a chatbot.
#    Ask: "What problems in the data does this output show?"
# 2. Pick two of its claims. Test each with ONE line of code below.
# 3. Write: claim, your test, true or false.
# Claim 1: ...
# Test 1:
# Claim 2: ...
# Test 2:

# %% Step 10: one publication-ready figure (the last step)
# TODO 10: a horizontal bar chart of mean_mpg by region from `by_region`
#   (Steps 12 and 13 on the slides): sorted bars in grey, the x axis labelled
#   with its unit, a title that states the finding, a source line, and saved
#   as FIG / "mpg_by_region.png" and FIG / "mpg_by_region.pdf".
#   Keep the names `fig` and `ax`: the self-check looks at them.

# %% If you finish early (optional)
# The mean of a 0/1 dummy is a share. Make `share_high` = the share of
# high-mpg cars in each region. What does .mean() do with the <NA> cars,
# and how could you check that?

# %%
print("Lab done")
