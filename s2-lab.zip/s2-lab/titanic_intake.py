"""Exercise after Session 2: a full intake of the Titanic passenger list.

The task sheet (course site, Session 2) explains each task. Work in this file,
one cell at a time, and use the names given in each TODO: the self-check
looks for them. Check your work at any time with:
    uv run check_exercise_s2.py

About 90 minutes. The last cell prints "Exercise done".
AI rule: lines that came from an AI get the comment  # AI:
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
DATA_FILE = "titanic.csv"      # the file in data/raw/
AGE_ADULT = 18                 # age from which a passenger counts as adult
# ---------------------------------------------------------------------

# %% Setup
from pathlib import Path
import json
try:
    import pandas as pd
except ModuleNotFoundError:            # VS Code is using another Python, not the course's .venv
    raise SystemExit("pandas not found: VS Code is not using the course Python. Put this lab "
                     "folder inside na446a-starter, open na446a-starter in VS Code (File > Open "
                     "Folder), choose Python: Select Interpreter > .venv, then Restart. "
                     "See 'Common problems in class' on the Setup page.")

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
PROC.mkdir(parents=True, exist_ok=True)

# %% Task 1: load and name (5 min)
# TODO: load the file into `df`; make every column name lower case; print the shape
df = ...

# %% Task 2: types (10 min)
# TODO: print the dtypes. Convert survived, pclass, sibsp and parch to "Int8".
# Your answer: which columns are text (str)? ...

# %% Task 3: missing values (10 min)
# TODO: `miss` = one row per variable, columns n (count) and pct (percent,
#   1 decimal), sorted from most to least missing
miss = ...

# %% Task 4: ranges and plausibility; flag, do not drop (15 min)
# TODO: `flags` = a DataFrame of True/False columns, one per rule, True where a
#   value that is NOT missing breaks the rule:
#   survived in {0, 1}; pclass in {1, 2, 3}; sex in {"male", "female"};
#   embarked in {"C", "Q", "S"}; age between 0 and 100; fare >= 0
flags = ...
# TODO: `n_zero_fare` = number of passengers with a fare of exactly 0
n_zero_fare = ...
# Your answer: is a fare of 0 a sentinel code for "missing", or a real value?
# What in the data supports your view? What do you do with it? ...

# %% Task 5: categories (10 min)
# TODO: value counts of sex and embarked, missing values included
# TODO: `ct` = crosstab of pclass (rows) by sex (columns), with totals (margins)
# TODO: `ct_row` = the same in row percent (1 decimal)
ct = ...
ct_row = ...

# %% Task 6: create variables (15 min)
# TODO: df["child"] = 1 if age < AGE_ADULT, 0 if not, <NA> if age is missing (Int8)
# TODO: df["family_size"] = sibsp + parch + 1

# %% Task 7: aggregate (15 min)
# TODO: `by_class_sex` = one row per (pclass, sex) with the columns
#   n (number of passengers), survival (mean of survived), mean_age
by_class_sex = ...
# TODO: df["class_fare"] = the mean fare of the passenger's class (transform)
# TODO: df["fare_rel"] = fare / class_fare
# Your answer: how many rows do by_class_sex and df have, and why? ...

# %% Task 8: save (5 min)
# TODO: save df to PROC / "titanic_clean.parquet"
# TODO: save a codebook (dict: variable -> one-line label) to
#   PROC / "titanic_codebook.json" with json.dump

# %% If you finish early (optional, 15 min)
# Many passengers share a ticket number. Do passengers on the same ticket
# pay the same fare? If so, what does `fare` measure, and how would you get
# a fare per person? (hint: groupby("ticket") with transform("size"))

# %%
print("Exercise done")
