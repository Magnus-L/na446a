"""Self-check for the Titanic intake exercise: which of your tasks are right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_exercise_s2.py                  checks titanic_intake.py
    uv run check_exercise_s2.py my_copy.py       checks another file

It runs your script cell by cell (a cell that fails is reported and
skipped), then checks each task. It never changes your script.
Runtime: about 2 seconds. Last line printed: "N of 8 tasks right."
"""
import contextlib
import io
import json
import sys
import time
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent


def run_cells(script: Path) -> dict:
    """Run a # %% script cell by cell in one namespace, as VS Code does."""
    ns = {"__file__": str(script), "__name__": "__exercise__"}
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:        # a new cell starts here
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    for i, cell in enumerate(cells):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
    return ns


def main() -> None:
    script = HERE / (sys.argv[1] if len(sys.argv) > 1 else "titanic_intake.py")
    print(f"Checking {script.name} ...\n")
    with contextlib.redirect_stdout(io.StringIO()) as quiet:   # hide your prints
        started = time.time()                          # files must be written by THIS run
        ns = run_cells(script)
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    df = ns.get("df")
    proc = HERE / "data" / "processed"
    results = []

    def task(name, test, hint):
        """Run one check; print OK or a friendly hint, never crash."""
        try:
            passed = bool(test())
        except Exception:
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    task("Task 1  loaded, names in lower case",
         lambda: len(df) == 891 and all(c == c.lower() for c in df.columns)
         and {"survived", "pclass", "age", "fare"} <= set(df.columns),
         "df should have 891 rows and lower-case names (df.columns.str.lower()).")
    task("Task 2  counts and codes as Int8",
         lambda: all(str(df[c].dtype) == "Int8" for c in ["survived", "pclass", "sibsp", "parch"]),
         'convert survived, pclass, sibsp and parch with .astype("Int8").')
    task("Task 3  missing-value table `miss`",
         lambda: ns["miss"].index[0] == "cabin" and int(ns["miss"].loc["cabin", "n"]) == 687
         and int(ns["miss"].loc["age", "n"]) == 177
         and round(float(ns["miss"].loc["age", "pct"]), 1) == 19.9,
         "columns n and pct, sorted with the most missing first (cabin 687, age 177 = 19.9%).")
    task("Task 4  plausibility flags and zero fares",
         lambda: ns["flags"].shape == (891, 6) and int(ns["flags"].sum().sum()) == 0
         and ns["n_zero_fare"] == 15,
         "six True/False columns, True only where a PRESENT value breaks its rule "
         "(none do); 15 passengers have fare 0.")
    task("Task 5  crosstab of pclass by sex",
         lambda: int(ns["ct"].iloc[-1, -1]) == 891 and int(ns["ct"].loc[3, "male"]) == 347
         and round(float(ns["ct_row"].loc[3, "male"]), 1) == 70.7,
         "pd.crosstab(df['pclass'], df['sex'], margins=True); row percent with normalize='index'.")
    task("Task 6  child (with <NA>) and family_size",
         lambda: str(df["child"].dtype) == "Int8" and df["child"].isna().sum() == 177
         and int(df["child"].sum()) == 113 and int(df["family_size"].max()) == 11,
         "child must stay <NA> where age is missing (see Step 8 on the slides); "
         "family_size = sibsp + parch + 1.")
    task("Task 7  by_class_sex (agg) and fare_rel (transform)",
         lambda: len(ns["by_class_sex"]) == 6
         and round(float(ns["by_class_sex"].loc[(1, "female"), "survival"]), 3) == 0.968
         and int(ns["by_class_sex"].loc[(3, "male"), "n"]) == 347
         and len(df) == 891 and abs(df.groupby("pclass")["fare_rel"].mean() - 1).max() < 1e-9,
         "agg by ['pclass', 'sex'] gives 6 rows; class_fare needs transform so df keeps 891 rows.")
    task("Task 8  clean file and codebook saved",
         lambda: (proc / "titanic_clean.parquet").stat().st_mtime >= started - 1
         and (proc / "titanic_codebook.json").stat().st_mtime >= started - 1
         and len(pd.read_parquet(proc / "titanic_clean.parquet")) == 891
         and str(pd.read_parquet(proc / "titanic_clean.parquet")["child"].dtype) == "Int8"
         and len(json.loads((proc / "titanic_codebook.json").read_text(encoding="utf-8"))) >= 12,
         "save to data/processed/titanic_clean.parquet (after Task 6) and a codebook "
         "with a label for every variable.")

    print(f"\n{sum(results)} of {len(results)} tasks right.")


if __name__ == "__main__":
    main()
