"""Lab 1, step 3: fix an AI-written script.

A student asked an AI tool for "a script that compares fuel economy (mpg)
of American, European and Japanese cars in auto.csv". The script below is
what it gave. It runs without an error. One line gives a wrong answer.

Your task (course rules 3 and 4):
  1. Before running it, write down what you expect, using a case you
     already know: the concept check in today's lecture.
  2. Run it and compare. Where does the result disagree?
  3. Find the line that causes it, fix it, and mark your fix with a comment.
  4. Explain in one sentence why the script did not crash.

Hint: the concept check in the lecture gave mean mpg for each origin code.
"""
from pathlib import Path

import pandas as pd

RAW = Path(__file__).resolve().parent / "data" / "raw"
cars = pd.read_csv(RAW / "auto.csv")

# Give the origin codes readable names (line suggested by AI)
names = {1: "US", 2: "Japan", 3: "Europe"}
cars["region"] = cars["origin"].map(names)

# Mean mpg by region, highest first
mpg_by_region = (cars.groupby("region")["mpg"]
                     .mean()
                     .round(1)
                     .sort_values(ascending=False))
print(mpg_by_region)
print(f"Most fuel-efficient region: {mpg_by_region.index[0]}")
