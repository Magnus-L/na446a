"""Session 1 lab: load and inspect a dataset.

Put this folder inside your course folder (na446a-starter), open it in VS Code,
and run one cell at a time (click "Run Cell" above each # %% line).
It takes under a minute. The last cell prints "Lab done".
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
DATA_FILE = "auto.csv"          # the file in data/raw/ you want to load
VARIABLES = ["mpg", "weight"]   # the variables to summarise
# ---------------------------------------------------------------------

# %% Step 0: find the project folders from where this file is
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent   # the lab folder
RAW = ROOT / "data" / "raw"              # raw data: read, never overwrite

# %% Step 1: load the data and check its size
cars = pd.read_csv(RAW / DATA_FILE)
print(cars.shape)                        # expect (392, 9): rows, columns

# %% Step 2: look at the first rows
print(cars.head(3))

# %% Step 3: summary statistics for the chosen variables
print(cars[VARIABLES].describe().round(1))

# %% Step 4 (your turn): predict first, then run
# Which origin (1 = US, 2 = Europe, 3 = Japan) has the highest mean mpg?
# Write your prediction in this comment: ...
print(cars.groupby("origin")["mpg"].mean().round(1))

# %%
print("Lab done")
