******** START A LOG-FILE ******
set logtype t
set linesize 120
cap noisily log close
log using "f4_stata.log", replace

********* PREAMBLE ************
* DO-file name: f4_stata.do
* Created: 30 Sep 2026 (Magnus Lodefalk)
* The Stata equivalents of f4_script.py (Further topic F4, NA446A Part II):
* DiD by hand, two-way FE with reghdfe, an event study with explicit
* dummies, and Poisson with fixed effects with ppmlhdfe.
* Data: data/firm_panel.csv, made up by f4_make_data.py (true effect -0.10)
* Needs: reghdfe, ftools, ppmlhdfe (once: ssc install reghdfe, ssc install
*        ftools, ssc install ppmlhdfe)
* Run from this folder: do f4_stata.do (StataNow 19.5, 30 Sep 2026)
**********************

clear all
set more off
version 19

********* STEP 1: LOAD AND CHECK THE PANEL
import delimited using "data/firm_panel.csv", clear
isid firm year
xtset firm year
tab treat if year == 2015

********* STEP 2: DiD BY HAND, FROM FOUR MEANS
table treat post, statistic(mean ln_emp) nformat(%9.4f)

********* STEP 3: TWO-WAY FIXED EFFECTS, CLUSTERED BY FIRM
reghdfe ln_emp treat_post, absorb(firm year) vce(cluster firm)
* firm effects only (the concept check)
reghdfe ln_emp treat_post, absorb(firm) vce(cluster firm)

********* STEP 4: EVENT STUDY WITH EXPLICIT DUMMIES (2019 = reference)
* Explicit dummies, because with fixed effects Stata can ignore the base
* of an interaction like ib2019.year#c.treat and drop another year instead.
forvalues y = 2015/2024 {
    if `y' != 2019 {
        gen ev_`y' = treat * (year == `y')
    }
}
reghdfe ln_emp ev_*, absorb(firm year) vce(cluster firm)

********* STEP 6: POISSON WITH FIXED EFFECTS FOR HIRES
count if hires == 0
ppmlhdfe hires treat_post, absorb(firm year) vce(cluster firm)
di "per cent change in hires: " %5.1f 100*(exp(_b[treat_post]) - 1)

***** POSTSCRIPT
cap log close
exit
