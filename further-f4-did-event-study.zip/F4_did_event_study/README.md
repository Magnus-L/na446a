# F4 Difference-in-differences and event studies in Python

Optional self-study for NA446A Part II. Not examined.

**What:** the design the AI-Econ Lab's papers are built on, on a made-up firm panel whose true effect we know. The 2×2 difference-in-differences by hand from four group means; the same number as a two-way fixed-effects regression (`pf.feols` with firm and year effects, clustered by firm); an event study with leads and lags (`i(year, treat, ref=2019)`) and its figure, with the pre-trends visible; Poisson with fixed effects for a count outcome (`pf.fepois`), as the canaries paper does for job ads; and where to go next (HonestDiD, staggered adoption). All three estimators recover the true effect of −0.10, and the slides say so.

**After which session:** Session 3 (panels, `groupby`) and Session 4 (regressions); F1 first is recommended, since F4 uses the same `pf.feols(... | firm+year, vcov={"CRV1": ...})` line.

**Time:** about 60–75 minutes (slides 20, running and changing the scripts 40–55).

## Extra packages

In your course folder (`na446a-starter`), in the VS Code terminal:

```bash
uv add pyfixest          # about 20 small packages; the only addition
```

Tested on 30 Sep 2026 with pyfixest 0.60.0, pandas 3.0.6, matplotlib, Python 3.12, in a separate environment (the course `pyproject.toml` and the student starter were not changed).

## The data

`f4_make_data.py` builds `data/firm_panel.csv` offline: 500 firms × 2015–2024 (5,000 rows), 216 of them treated from 2020 (chosen at random, seed 20260930). Log employment is a constant + a firm effect (treated firms are 0.3 larger on average: a level difference DiD removes) + a year effect common to all firms (so parallel trends hold by construction) + the true effect −0.10 for treated firms from 2020 + pure noise. Hires is a Poisson count with the same structure and the same −0.10 on the log scale (−9.5 per cent). The file ships in the folder, so students need not run the generator; rerunning it gives the identical file. Change `TRUE_EFFECT` or `START_YEAR` at its top to experiment (and `TRUE_EFFECT` in `f4_script.py` to match).

## Files

| File | What |
|---|---|
| `F4.pdf` (source `F4.tex`) | 13 slides plus title: goals, six terms, the data, six steps with real output and the event-study figure, two concept checks, where to go next, summary |
| `f4_make_data.py` | Makes the synthetic panel (about 1 second). Last printed line: `f4_make_data.py done: data/firm_panel.csv written` |
| `f4_script.py` | Reproduces every number on the slides and the figure, one `# %%` cell per step, written like a Stata do-file: one step at a time, a comment and the Stata line above each block |
| `f4_stata.do`, `f4_stata.log` | The Stata equivalents (`reghdfe`, explicit event-study dummies, `ppmlhdfe`), run in StataNow 19.5: the same estimates and standard errors to four decimals |
| `data/firm_panel.csv` | The made-up panel |
| `figures/f4_event_study.pdf` | The event-study figure, written by the script |
| `build/f4_output.txt`, `build/f4_make_data_output.txt` | The printouts of 30 Sep 2026, for comparison |

## Run

```bash
uv run further/F4_did_event_study/f4_script.py
```

Runtime about 3–4 seconds (the very first pyfixest run takes longer while it compiles). Last printed line: `f4_script.py done: true effect -0.10 recovered, figure in figures/`. Or run it cell by cell (`# %%`) in VS Code, next to the slides.

## Results (30 Sep 2026)

| Estimator | Estimate (SE) | True |
|---|---|---|
| DiD by hand | −0.1103 | −0.10 |
| Two-way FE, clustered by firm | −0.1103 (0.0111); 95% CI −0.132 to −0.089 | −0.10 |
| Event study: mean of leads / lags | −0.0004 / −0.1106 | 0 / −0.10 |
| Poisson FE on hires | −0.0990 (0.0182), i.e. −9.4% | −9.5% |
| Firm effects only (the concept check, wrong on purpose) | −0.0306 (0.0081) | −0.10 |

## Checked against Stata

`reghdfe`, `ftools` and `ppmlhdfe` were already installed in StataNow 19.5; on a new machine, `ssc install` each once. The event study in Stata uses explicit dummies `ev_2015`…`ev_2024` (no 2019) made in a `forvalues` loop, because with fixed effects Stata can ignore the base level of an interaction such as `ib2019.year#c.treat` and drop another year instead.

## References on the last slide (checked 30 Sep 2026)

- Rambachan, A. and J. Roth (2023). A more credible approach to parallel trends. *Review of Economic Studies* 90(5): 2555–2591. Package: github.com/asheshrambachan/HonestDiD
- Callaway, B. and P. H. C. Sant'Anna (2021). Difference-in-differences with multiple time periods. *Journal of Econometrics* 225(2): 200–230. Open version: arxiv.org/abs/1803.09015; R package: github.com/bcallaway11/did

Build the slides: `python3 ../scripts/check_deck.py F4.tex` (Tectonic; zero overfull boxes on 30 Sep 2026).
