"""Make the synthetic firm panel for Further topic F4 (run once, offline).

########## PREAMBLE ##########
File:     f4_make_data.py
Created:  30 Sep 2026 (Magnus Lodefalk, NA446A Part II, further topic F4)
What:     builds a made-up panel of firms x years that looks like register
          data (one row per firm and year), with a treatment that starts in
          2020 for about half the firms and a TRUE effect that we choose.
          Everything else is pure random noise.
Why:      with made-up data we know the right answer, so we can check that
          the difference-in-differences estimators in f4_script.py find it.
Output:   data/firm_panel.csv  (5,000 rows: 500 firms x 10 years)
Run:      uv run f4_make_data.py   (about 1 second; no network needed)
Last printed line: "f4_make_data.py done: data/firm_panel.csv written"
The seed is fixed, so every run gives exactly the same file.
##############################
"""

# Load the packages we need (Stata: nothing to load)
from pathlib import Path

import numpy as np
import pandas as pd

# ---- CHANGE HERE (only these lines) --------------------------------------
SEED = 20260930       # the random seed (Stata: set seed 20260930)
N_FIRMS = 500         # number of firms
FIRST_YEAR = 2015     # first year in the panel
LAST_YEAR = 2024      # last year in the panel
START_YEAR = 2020     # the treatment starts this year, for treated firms only
TRUE_EFFECT = -0.10   # the true effect: -0.10 log points (about -10 per cent)
# ---------------------------------------------------------------------------

# The folder this file sits in, so the data land next to it
HERE = Path(__file__).resolve().parent

# A random number generator with a fixed seed (Stata: set seed)
rng = np.random.default_rng(SEED)


########## STEP 1: ONE ROW PER FIRM ##########

# Stata: set obs 500, then gen firm = _n
firms = pd.DataFrame()
firms["firm"] = np.arange(1, N_FIRMS + 1)

# About half the firms are treated, chosen at random
# Stata: gen treat = runiform() < 0.5
firms["treat"] = (rng.uniform(size=N_FIRMS) < 0.5).astype(int)

# A permanent firm effect (some firms are simply bigger than others).
# Treated firms are 0.3 larger on average: the groups differ in LEVEL,
# which difference-in-differences is built to remove.
# Stata: gen firm_effect = rnormal(0, 0.5) + 0.3*treat
firms["firm_effect"] = rng.normal(0, 0.5, size=N_FIRMS) + 0.3 * firms["treat"]

print("Step 1: firms and how many are treated")
print(firms["treat"].value_counts().sort_index())


########## STEP 2: ONE ROW PER YEAR ##########

# A common year effect: a trend of 0.02 a year plus a small shock each year.
# It is the same for treated and control firms, so the two groups have
# parallel trends by construction.
years = pd.DataFrame()
years["year"] = np.arange(FIRST_YEAR, LAST_YEAR + 1)
years["year_effect"] = (0.02 * (years["year"] - FIRST_YEAR)
                        + rng.normal(0, 0.03, size=len(years)))

print("\nStep 2: the years")
print(years["year"].tolist())


########## STEP 3: EVERY FIRM IN EVERY YEAR ##########

# A cross join: each of the 500 firms gets all 10 years (5,000 rows).
# Stata: expand 10, then bysort firm: gen year = 2014 + _n
panel = firms.merge(years, how="cross")

print("\nStep 3: rows in the panel:", len(panel))


########## STEP 4: THE TREATMENT DUMMY ##########

# post = 1 from 2020 on, for every firm (Stata: gen post = year >= 2020)
panel["post"] = (panel["year"] >= START_YEAR).astype(int)

# treat_post = 1 only for treated firms from 2020 on: the DiD dummy
# Stata: gen treat_post = treat*post
panel["treat_post"] = panel["treat"] * panel["post"]


########## STEP 5: THE OUTCOMES ##########

# Log employment = constant + firm effect + year effect
#                  + TRUE_EFFECT for treated firms after 2020
#                  + pure noise (sd 0.2), drawn fresh for every row
# Stata: gen ln_emp = 3 + firm_effect + year_effect + (-0.10)*treat_post + rnormal(0, 0.2)
noise = rng.normal(0, 0.2, size=len(panel))
panel["ln_emp"] = (3.0 + panel["firm_effect"]
                   + panel["year_effect"]
                   + TRUE_EFFECT * panel["treat_post"]
                   + noise)

# Hires: a COUNT (0, 1, 2, ...), drawn from a Poisson distribution whose
# mean has the same structure. The effect is again -0.10 on the log scale,
# so treated firms hire exp(-0.10) - 1 = -9.5 per cent fewer after 2020.
# Stata: gen hires = rpoisson(exp(2 + firm_effect + year_effect + (-0.10)*treat_post))
mean_hires = np.exp(2.0 + panel["firm_effect"] + panel["year_effect"]
                    + TRUE_EFFECT * panel["treat_post"])
panel["hires"] = rng.poisson(mean_hires)


########## STEP 6: KEEP WHAT AN ANALYST WOULD SEE, AND SAVE ##########

# Drop the true firm and year effects: in real data nobody observes them
# Stata: keep firm year treat post treat_post ln_emp hires
panel = panel[["firm", "year", "treat", "post", "treat_post", "ln_emp", "hires"]]

# Round so the CSV is short and Stata reads exactly the same numbers
panel["ln_emp"] = panel["ln_emp"].round(6)

print("\nStep 6: the first rows")
print(panel.head(3))
print("\nSummary of the outcomes")
print(panel[["ln_emp", "hires"]].describe().round(2))

# Save as CSV for f4_script.py and for Stata (Stata: export delimited)
(HERE / "data").mkdir(exist_ok=True)
panel.to_csv(HERE / "data" / "firm_panel.csv", index=False)

print("\nf4_make_data.py done: data/firm_panel.csv written")
