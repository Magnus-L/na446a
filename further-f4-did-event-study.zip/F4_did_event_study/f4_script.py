"""Further topic F4: difference-in-differences and event studies in Python.

########## PREAMBLE ##########
File:     f4_script.py
Created:  30 Sep 2026 (Magnus Lodefalk, NA446A Part II, further topic F4)
Course:   optional self-study, not examined
What:     one step per slide of F4.pdf, top to bottom:
            1. load the firm panel and check its key
            2. the 2x2 difference-in-differences by hand, from four means
            3. the same number as a regression with firm and year fixed
               effects, clustered by firm (the lab's workhorse)
            4. an event study: one treated-control gap per year, 2019 = 0
            5. the event-study figure (figures/f4_event_study.pdf)
            6. Poisson with fixed effects for a count outcome (hires)
Data:     data/firm_panel.csv, MADE UP by f4_make_data.py. The true
          effect is -0.10 on both outcomes, so we can check the answer.
Packages: pandas, matplotlib and pyfixest (add it once: uv add pyfixest)
Stata:    the same steps are in f4_stata.do (log in f4_stata.log)
Run:      uv run f4_script.py      or cell by cell (# %%) in VS Code
Runtime:  about 5 seconds (the first run of pyfixest takes longer)
Last printed line: "f4_script.py done: true effect -0.10 recovered, figure in figures/"
##############################
"""

# %% Setup: packages, settings, folders
# Stata: clear all, set more off

from pathlib import Path

import matplotlib
matplotlib.use("Agg")            # save figures to files, do not open a window
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pyfixest as pf

# ---- CHANGE HERE (only these lines) --------------------------------------
TRUE_EFFECT = -0.10   # must match f4_make_data.py: the answer we should find
# ---------------------------------------------------------------------------

# The folder this file sits in (for cell-by-cell runs, the working folder)
try:
    HERE = Path(__file__).resolve().parent
except NameError:
    HERE = Path.cwd()
(HERE / "figures").mkdir(exist_ok=True)


# %% Step 1: load the panel and check its key
# Stata: import delimited using "data/firm_panel.csv", clear

df = pd.read_csv(HERE / "data" / "firm_panel.csv")

print("=== Step 1: the panel ===")
print("rows and columns:", df.shape)
print("firms:", df["firm"].nunique(), "| years:", df["year"].min(), "to", df["year"].max())

# One row per firm and year, or stop (Stata: isid firm year)
print("duplicate firm-years:", df.duplicated(["firm", "year"]).sum())

# Treated and control firms (Stata: tab treat if year == 2015)
print(df.loc[df["year"] == 2015, "treat"].value_counts().sort_index())


# %% Step 2: the 2x2 difference-in-differences by hand
# Four means: treated and control firms, before and after 2020.
# Stata: table treat post, statistic(mean ln_emp)

means = df.groupby(["treat", "post"])["ln_emp"].mean()

print("\n=== Step 2: DiD by hand ===")
print(means.round(4))

# Change over time within each group
change_treated = means.loc[(1, 1)] - means.loc[(1, 0)]
change_control = means.loc[(0, 1)] - means.loc[(0, 0)]

# The difference in the differences: the treated group's change minus the
# change the control group shows we should have expected anyway
did_by_hand = change_treated - change_control

print("change, treated:", round(change_treated, 4))
print("change, control:", round(change_control, 4))
print("DiD by hand:    ", round(did_by_hand, 4))


# %% Step 3: the same number as a two-way fixed-effects regression
# "| firm+year" absorbs a dummy for every firm and every year. The treat_post
# coefficient is the DiD. Standard errors are clustered by firm, because a
# firm's errors are related across years and the treatment varies by firm.
# (Write "firm+year" without spaces: pyfixest 0.60 mislabels the fixed
# effects in etable otherwise.)
# Stata: reghdfe ln_emp treat_post, absorb(firm year) vce(cluster firm)

twfe = pf.feols("ln_emp ~ treat_post | firm+year", data=df,
                vcov={"CRV1": "firm"})

print("\n=== Step 3: two-way fixed effects ===")
print(twfe.tidy().round(4))

# Does the 95% confidence interval contain the true effect?
ci_low = twfe.confint().loc["treat_post", "2.5%"]
ci_high = twfe.confint().loc["treat_post", "97.5%"]
inside = (ci_low < TRUE_EFFECT) and (TRUE_EFFECT < ci_high)
print("95% CI:", round(ci_low, 4), "to", round(ci_high, 4))
print("true effect", TRUE_EFFECT, "inside the 95% CI:", inside)

# The same regression with only firm effects, for the concept check:
# without year effects, the common trend is mixed into the estimate.
# Stata: reghdfe ln_emp treat_post, absorb(firm) vce(cluster firm)
firm_only = pf.feols("ln_emp ~ treat_post | firm", data=df,
                     vcov={"CRV1": "firm"})
print("firm effects only:", round(firm_only.coef()["treat_post"], 4))


# %% Step 4: the event study, one gap per year
# i(year, treat, ref=2019) makes a dummy for treat x each year except 2019.
# Each coefficient is the treated-control gap in that year MINUS the gap in
# 2019. Before 2020 they should be near zero (no pre-trend); from 2020 on,
# near the true effect.
# Stata: make the dummies ev_2015 ... ev_2024 (no ev_2019) in a loop, then
#        reghdfe ln_emp ev_*, absorb(firm year) vce(cluster firm)

event = pf.feols("ln_emp ~ i(year, treat, ref=2019) | firm+year",
                 data=df, vcov={"CRV1": "firm"})

# Put the results in a table: estimate, standard error, 95% interval
es_table = event.tidy()

# The row names look like "year::2015:treat": characters 6 to 9 are the year
es_table["year"] = es_table.index.str.slice(6, 10).astype(int)

print("\n=== Step 4: event study ===")
print(es_table[["year", "Estimate", "Std. Error", "2.5%", "97.5%"]].round(4))

# Average of the leads (before 2020) and of the lags (2020 on)
leads = es_table.loc[es_table["year"] < 2020, "Estimate"]
lags = es_table.loc[es_table["year"] >= 2020, "Estimate"]
print("mean of the leads (pre-2020):", round(leads.mean(), 4))
print("mean of the lags (2020 on):  ", round(lags.mean(), 4))


# %% Step 5: the event-study figure
# Add the reference year as a row with estimate 0 (it is 0 by construction)
ref_row = pd.DataFrame({"year": [2019], "Estimate": [0.0],
                        "2.5%": [0.0], "97.5%": [0.0]})
plot_data = pd.concat([es_table, ref_row]).sort_values("year")

# Distance from each estimate to the ends of its interval (for error bars)
below = plot_data["Estimate"] - plot_data["2.5%"]
above = plot_data["97.5%"] - plot_data["Estimate"]

fig, ax = plt.subplots(figsize=(7, 3.2))
ax.axhline(0, color="black", linewidth=0.8)                  # no effect
ax.axvline(2019.5, color="grey", linestyle=":")      # treatment starts
ax.hlines(TRUE_EFFECT, 2019.5, 2024.5, color="grey",
          linestyle="--", label="true effect (-0.10)")
ax.errorbar(plot_data["year"], plot_data["Estimate"], yerr=[below, above],
            fmt="o", color="black", capsize=3, label="estimate, 95% CI")
ax.set_xticks(plot_data["year"])
ax.set_ylabel("gap vs 2019 (log points)")
ax.legend(frameon=False, loc="lower left")
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
fig.tight_layout()
fig.savefig(HERE / "figures" / "f4_event_study.pdf")
plt.close(fig)

print("\n=== Step 5: figure saved to figures/f4_event_study.pdf ===")


# %% Step 6: Poisson with fixed effects for a count outcome (hires)
# Hires is a count with zeros, and log(0) is not defined, so a regression of
# log hires would have to drop those rows. Poisson models the count itself;
# the coefficient is still read on the log scale. This is what the canaries
# paper does for job ads.
# Stata: ppmlhdfe hires treat_post, absorb(firm year) vce(cluster firm)

print("\n=== Step 6: Poisson with fixed effects ===")
print("rows with zero hires:", (df["hires"] == 0).sum())

poisson = pf.fepois("hires ~ treat_post | firm+year", data=df,
                    vcov={"CRV1": "firm"})
print(poisson.tidy().round(4))

# From log points to per cent: exp(b) - 1
b_poisson = poisson.coef()["treat_post"]
pct = 100 * (np.exp(b_poisson) - 1)
print("per cent change in hires:", round(pct, 1))
print("true per cent change:    ", round(100 * (np.exp(TRUE_EFFECT) - 1), 1))


# %% Step 7: one table with the three models
# Stata: esttab (SSC) or outreg2 after each regression

# signif_code: stars at 1, 5 and 10 per cent, as in Stata's usual tables;
# coef_fmt: coefficient with stars, then its standard error in brackets
models = [twfe, firm_only, poisson]
table = pf.etable(models, type="df",
    signif_code=[0.01, 0.05, 0.1],
    coef_fmt="b:.3f* (se:.3f)")

print("\n=== Step 7: the table ===")
print(table.to_string())

print("\nf4_script.py done: true effect -0.10 recovered, figure in figures/")
