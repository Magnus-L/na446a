"""Solution to s2_lab.py (Session 2 lab). Released after the session.

Same cells and variable names as the starter, so check_s2.py can check it:
    uv run check_s2.py worked/s2_lab_worked.py
RUNTIME  about 1 second. Last line printed: "Lab done"
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
DATA_FILE = "auto_messy.csv"   # the file in data/raw/
TEXT_COL = "horsepower"        # a number column that was read as text
CODE_COL = "mpg"               # a column that hides a sentinel code
SENTINEL = 999                 # the code that means "missing"
THRESHOLD = 25                 # mpg above this counts as high
# ---------------------------------------------------------------------

# %% Step 0: find the project folders from where this file is
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]   # the lab folder (one up from worked/)
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
FIG = ROOT / "output" / "figures"
PROC.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

# %% Step 1: load and check the types (done for you)  [slides: Step 1]
cars = pd.read_csv(RAW / DATA_FILE)
print(cars.shape)                        # (392, 9)
print(cars.dtypes)                       # horsepower is str: a problem

# %% Step 2: convert the text column to numbers  [slides: Steps 2-3]
hp = pd.to_numeric(cars[TEXT_COL], errors="coerce")   # "?" becomes NaN
print(cars.loc[hp.isna(), ["name", TEXT_COL]])        # look before you convert
cars[TEXT_COL] = hp
print(cars.isna().sum())                              # only horsepower: 4
# Answer: 4 values were not numbers; all four were "?" (unknown).

# %% Step 3: find and fix the sentinel code  [slides: Steps 4-6]
print(cars[CODE_COL].describe())                      # max 999: impossible
n_codes = int((cars[CODE_COL] == SENTINEL).sum())     # 3
cars[CODE_COL] = cars[CODE_COL].mask(cars[CODE_COL] == SENTINEL)
print(n_codes, cars[CODE_COL].isna().sum())           # 3 in, 3 missing out

# %% Step 4: create variables  [slides: Steps 7-8]
cars["kpl"] = cars["mpg"] * 0.425144                  # km per litre
cars["region"] = cars["origin"].map({1: "US", 2: "Europe", 3: "Japan"})
ok = cars["mpg"].notna()
high = (cars["mpg"] > THRESHOLD).astype("Int8")       # NaN > 25 is False ...
cars["high_mpg"] = high.where(ok)                     # ... so put <NA> back
print(cars["high_mpg"].value_counts(dropna=False))    # 0: 235, 1: 154, <NA>: 3

# %% Step 5: subset and sort  [slides: Step 9]
fast = (cars.loc[cars["mpg"] > 40, ["name", "region", "mpg"]]
            .sort_values("mpg", ascending=False))
print(fast)
# Answer: 8 cars; 3 are from Japan (mazda glc, honda civic 1500 gl, datsun 210).

# %% Step 6: one row per region with agg  [slides: Step 10]
by_region = cars.groupby("region").agg(
    n=("mpg", "count"),                               # non-missing mpg only
    mean_mpg=("mpg", "mean"),
    mean_hp=(TEXT_COL, "mean"),
)
print(by_region.round(1))                             # Europe 67, Japan 79, US 243

# %% Step 7: a group value on every row with transform  [slides: Step 11]
cars["region_mpg"] = cars.groupby("region")["mpg"].transform("mean")
cars["gap"] = cars["mpg"] - cars["region_mpg"]
print(cars.nlargest(3, "gap")[["name", "region", "mpg", "gap"]].round(1))
# Answer: no. The mazda glc has the highest mpg (46.6, +16.1 above Japan's
# mean), but the plymouth champ (US, 39.0 mpg) is furthest above its own
# region's mean: +19.0, because the US mean is only 20.0. A gap depends on
# the group you compare with.

# %% Step 8: save the fixed data (types are kept in Parquet)  [not on the slides]
cars.to_parquet(PROC / "auto_clean.parquet")

# %% Step 9: ask an AI, then check it  [slides: Today's lab]
# Typical claims and one-line tests (the chatbot's wording will differ):
# Claim: "horsepower is text because it contains non-numeric values"
# Test:  cars_raw = pd.read_csv(RAW / DATA_FILE); cars_raw["horsepower"].str.isdigit().value_counts()
#        -> True 388, False 4: true.
# Claim: "mpg has no missing values"
# Test:  (pd.read_csv(RAW / DATA_FILE)["mpg"] == 999).sum()  -> 3: false, they hide as 999.
# Claim: "the mean mpg of 30.9 looks plausible"   -> false: the median is 23.0, the max 999.

# %% Step 10: one publication-ready figure (the last step)  [slides: Steps 12-13]
m = by_region["mean_mpg"].sort_values()               # sorted: the eye reads a ranking
fig, ax = plt.subplots(figsize=(6, 2.4))
ax.barh(m.index, m, color="0.35")                     # one grey: fine in black and white
ax.set_xlabel("Miles per US gallon (mean)")           # label with unit
ax.spines[["top", "right"]].set_visible(False)        # no box: less ink, same information
ax.set_title("Japan's cars go furthest")              # the title states the finding
fig.text(0, -0.15, "Source: auto.csv, 389 cars with known mpg, model years 1970-82")
for ext in ["png", "pdf"]:
    fig.savefig(FIG / f"mpg_by_region.{ext}", bbox_inches="tight")
plt.close(fig)                                        # free the memory; the files stay

# %% If you finish early (optional)
share_high = cars.groupby("region")["high_mpg"].mean()
print(share_high.round(3))
# .mean() skips <NA>: the share is over the cars with known mpg. Check:
# cars.groupby("region")["high_mpg"].sum() / cars.groupby("region")["high_mpg"].count()

# %%
print("Lab done")
