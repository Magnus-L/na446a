"""Solution: Titanic intake (exercise after Session 2). Released three days after the session.

PURPOSE  Apply the intake checklist to the Titanic passenger list: names,
         types, missing values, ranges, categories; create, aggregate, save.
INPUTS   data/raw/titanic.csv (891 passengers, 12 variables; the public
         Data Science Dojo copy used in HT25)
OUTPUTS  data/processed/titanic_clean.parquet, data/processed/titanic_codebook.json
RUNTIME  about 1 second. Last line printed: "Exercise done"

Rewritten 29 Sep 2026 from the HT25 solution. Changes: no download
fallback (the file ships with the lab); no blind sentinel replacement on
data that has none (the zero fares are examined instead); the missing-value
table holds whole-number counts; the mangled cell marker is gone; plots are
left to a later session; names match the starter and the self-check.
Check it with:  uv run check_exercise_s2.py worked/titanic_intake_worked.py
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
DATA_FILE = "titanic.csv"      # the file in data/raw/
AGE_ADULT = 18                 # age from which a passenger counts as adult
# ---------------------------------------------------------------------

# %% Setup
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]   # the lab folder (one up from worked/)
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"
PROC.mkdir(parents=True, exist_ok=True)

# %% Task 1: load and name
df = pd.read_csv(RAW / DATA_FILE)
df.columns = df.columns.str.lower()          # PassengerId -> passengerid
print(df.shape)                              # (891, 12)

# %% Task 2: types
print(df.dtypes)
# Every column was read with a sensible type: numbers as int64/float64,
# text (name, sex, ticket, cabin, embarked) as str. The small counts and
# codes become nullable integers, which can also hold <NA> later.
for col in ["survived", "pclass", "sibsp", "parch"]:
    df[col] = df[col].astype("Int8")

# %% Task 3: missing values
miss = pd.DataFrame({
    "n": df.isna().sum(),                    # whole numbers, not 687.0
    "pct": (df.isna().mean() * 100).round(1),
}).sort_values("n", ascending=False)
print(miss.head(4))                          # cabin 687 (77.1), age 177 (19.9), embarked 2

# %% Task 4: ranges and plausibility (flag, do not drop)
# A rule is broken only where the value is present: missing is a separate issue.
flags = pd.DataFrame({
    "survived_bad": df["survived"].notna() & ~df["survived"].isin([0, 1]),
    "pclass_bad": df["pclass"].notna() & ~df["pclass"].isin([1, 2, 3]),
    "sex_bad": df["sex"].notna() & ~df["sex"].isin(["male", "female"]),
    "embarked_bad": df["embarked"].notna() & ~df["embarked"].isin(["C", "Q", "S"]),
    "age_bad": df["age"].notna() & ~df["age"].between(0, 100),
    "fare_bad": df["fare"].notna() & (df["fare"] < 0),
})
print(flags.sum())                           # all 0: no rule is broken
n_zero_fare = int((df["fare"] == 0).sum())
print(n_zero_fare)                           # 15
print(df.loc[df["fare"] == 0, ["pclass", "sex", "age", "ticket", "embarked"]])
# Sentinel or real? The data cannot settle it. For: all 15 are men who
# embarked at S, 7 also lack an age, and four hold the ticket "LINE", which
# is not an ordinary ticket number. Against: the zeros occur in all three
# classes, and a free ticket is possible. We keep the zeros, add a flag so
# any analysis can drop or test them, and write the choice in the codebook.
df["fare_zero"] = (df["fare"] == 0).astype("Int8")

# %% Task 5: categories
print(df["sex"].value_counts(dropna=False))      # male 577, female 314
print(df["embarked"].value_counts(dropna=False)) # S 644, C 168, Q 77, NaN 2
ct = pd.crosstab(df["pclass"], df["sex"], margins=True)
ct_row = pd.crosstab(df["pclass"], df["sex"], normalize="index").mul(100).round(1)
print(ct)
print(ct_row)                                # 3rd class: 70.7% male

# %% Task 6: create variables
ok = df["age"].notna()
child = (df["age"] < AGE_ADULT).astype("Int8")   # NaN < 18 is False ...
df["child"] = child.where(ok)                    # ... so missing age -> <NA>
df["family_size"] = df["sibsp"] + df["parch"] + 1
print(df["child"].value_counts(dropna=False))    # 0: 601, 1: 113, <NA>: 177

# %% Task 7: aggregate
by_class_sex = df.groupby(["pclass", "sex"]).agg(
    n=("survived", "size"),                  # passengers (survived is never missing)
    survival=("survived", "mean"),
    mean_age=("age", "mean"),                # mean over known ages only
)
print(by_class_sex.round(3))                 # 6 rows
df["class_fare"] = df.groupby("pclass")["fare"].transform("mean")
df["fare_rel"] = df["fare"] / df["class_fare"]
print(len(by_class_sex), len(df))            # 6 891
# agg gives one row per group (3 classes x 2 sexes = 6); transform gives one
# value per passenger, so df keeps its 891 rows.

# %% Task 8: save
df.to_parquet(PROC / "titanic_clean.parquet", index=False)
codebook = {
    "passengerid": "Passenger number in this file (1-891)",
    "survived": "Survived the sinking (1 = yes, 0 = no)",
    "pclass": "Ticket class (1 = first, 2 = second, 3 = third)",
    "name": "Passenger name",
    "sex": "Sex (male, female)",
    "age": "Age in years; fractions below 1; missing for 177",
    "sibsp": "Siblings and spouses aboard",
    "parch": "Parents and children aboard",
    "ticket": "Ticket number (text)",
    "fare": "Fare paid for the ticket; 0 for 15 passengers, kept (see fare_zero)",
    "cabin": "Cabin number; missing for 687",
    "embarked": "Port of embarkation (C, Q, S); missing for 2",
    "fare_zero": "1 if fare is exactly 0 (created)",
    "child": "1 if age below 18, 0 if 18 or over, <NA> if age missing (created)",
    "family_size": "sibsp + parch + 1 (created)",
    "class_fare": "Mean fare of the passenger's class (created)",
    "fare_rel": "fare / class_fare (created)",
}
with open(PROC / "titanic_codebook.json", "w", encoding="utf-8") as f:
    json.dump(codebook, f, indent=2, ensure_ascii=False)

# %% If you finish early (optional)
n_ticket = df.groupby("ticket")["ticket"].transform("size")
fares_per_ticket = df.groupby("ticket")["fare"].transform("nunique")
shared = n_ticket > 1
print(shared.sum(), (shared & (fares_per_ticket > 1)).sum())   # 344 2
# 344 passengers share a ticket with someone, and on all but 2 of those rows
# everyone on the ticket has the same fare: `fare` is the price of the
# TICKET, not of the person. Fare per person:
df["fare_pp"] = df["fare"] / n_ticket
print(df.groupby("pclass")[["fare", "fare_pp"]].mean().round(1))
# (Within this file only: people on the same ticket who are not in this
# 891-passenger sample are not counted, so fare_pp is an upper bound.)

# %%
print("Exercise done")
