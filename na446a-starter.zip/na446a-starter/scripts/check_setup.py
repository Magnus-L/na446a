"""Check that your NA446A setup works.

Run it from VS Code (open this file, press the play button at the top right)
or in the terminal with:  uv run scripts/check_setup.py

Every line should end in OK. If one does not, copy ALL the output into
the help form described on the course site's Setup page.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]   # the project folder
(ROOT / "output").mkdir(exist_ok=True)       # create output/ if it is missing
problems = []


def check(label, test):
    """Run one test; print OK or the error, and remember failures."""
    try:
        test()
        print(f"{label:<40} OK")
    except Exception as err:                  # show the error, keep going
        print(f"{label:<40} PROBLEM: {err}")
        problems.append(label)


def python_version():
    if sys.version_info < (3, 12):
        raise RuntimeError(f"Python {sys.version.split()[0]} is too old")


def packages():
    import pandas, pyarrow, matplotlib, statsmodels, requests, duckdb, dotenv  # noqa: F401


def read_data():
    import pandas as pd
    df = pd.read_csv(ROOT / "data" / "raw" / "check.csv")
    assert df.shape == (2, 3), f"expected 2 rows and 3 columns, got {df.shape}"


def make_figure():
    import matplotlib
    matplotlib.use("Agg")                     # draw without opening a window
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots()
    ax.bar(["North", "South"], [120, 95])
    fig.savefig(ROOT / "output" / "check_figure.png")
    plt.close(fig)


def run_sql():
    import duckdb
    assert duckdb.sql("SELECT 1 + 1").fetchone()[0] == 2


print(f"Python {sys.version.split()[0]} at {sys.executable}\n")
check("Python 3.12 or newer", python_version)
check("Course packages installed", packages)
check("Read a CSV from data/raw", read_data)
check("Save a figure to output/", make_figure)
check("Run SQL with DuckDB", run_sql)
check("Running inside the project's .venv", lambda: None if ".venv" in sys.executable
      else (_ for _ in ()).throw(RuntimeError("not the course environment: select .venv in VS Code")))

print("\nAll good: you are ready for the course." if not problems
      else f"\n{len(problems)} problem(s). See the Setup page, section 'If something fails'.")
