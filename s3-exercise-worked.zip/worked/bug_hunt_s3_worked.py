"""Solution to bug_hunt_s3.py (after Session 3), with a short comment on every line.

Same cells, TODOs and names as your file. Under each TODO: the answer, what each
line does, and the Stata you would write. The numbers in the comments are pair
00's (the data in the lab zip); other pairs get other numbers.

Before you run it: clean_registers_flawed.py must have run on the pair's data
(lab Step 8), so that data/processed/flawed_py/ holds its 20 files.
Check it:  uv run check_exercise_s3.py worked/bug_hunt_s3_worked.py   (or ... 07)
B13, B14, B24, B25, C1-C3); make_exercise_answers.py uses the same lines.
RUNTIME  under 2 seconds. Last line printed: "Exercise done"
"""
# %% ---- CHANGE HERE (only this line) ---------------------------------
PAIR = "00"                    # the same pair number as in the lab
# ---------------------------------------------------------------------

# %% Step 0: your pair's folders (done for you)
from pathlib import Path       # file paths that work on Mac and Windows
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]   # the lab folder: one up from this file's folder
HOME = ROOT / f"pair_{PAIR}"
if not (HOME / "data").exists():             # unzipped one folder too deep?
    HOME = HOME / f"pair_{PAIR}"
RAW = HOME / "data" / "raw"                  # the files as delivered
FLAWED = HOME / "data" / "processed" / "flawed_py"   # what the flawed script wrote

# %% Task 1 (easy): it runs
# Stata: local files : dir "flawed_py" files "*.csv"  /  display wordcount(`"`files'"')
n_outputs = len(list(FLAWED.glob("*.csv")))  # 20. glob("*.csv"): every .csv file; list, then len counts them

# %% Task 2 (easy): the level-1 bugs, in numbers
ak9 = pd.read_csv(FLAWED / "se_ak9.csv")     # the grade-9 file: should be one row per person
ak9_rows_per_person = len(ak9) / ak9["lopnr"].nunique()   # 16.0: 15456 rows / 966 persons
#   Cause (B2): `df.drop_duplicates()` on a line of its own. pandas returns a NEW
#   table; without `df = ...` nothing changes, and nothing warns. (Stata: isid lopnr would stop it.)
lisa_app = pd.read_csv(FLAWED / "se_lisa_appended.csv")
lisa_years = sorted(lisa_app["year"].unique().tolist())   # [2019, 2021, 2022, 2023]: no 2020. Stata: tab year
#   Cause (B3): the 2020 block was copied from 2019 and still says df["year"] = 2019.
firm_app = pd.read_csv(FLAWED / "se_foretag_appended.csv")
firm_years = sorted(firm_app["year"].unique().tolist())   # [2019, ..., 2022]: 2023 missing
#   Cause (B13): the concat lists the 2019-2022 files only; 2023 was never added.
mig = pd.read_csv(FLAWED / "se_migrationer.csv")
n_mig_missing = int(mig.isna().any(axis=1).sum())          # 114 persons. any(axis=1): True if ANY column in the row is missing
#   Cause (B4): every year's count gets fillna(0) on its own line; the line for
#   invnonoecd2023 was forgotten. Stata: misstable summarize
# Question 1 (exercise page): which would one assert have stopped? All four:
#   assert ak9["lopnr"].is_unique                       (Stata: isid lopnr)
#   assert sorted(lisa_app["year"].unique()) == [2019, 2020, 2021, 2022, 2023]
#   assert firm_app["year"].max() == 2023
#   assert mig.notna().all().all()                      (Stata: assert !missing(...))

# %% Task 3 (medium): trust but verify the codebook (three errata)
# Checklist items 1 (names), 6 (categories), 8 (IDs and keys), on the RAW files.
persons = pd.read_csv(RAW / "persons.csv", dtype=str)
kon_codes = sorted(persons["Kon"].unique().tolist())   # ['1', '2'] (C1). Stata: tab kon
cols_2021 = pd.read_csv(RAW / "lisa_2021.csv", dtype=str, nrows=1).columns   # nrows=1: read one row, just to get the names
for c in cols_2021:                          # look at each column name (Stata: describe)
    if "PeOrgNr" in c:                       # the employer id has "PeOrgNr" in its name
        employer_col_2021 = c                # AGI1PeOrgNr (C2)
missing = {}                                 # an empty dictionary: {file name: number of missing ids}
for f in sorted(RAW.glob("*.csv")):          # EVERY raw file, not only the ones we use
    d = pd.read_csv(f, dtype=str)
    if "LopNr" in d.columns and d["LopNr"].isna().any():   # has a person id, and some are missing?
        missing[f.name] = int(d["LopNr"].isna().sum())     # remember the file and the count
missing_id_file, n_missing_id = list(missing.items())[0]   # agi_manad_2023.csv, 41 (C3): the one file found
# Errata (codebook says / data say / how found):
# 1: Kon 0 = man, 1 = woman / Kon holds 1 and 2, never 0 / value_counts() (Stata: tab kon).
# 2: KU1PeOrgNr in every year / from 2021 it is AGI1PeOrgNr / list the columns per year.
# 3: LopNr never missing / 41 rows of agi_manad_2023.csv have none / isna().sum() per file.
# Question 2: which source to believe? The DATA, for what the files contain. The
#   codebook and the script's own comment ("(2,1) woman, man") disagree on Kon; to
#   settle what 1 and 2 MEAN, ask the data provider (SCB's documentation).

# %% Task 4 (medium, level 2): the youth flag in the municipal register
# The flawed script's comment: codes F12, F15, F18 AND age under 25.
kom_flawed = pd.read_csv(FLAWED / "se_insatser_kommun.csv")
n_youth_flawed = int(kom_flawed.loc[kom_flawed["youth"] == 1, "lopnr"].nunique())   # 125 persons flagged
kom = pd.read_csv(RAW / "insatser_kommun.csv", dtype=str)
codes = []                                   # the code columns: HKod, Kod1 ... Kod8
for c in kom.columns:
    if c == "HKod" or c.startswith("Kod"):
        codes.append(c)
has_youth_code = kom[codes].isin(["F12", "F15", "F18"]).any(axis=1)   # True if ANY code column holds a youth code
young = pd.to_numeric(kom["Alder"]) < 25    # age under 25 (Alder is text: make it a number first)
n_youth_right = int(kom.loc[has_youth_code & young, "LopNr"].nunique())   # 43: both conditions, then count persons
# Answer (B5): the line  a | b | ... | z & (alder < 25).  & binds before |, in
#   pandas AND in Stata, so the age test applies to the LAST term only; every
#   other youth code counts at any age: 125 instead of 43. Fix: brackets round
#   all the | terms, or isin(...).any(axis=1) & young as above.
# Question 3: the state register (line 841) has the same chain, and goes wrong
#   the same way: 100 persons instead of 41.

# %% Task 5 (hard, level 3): education after the new code vintage
l21_flawed = pd.read_csv(FLAWED / "se_lisa2021.csv")
share_educ_missing_2021_flawed = l21_flawed["educat_level"].isna().mean()   # 0.546. mean of True/False = share True
l21 = pd.read_csv(RAW / "lisa_2021.csv", dtype=str)
share_educ_missing_2021_right = (l21["Sun2020Niva"] == "999").mean()       # 0.017: 999 = unknown (the sentinel)
# Answer (B14): from 2021 the education variable is a new vintage (Sun2020Niva):
#   codes ending in 6 now end in 7, and 600/640 became 620. The script's typed
#   lists match none of them, and every unmatched code silently becomes missing:
#   a "fall" in education in 2021 that is pure artefact. Robust: classify on the
#   first two digits (e.g. l21["Sun2020Niva"].str[:2]), then assert that every
#   non-missing code got a level, so the next vintage stops the run.

# %% Task 6 (hard, level 3): the firm block "added in April" (the last block)
agi = pd.read_csv(RAW / "agi_manad_2023.csv", dtype=str)   # monthly pay: person x employer x month
n_dropped_by_dedup = len(agi) - len(agi.drop_duplicates(subset=["LopNr", "PeOrgNr", "Period"]))   # 30 rows removed
n_exact_copies = int(agi.duplicated().sum())               # 10: only these are real resubmissions
clean = agi.drop_duplicates()                              # drop the exact copies only (Stata: duplicates drop)
form = pd.to_numeric(clean["AnstForm"])                    # 1 permanent, 2 fixed-term, 3 hourly; empty = not reported
permshare_right = (form[form.notna()] == 1).mean()         # 0.760: share permanent among REPORTED months
# Answer (B25): the 41 rows with no LopNr. pandas (and Stata) treat missing ids
#   as EQUAL, so unidentified workers at the same firm and month look like
#   copies of each other: 20 real pay rows are dropped (30 - 10).
# (B24): fillna(0) turns "not reported" into a code 0, and `< 2` then counts it as
#   permanent: firms' permanent shares go up (or stay), never down.
# Question 4: the rows without a person id are real pay. In a PERSON-level file
#   they cannot be placed (no id): drop them there, and say so. In a FIRM-level
#   file (wage bill) they belong: keep them.

# %% If you finish early (optional)
# The smallest set of asserts, and where each goes:
# assert persons["LopNr"].is_unique                        after reading persons (B19)
# assert set(persons["Kon"]) <= {"1", "2"}                  the codes actually there (C1)
# assert df["year"].nunique() == 5                          after the LISA append (B3)
# assert df["educat_level"].notna().sum() == (df["sun2020niva"].notna()).sum()   (B14)
# assert agi["LopNr"].notna().all()                         before any key-based dedup (B25)
# assert set(df["anstform"].dropna()) <= {1, 2, 3}          after the recode (B24)
# assert sorted(firms["year"].unique()) == list(range(2019, 2024))  after the firm append (B13)
# Two catch bugs that never raise an error in pandas: B14 (silent missing) and B24 (fillna(0)).

# %%
print("Exercise done")
