"""Solution to s3_lab.py (Session 3 lab), with a short comment on every line.

Same steps and TODOs as your file. Under each TODO: the answer, what each line
does, and the Stata you would write. The numbers in the comments are pair 00's
(the data in the zip); other pairs get the same kinds of result, other numbers.

How to run: this file sits in s3_lab/worked/ (teacher copy: worked/). Open the
folder na446a-starter in VS Code and press Shift+Enter in each cell from the top.
After a restart, start again from the top: Python forgets everything, like
Stata after clear all. Check it:  uv run check_s3.py worked/s3_lab_worked.py
RUNTIME  about 1 second. Last line printed: "Lab done"
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
PAIR = "00"                    # "00" as in class; or the pair you downloaded, two digits
FIRST_YEAR = 2019              # the yearly files run from ...
LAST_YEAR = 2023               # ... to
KEY = ["LopNr", "year"]        # what identifies one row of the PANEL (person and year)
LAG_COL = "ForvErs"            # the variable to lag: income from work
# ---------------------------------------------------------------------

# %% Step 0: find your pair's folder (done for you)
# Stata: cd ".../s3_lab/pair_00"   (here we build the paths instead of cd)
from pathlib import Path       # Path: file paths that work on Mac and Windows
import pandas as pd            # pandas, under the short name pd

ROOT = Path(__file__).resolve().parents[1]   # the lab folder: one up from this file's folder
HOME = ROOT / f"pair_{PAIR}"                  # "/" glues folder names: s3_lab/pair_00
if not (HOME / "data").exists():              # unzipped one folder too deep?
    HOME = HOME / f"pair_{PAIR}"
RAW = HOME / "data" / "raw"                   # the delivered files: read, never overwrite
PROC = HOME / "data" / "processed"            # files our code writes
print((RAW / "GENERATED.txt").read_text().split())   # ['seed=446', 'pair=default']

# %% Step 1: stack the yearly files (append)  [slides: Steps 6-8]
# Stata:  foreach y of numlist 2019/2023 {
#             import delimited lisa_`y'.csv, stringcols(_all) clear
#             rename ...          (one line per rename)
#             gen year = `y'
#             append ...
#         }
# Why rename: some variables changed name in 2021. If we stack without renaming,
# one variable becomes two half-empty columns (old name up to 2020, new name after).
# RENAME = {name in 2021-2023: name in 2019-2020}. The first five are from the codebook.
RENAME = {"SyssStat19": "SyssStat11",
          "Sun2020Niva": "Sun2000Niva",
          "Sun2020Niva_Old": "Sun2000Niva_Old",
          "AGI1SSYK4": "KU1SSYK4",
          "AGI1Ink": "KU1Ink",
          "AGI1PeOrgNr": "KU1PeOrgNr"}   # TODO 1a ANSWER: the sixth, missing from the codebook
frames = []                                   # an empty list: we collect the five years in it
for year in range(FIRST_YEAR, LAST_YEAR + 1): # 2019 ... 2023 (range stops BEFORE the end, hence + 1)
    d = pd.read_csv(RAW / f"lisa_{year}.csv", dtype=str)   # one year; f"..{year}.." puts the year in the name
    # TODO 1b ANSWER: rename, and add the column year (Stata: rename, gen year = `y')
    d = d.rename(columns=RENAME).assign(year=year)
    frames.append(d)                          # put this year's table in the list (NOT Stata's append)
lisa = pd.concat(frames, ignore_index=True)   # stack the five tables: THIS is Stata's append
print(lisa.shape)                             # (4884, 21): rows, columns
# The test: share of non-missing values per column and year; show columns that are
# EMPTY in a whole year. Stata: by year: misstable summarize (roughly)
filled = lisa.notna().groupby(lisa["year"]).mean()   # notna(): 1 if a value is there; mean by year = share
print(filled.loc[:, (filled == 0).any()])            # columns with a 0 share in any year: want none
# Answer 1a: with only the codebook's five renames, KU1PeOrgNr is empty from 2021
# and AGI1PeOrgNr before 2021: the employer id changed name, and the codebook missed it.

# %% Step 2: check the key of the panel  [slides: Step 8]
# Stata:  duplicates report lopnr year   /   duplicates report   /   duplicates drop   /   isid lopnr year
# Predict first: how many person-years appear more than once? ...
# TODO 2a ANSWER: does a person-year appear more than once?
n_dup_key = lisa.duplicated(KEY).sum()        # 1. duplicated(): True for each REPEAT of an earlier row; sum counts them
# TODO 2b ANSWER: is that because the same row was recorded twice?
n_dup_row = lisa.duplicated().sum()           # 1. no columns given = compare ALL columns (Stata: duplicates report)
# TODO 2c ANSWER: drop the exact copies, then check that the key is unique
lisa = lisa.drop_duplicates()                 # Stata: duplicates drop
assert not lisa.duplicated(KEY).any()         # Stata: isid lopnr year (stops with an error if not unique)

print(n_dup_key, n_dup_row, len(lisa))        # 1 1 4883: one exact copy, dropped
# Note: duplicated(keep=False) would mark BOTH rows of a pair, so it counts 2, not 1.

# %% Step 3a: a merge that fails ON PURPOSE (predict first: will it run?)  [slides: Steps 3-4]
# Stata:  merge m:1 lopnr using persons    -> refuses, r(459)
persons = pd.read_csv(RAW / "persons.csv", dtype=str)   # one row per person (we hope)
try:                                                   # try: run this, and if it fails ...
    lisa.merge(persons, on="LopNr", how="left", validate="m:1")   # m:1 = many panel rows to ONE person
    print("It ran.")
except pd.errors.MergeError as err:                    # ... show the error instead of stopping
    print("MergeError:", str(err).splitlines()[0])
# Answer: persons (the "right dataset") is at fault: some LopNr appear more than once,
# so it is not "one" person per id, and validate="m:1" refuses, as Stata's m:1 does.

# %% Step 3b: fix the persons file, then merge  [slides: Steps 2-5]
# Stata:  duplicates drop
#         duplicates tag lopnr, gen(conflict)
#         bysort lopnr: keep if _n == 1
#         isid lopnr
#         merge m:1 lopnr using persons, assert(master match)
#         tab _merge
#         drop _merge
# NB: the key of persons is LopNr ALONE (it has no year). KEY is the panel's key.
# TODO 3a ANSWER: drop exact copies, then count the ids that STILL repeat
persons = persons.drop_duplicates()                     # exact copies: 1005 -> 1002 rows
conflict = persons.duplicated("LopNr", keep=False)      # True for EVERY row of a repeated id (Stata: duplicates tag)
n_conflict = persons.loc[conflict, "LopNr"].nunique()   # 2 ids. .loc[rows, column]: pick rows, then a column
print(persons.loc[conflict].sort_values("LopNr"))       # look at them: they differ in country of birth
# TODO 3b ANSWER: keep the first row of each id (a decision: write it down), then check
persons = persons.drop_duplicates("LopNr")              # keep the first record of P000182 and P000358
assert persons["LopNr"].is_unique                       # Stata: isid lopnr
# TODO 3c ANSWER: the merge, with all four checks
panel = lisa.merge(persons, on="LopNr", how="left",     # how="left": keep every panel row (Stata keeps all)
                   validate="m:1", indicator=True)      # m:1 check, and add _merge (Stata does both by itself)
print(panel["_merge"].value_counts())                   # Stata: tab _merge. both 4883, left_only 0
assert len(panel) == len(lisa)                          # rows in = rows out: nothing lost, nothing added
panel = panel.drop(columns="_merge")                    # Stata: drop _merge

# %% Step 4: catch the wrong merge an AI proposes  [slides: Steps 3 and 5]
# We asked a chatbot: "Add each person's total pay in 2023 from the monthly
# file agi_manad_2023.csv to the 2023 rows of my panel." It answered with the
# line marked # AI: below.
y23 = panel[panel["year"] == LAST_YEAR]                 # keep 2023 rows. Stata: keep if year == 2023
agi = pd.read_csv(RAW / f"agi_manad_{LAST_YEAR}.csv", dtype=str)   # one row per person, employer AND month
# Predict first: how many rows will `pay` have, compared with len(y23)? ...
pay = y23.merge(agi, on="LopNr")      # AI:
n_ai_rows = len(pay)
print(len(y23), "persons in 2023;", n_ai_rows, "rows after the AI's merge")   # 971; 7734
# Answer, two faults:
# (1) agi has many rows per person (12 months, sometimes 2 employers), so each
#     person is repeated: a many-to-many merge. 971 persons -> 7734 rows.
# (2) the default how="inner" keeps only persons found in BOTH tables: the 282
#     persons with no declared pay vanish, silently. (Stata's merge would keep them.)
# Stata:  destring lon, replace
#         collapse (sum) lon, by(lopnr)           (one row per person)
#         merge 1:1 lopnr using agi_year
#         tab _merge
# TODO 4 ANSWER: first make agi one row per person, then merge 1:1
agi["Lon"] = pd.to_numeric(agi["Lon"])                  # text -> number (Stata: destring)
agi_year = agi.groupby("LopNr", as_index=False)["Lon"].sum()   # yearly pay per person (Stata: collapse (sum) lon, by(lopnr))
#   as_index=False keeps LopNr as an ordinary column, so we can merge on it
pay = y23.merge(agi_year, on="LopNr", how="left",       # left: keep every 2023 person
                validate="1:1", indicator=True)         # 1:1: one row per person on BOTH sides
n_no_pay = (pay["_merge"] == "left_only").sum()         # 282 persons with no pay. (==) gives True/False; sum counts
assert len(pay) == len(y23)                             # 971 in, 971 out
print(n_no_pay)

# %% AT HOME from here: Steps 5-8 ==========================================

# %% Step 5: wide and long  [slides: appendix, self-study]
# Stata:  reshape wide syssstat11, i(lopnr) j(year)
#         reshape long syssstat11, i(lopnr) j(year)
# TODO 5a ANSWER: one row per person, one column per year
wide = panel.pivot(index="LopNr", columns="year", values="SyssStat11")   # rows = i(), columns = j(), values = the variable
print(wide.shape)                                       # (1000, 5): 1000 persons, 5 years
n_all_years = wide.notna().all(axis=1).sum()            # 897: all(axis=1) = True if EVERY year in the row has a value
# TODO 5b ANSWER: back to long, dropping the person-years that do not exist
long = wide.reset_index().melt(id_vars="LopNr", value_name="status").dropna()
#   reset_index(): LopNr back to an ordinary column; melt: one row per person-year;
#   dropna(): drop the empty cells (years a person was not in the data)
print(n_all_years, len(long), len(panel))               # 897 4883 4883: long has as many rows as the panel

# %% Step 6: a lag within each person, and the gap trap  [slides: Step 9 and appendix]
# Stata:  xtset lopnr year
#         gen inc_lag = L.inc
# TODO 6a ANSWER
panel = panel.sort_values(KEY)                          # by person, then year: shift takes the row ABOVE
panel["inc"] = pd.to_numeric(panel[LAG_COL])            # income as a number (Stata: destring)
panel["inc_lag"] = panel.groupby("LopNr")["inc"].shift(1)   # within each person, the row above (Stata: L.inc)
# TODO 6b ANSWER: is the row above really LAST year?
panel["gap"] = panel["year"] - panel.groupby("LopNr")["year"].shift(1)   # this year minus previous year in the data
n_gap = (panel["gap"] > 1).sum()                        # 52 rows where a year is missing in between
panel["inc_lag"] = panel["inc_lag"].where(panel["gap"] == 1)   # keep the lag only if gap is 1, else missing
print(n_gap, panel["inc_lag"].notna().sum())            # 52 3831
# Answer: across a gap, shift(1) gives an older year's income, e.g. 2019 as "last
# year" for 2021. Stata's L. uses the year itself (after xtset), so L.inc is
# missing when last year is missing. pandas does not know the time variable.

# %% Step 7: save the panel  [not on the slides]
# Stata:  save panel.dta
# TODO 7 ANSWER
PROC.mkdir(parents=True, exist_ok=True)                 # make the folder if missing (Stata: capture mkdir)
panel.to_parquet(PROC / "panel.parquet")                # parquet: a compact file that keeps the column types
print(panel.shape)                                      # (4883, 29)

# %% Step 8: before the exercise: run the flawed script and find what shows (about 20 minutes)
# clean_registers_flawed.py writes cleaned files into data/processed/flawed_py/.
# What a student does: Find and Replace  C:/Users/teacher/project/  with the
# full path of the pair folder, save, run the file (about 2 seconds). Then: read
# the OUTPUT and look for what is wrong, without reading the script's logic.
# Each bug: file, what, a number. The cells below need the flawed script run first.
# The answers (pair 00), each checked by a line of code below:
# Bug 1: every path is C:/Users/teacher/project/... (48 paths): runs on nobody's machine.
# Bug 2: se_ak9.csv has 16 rows per person (15456 rows, 966 persons).
# Bug 3: se_lisa_appended.csv has 1959 rows labelled 2019 and none 2020.
# Bug 4: se_foretag_appended.csv stops at 2022: 2023 is never appended.
# Bug 5: se_migrationer.csv: invnonoecd2023 missing for 114 of 167 persons.
FLAWED = PROC / "flawed_py"
ran = (FLAWED / "se_ak9.csv").exists()        # has the flawed script been run?
if not ran:
    print("Run clean_registers_flawed.py first (see the steps above); Bugs 2-5 read its output.")

# Check 1: every path points to the teacher's machine, so it runs on nobody else's.
text = (ROOT / "clean_registers_flawed.py").read_text()   # the script as text
print("Bug 1:", text.count("C:/Users/teacher/project/"), "hard-coded paths")   # 48
# Fix: one ROOT = Path(...) at the top, every path built from it (as in Step 0).

if ran:                                       # the indented lines run only if the files exist
    # Check 2: grades file should be one row per person (Stata: isid lopnr).
    ak9 = pd.read_csv(FLAWED / "se_ak9.csv", dtype=str)
    print("Bug 2:", len(ak9), "rows,", ak9["lopnr"].nunique(), "persons")   # 15456 rows, 966 persons: 16 per person
    # Cause: a line  df.drop_duplicates()  whose result is never stored (needs df = ...).

    # Check 3: years in the stacked LISA file (Stata: tab year).
    lisa_flawed = pd.read_csv(FLAWED / "se_lisa_appended.csv", dtype=str)
    print("Bug 3:", lisa_flawed["year"].value_counts().sort_index().to_dict())   # 2019 twice as big, no 2020
    # Cause: the 2020 block still says year = 2019 (copy-paste).

    # Check 4: years in the stacked firm file.
    firms_flawed = pd.read_csv(FLAWED / "se_foretag_appended.csv", dtype=str)
    print("Bug 4:", sorted(firms_flawed["year"].unique()))   # stops at 2022
    # Cause: the 2023 firm file is never appended.

    # Check 5: missing values in the migration file (Stata: misstable summarize).
    mig = pd.read_csv(FLAWED / "se_migrationer.csv", dtype=str)
    print("Bug 5:", mig["invnonoecd2023"].isna().sum(), "of", len(mig), "missing in invnonoecd2023")   # 114 of 167
    # Cause: the other years get fillna(0) (no migration = 0); for this one the line was forgotten.

# %% If you finish early (optional): the person-firm-year join
# Stata:  (stack the firm years as in Step 1), duplicates report peorgnr year, ...
#         merge m:1 ku1peorgnr year using firms
firm_frames = []
for year in range(FIRST_YEAR, LAST_YEAR + 1):           # same loop as Step 1, for firms
    f = pd.read_csv(RAW / f"foretag_{year}.csv", dtype=str)
    firm_frames.append(f.assign(year=year))
firms = pd.concat(firm_frames, ignore_index=True)
print(firms.duplicated(["PeOrgNr", "year"]).sum())      # 1: one firm twice in 2021
firms = firms.drop_duplicates(["PeOrgNr", "year"])      # keep the first, as for persons
pf = panel.merge(firms, left_on=["KU1PeOrgNr", "year"], # the key has different NAMES in the two tables:
                 right_on=["PeOrgNr", "year"], how="left",   # left_on / right_on say which is which
                 validate="m:1", indicator=True)
employed = pf["KU1PeOrgNr"].notna()                     # rows with an employer id
print(pf.loc[employed, "_merge"].value_counts())        # all 'both': every employed person-year finds its firm

# %%
print("Lab done")
