# Start your thesis from this project

1. **Copy one version.** Copy the `stata` or the `python` folder to where you keep your
   thesis, and give it the name of your project (for example `thesis-unions`). Each
   folder works on its own.
2. **Swap the data.** Put your own data files in `data/raw/` and delete `wagepan.csv`.
   Never change a file in `data/raw/`: every change is made by code.
3. **Change the steps.** Keep the numbering. Rewrite `01_import` for your files, then the
   checks in `02_clean` for your variables. If you need more steps (merging two sources,
   for example), add a file such as `02b_merge` and add it to the master file.
4. **Delete what you do not need.** A step you do not use goes out of the folder and out
   of the master file.
5. **Write the header of each file first:** what it does, what it reads, what it
   writes. Then the code.
6. **Use version control from day one** (git, or at least dated copies), and keep a
   short log of decisions: which rows you dropped and why.

## Before you hand in: the five checks

1. Delete everything in `data/processed` and `output`; run the master file; does
   everything come back?
2. Every number in the text comes from a log or a table produced by your code.
3. Raw data untouched; one file per step; a header on each; comments say WHY.
4. Lines that came from an AI tool are marked (`* AI:` in Stata, `# AI:` in Python),
   and you can explain each of them.
5. No names or personal identity numbers anywhere in code, logs or tables.
