"""Step 1: read the raw file, keep what the question needs, check what one row is.

Inputs:  data/raw/wagepan.csv (never changed)
Outputs: data/processed/wagepan_imported.parquet
Run:     from run_all.py, or on its own (the paths work from any folder)
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]      # the project folder, one up from scripts/
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
PROCESSED.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(RAW / "wagepan.csv")
print("01_import: rows in", len(df))            # expect 4360

# Keep only the variables the question needs: a smaller file is easier to check
df = df[["nr", "year", "lwage", "educ", "exper", "expersq",
         "black", "hisp", "married", "union"]]

# What is one row? One man (nr) in one year. Stop if a pair appears twice
# (Stata: isid nr year).
assert not df.duplicated(["nr", "year"]).any(), "nr and year do not identify the rows"
df = df.sort_values(["nr", "year"]).reset_index(drop=True)

# Parquet keeps the column types exactly (a csv would forget them)
df.to_parquet(PROCESSED / "wagepan_imported.parquet")
