"""Step 4: Table 2, the wage equation (Mincer): log wage on years of schooling
and experience. The coefficient on educ is the percentage wage gain from one
more year of school (times 100), comparing men with the same experience.

Inputs:  data/processed/wagepan_clean.parquet, labels.csv
Outputs: output/tables/table2_regressions.csv (to read), results_long.csv (every number)
Run:     from run_all.py, or on its own
"""
from pathlib import Path
import pandas as pd
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "output" / "tables"
TABLES.mkdir(parents=True, exist_ok=True)

df = pd.read_parquet(PROCESSED / "wagepan_clean.parquet")
labels = pd.read_csv(PROCESSED / "labels.csv", index_col="variable")["label"]

# Standard errors clustered by man (nr): the same man's eight years are not eight
# independent draws, so ordinary standard errors would be too small.
# use_t=True: p-values from the t distribution, as Stata's vce(cluster nr) does.
CLUSTER = {"cov_type": "cluster", "cov_kwds": {"groups": df["nr"]}, "use_t": True}

# (1) the textbook Mincer equation
m1 = smf.ols("lwage ~ educ + exper + expersq", data=df).fit(**CLUSTER)
# (2) plus year dummies, C(year): wages rose for everyone over 1980-87 (inflation, the cycle)
m2 = smf.ols("lwage ~ educ + exper + expersq + C(year)", data=df).fit(**CLUSTER)
# (3) plus background: does schooling only stand in for these?
m3 = smf.ols("lwage ~ educ + exper + expersq + C(year) + black + hisp + married + union",
             data=df).fit(**CLUSTER)
print(m3.summary().tables[1])                    # the full output of model 3, to look at

MODELS = {"m1": m1, "m2": m2, "m3": m3}
TERMS = ["educ", "exper", "expersq", "black", "hisp", "married", "union"]

# ---- results_long.csv: every coefficient at full precision (check_same.py reads it)
rows = []
for name, m in MODELS.items():
    for term in TERMS:
        if term in m.params.index:                # a variable not in this model is skipped
            rows.append([name, term, m.params[term], m.bse[term], m.pvalues[term]])
    rows.append([name, "N", int(m.nobs), None, None])
    rows.append([name, "r2", m.rsquared, None, None])
pd.DataFrame(rows, columns=["model", "term", "coef", "se", "p"]).to_csv(
    TABLES / "results_long.csv", index=False, float_format="%.12f")

# ---- table2_regressions.csv: the table as it goes in the thesis --------------
# Coefficient with stars, standard error in brackets below: * p<0.10 ** p<0.05 *** p<0.01
table = []
for term in TERMS:
    line1 = [labels[term]]
    line2 = [""]
    for m in MODELS.values():
        if term in m.params.index:
            p = m.pvalues[term]
            stars = "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.10 else ""
            line1.append(f"{m.params[term]:.4f}{stars}")
            line2.append(f"({m.bse[term]:.4f})")
        else:
            line1.append("")
            line2.append("")
    table.append(line1)
    table.append(line2)
table.append(["Year dummies", "no", "yes", "yes"])
table.append(["Observations"] + [str(int(m.nobs)) for m in MODELS.values()])
table.append(["R-squared"] + [f"{m.rsquared:.3f}" for m in MODELS.values()])
pd.DataFrame(table, columns=["row", "(1)", "(2)", "(3)"]).to_csv(
    TABLES / "table2_regressions.csv", index=False)
print("04_estimate: table2_regressions.csv written")
