"""Step 2: check the data before using it, make the variables, name them.

Inputs:  data/processed/wagepan_imported.parquet
Outputs: data/processed/wagepan_clean.parquet
Run:     from run_all.py, or on its own
"""
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"

df = pd.read_parquet(PROCESSED / "wagepan_imported.parquet")

# ---- Checks: assert stops the run if a statement is false -------------
# A balanced panel: every man is seen in all eight years, 1980-87
assert df["year"].between(1980, 1987).all()
assert (df.groupby("nr")["year"].count() == 8).all(), "some men lack a year"
# Possible values only (schooling in years, experience in years, 0/1 dummies)
assert df["educ"].between(0, 20).all() and df["exper"].between(0, 30).all()
assert (df["expersq"] == df["exper"] ** 2).all()     # the square is what it says it is
for v in ["black", "hisp", "married", "union"]:
    assert df[v].isin([0, 1]).all(), f"{v} is not 0/1"
# No missing values in what goes into the regression
assert df.notna().all().all(), "missing values"

# ---- New variables ----------------------------------------------------
# The hourly wage in dollars, to see the level behind the log
df["wage"] = np.exp(df["lwage"])

# ---- Labels: Python has no variable labels, so keep them in one place.
# The tables and the figure read them from this file.
LABELS = {
    "lwage": "Log hourly wage",
    "wage": "Hourly wage (USD)",
    "educ": "Years of schooling",
    "exper": "Years of work experience",
    "expersq": "Experience squared",
    "black": "Black (0/1)",
    "hisp": "Hispanic (0/1)",
    "married": "Married (0/1)",
    "union": "Union member (0/1)",
}
pd.Series(LABELS, name="label").rename_axis("variable").to_csv(PROCESSED / "labels.csv")

df.to_parquet(PROCESSED / "wagepan_clean.parquet")
print("02_clean: rows out", len(df), "men", df["nr"].nunique())
