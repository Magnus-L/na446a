"""Step 5: Figure 1, mean log wage by years of schooling: the raw pattern
behind the coefficient on educ in Table 2.

Inputs:  data/processed/wagepan_clean.parquet
Outputs: output/figures/figure1_wage_by_school.png and .pdf
Run:     from run_all.py, or on its own
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")                            # draw to files only, no window
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
FIGURES = ROOT / "output" / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

df = pd.read_parquet(PROCESSED / "wagepan_clean.parquet")

# One point per year of schooling: the mean log wage of the men with that schooling
# (Stata: collapse (mean) lwage (count) n = lwage, by(educ))
by_school = df.groupby("educ")["lwage"].agg(["mean", "count"])
print(by_school.round(3))                        # look at the numbers the figure shows

# Grey, so it prints well in black and white; the title states the finding.
# Circle size = number of person-years: the few men with under 9 years of school
# make the left part jumpy, and the reader should see that.
fig, ax = plt.subplots(figsize=(7, 4.2))
ax.scatter(by_school.index, by_school["mean"], s=by_school["count"] * 1.5,
           facecolors="none", edgecolors="0.35")
ax.set_title("Men with more schooling earn more")
ax.set_xlabel("Years of schooling")
ax.set_ylabel("Mean log hourly wage")
ax.spines[["top", "right"]].set_visible(False)
fig.text(0.01, -0.04, "Circle size: number of person-years.\n"
         "Source: Vella and Verbeek (1998), 545 men, 1980-87, 4,360 person-years.",
         fontsize=8)
for ext in ["png", "pdf"]:
    fig.savefig(FIGURES / f"figure1_wage_by_school.{ext}", bbox_inches="tight", dpi=200)
print("05_figures: figure1 written")
