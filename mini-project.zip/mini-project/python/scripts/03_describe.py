"""Step 3: Table 1, descriptive statistics. Show the data before the regression.

Inputs:  data/processed/wagepan_clean.parquet, labels.csv
Outputs: output/tables/table1_descriptives.csv
Run:     from run_all.py, or on its own
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "output" / "tables"
TABLES.mkdir(parents=True, exist_ok=True)

df = pd.read_parquet(PROCESSED / "wagepan_clean.parquet")
labels = pd.read_csv(PROCESSED / "labels.csv", index_col="variable")["label"]

# One row per variable (Stata: summarize). describe() gives the variables as
# columns, so .T turns the table round.
VARS = ["lwage", "wage", "educ", "exper", "black", "hisp", "married", "union"]
table = df[VARS].describe().T
table = table[["mean", "std", "min", "max", "count"]].round(4)
table.columns = ["mean", "sd", "min", "max", "n"]
table["n"] = table["n"].astype(int)
table.insert(0, "label", labels[VARS])           # the label as the first column
print(table)

# A csv file opens in Excel; paste it into Word
table.rename_axis("variable").to_csv(TABLES / "table1_descriptives.csv", float_format="%.4f")
print("03_describe: table1_descriptives.csv written")
