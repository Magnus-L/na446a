"""Run the whole mini project, from the raw file to the last table and figure.

Question: how much more do men earn for each extra year of schooling?
(a Mincer wage equation on the Vella-Verbeek panel, 545 men, 1980-87)

Run from this folder:  uv run run_all.py   (or open it in VS Code and press play)
Last printed line: "run_all done: log in output/logs/run_log.txt"

The test of a good project: delete data/processed/ and output/, run this,
and everything comes back. The log records what every step did.

Reproducibility checklist (before you hand in):
1. Delete everything in data/processed and output; run run_all.py; does everything come back?
2. Every number in the text comes from a log or a table produced by your scripts.
3. Raw data untouched; one script per step; a header on each; comments say WHY.
4. Lines that came from an AI tool are marked # AI: and you can explain each of them.
5. No names or personal identity numbers anywhere in scripts, logs or tables.
"""
# ---- CHANGE HERE: the scripts, in the order they run -------------------
SCRIPTS = [
    "scripts/01_import.py",     # raw csv -> data/processed/wagepan_imported.parquet
    "scripts/02_clean.py",      # checks, new variables -> wagepan_clean.parquet
    "scripts/03_describe.py",   # Table 1: descriptive statistics
    "scripts/04_estimate.py",   # Table 2: the wage equation, three models
    "scripts/05_figures.py",    # Figure 1: mean log wage by years of schooling
]
# ------------------------------------------------------------------------

import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
# The folders that the scripts write to (they may have been deleted for the test)
for folder in ["data/processed", "output/tables", "output/figures", "output/logs"]:
    (ROOT / folder).mkdir(parents=True, exist_ok=True)

log = [f"run_all started {datetime.now():%Y-%m-%d %H:%M}"]
for script in SCRIPTS:
    # Run each script with the same Python as this one. Its normal output is
    # kept for the log; an error message goes straight to the screen.
    result = subprocess.run([sys.executable, ROOT / script],
                            stdout=subprocess.PIPE, text=True, encoding="utf-8")
    print(result.stdout, end="")
    log.append(result.stdout.strip())
    if result.returncode != 0:                      # stop at the first script that fails
        log.append(f"STOPPED: {script} failed")
        break

(ROOT / "output" / "logs" / "run_log.txt").write_text("\n".join(log) + "\n", encoding="utf-8")
if result.returncode != 0:
    sys.exit(f"STOPPED: {script} failed. Its error message is above.")
print("run_all done: log in output/logs/run_log.txt")
