# A whole project, start to finish: Stata and Python

A small but complete empirical project, written twice: once in Stata and once in Python.
Each version goes from the raw data file to the tables and the figure of a short report,
one step per file, and both give the same numbers. Use it as the model for your own thesis:
copy the version you prefer and replace the question and the data (see
`START_YOUR_THESIS.md`).

## The question

How much more do men earn for each extra year of schooling? This is the classic Mincer
wage equation: the log hourly wage on years of schooling, experience and experience
squared. The coefficient on schooling, times 100, is roughly the percentage wage gain from
one more year of school, comparing men with the same experience.

The answer here: about 9 to 10 per cent per year (Table 2). It is a correlation, not
the causal effect of school: men who stay longer in school may differ in ways we do not
see. Column (3) shows that adding background variables changes the estimate little.

## The data

`wagepan.csv`: 545 young American men followed every year from 1980 to 1987 (4,360
rows, one per man and year), from the US National Longitudinal Survey of Youth. Used in

> Vella, F., and Verbeek, M. (1998). Whose wages do unions raise? A dynamic model of
> unionism and wage rate determination for young men. *Journal of Applied Econometrics*,
> 13(2), 163–183.

and distributed with Wooldridge's textbook *Introductory Econometrics* as `WAGEPAN`. The
file is public teaching data; each version has its own copy in `data/raw/`, which is
never changed.

## How to run it

**Stata** (version 18 or newer, built-in commands only): open `stata/master.do` in Stata
and run it (Do). If Stata says it cannot find the data, set `global root` at the top of
`master.do` to the full path of the `stata` folder. Last line in the log:
`master done: log in output/logs/master.log`.

**Python**: open the `python` folder in VS Code (or put this folder inside your course
folder), open `run_all.py` and press the play button, or type in the terminal, in the
`python` folder: `uv run run_all.py`. The first `uv run` installs the packages in
`pyproject.toml` (needs the internet once). Last line:
`run_all done: log in output/logs/run_log.txt`.

**Do they agree?** After running both, in this folder: `python check_same.py`. Last line:
`SAME: Stata and Python agree`.

## What is where

```
mini-project/
├── README.md               this file
├── START_YOUR_THESIS.md    how to turn this into your own project
├── check_same.py           compares the Stata and the Python results
├── stata/
│   ├── master.do           runs everything, in order, with a log
│   ├── do/01_import.do … 05_figures.do
│   ├── data/raw/           the original data, never changed
│   ├── data/processed/     made by the do-files (delete it any time)
│   └── output/             tables/, figures/, logs/ (made by the do-files)
└── python/
    ├── run_all.py          runs everything, in order, with a log
    ├── scripts/01_import.py … 05_figures.py
    ├── pyproject.toml      the packages this project needs
    ├── data/raw/ , data/processed/ , output/   as in Stata
```

## The steps, side by side

| Step | What it does | Stata | Python (pandas, statsmodels) |
|---|---|---|---|
| 01 import | Read the raw file, keep the variables, check what one row is | `import delimited`, `keep`, `isid nr year`, `save` | `pd.read_csv`, `df[[...]]`, `df.duplicated([...]).any()`, `to_parquet` |
| 02 clean | Check the data (balanced, possible values, no missing), make the wage in dollars, labels | `assert`, `bysort nr: assert _N == 8`, `generate`, `label variable` | `assert`, `groupby("nr")["year"].count()`, `np.exp`, a labels file |
| 03 describe | Table 1: mean, sd, min, max, N | `summarize`, `file write` | `describe().T`, `to_csv` |
| 04 estimate | Table 2: three wage equations, standard errors clustered by man | `regress ..., vce(cluster nr)`, `i.year`, `etable` | `smf.ols(...).fit(cov_type="cluster", ...)`, `C(year)` |
| 05 figures | Figure 1: mean log wage by years of schooling | `collapse`, `twoway scatter`, `graph export` | `groupby().agg()`, `ax.scatter`, `fig.savefig` |

The results in both: `output/tables/table1_descriptives.csv`, `table2_regressions.csv`
(the table as it goes in a report), `results_long.csv` (every number at full precision)
and `output/figures/figure1_wage_by_school.png` and `.pdf`. Stata also writes Table 2 for
Word (`table2_regressions.docx`).

## Why it is built like this

- **One file per step, run in order by one master file.** When something changes, you
  rerun everything and nothing is forgotten.
- **Raw data never changed; everything else made by code.** Delete `data/processed` and
  `output`, run the master file, and everything comes back. That is the test.
- **Checks in the code (`assert`, `isid`).** The run stops when the data are not what you
  think, instead of giving a wrong table quietly.
- **Every number in the report comes from a table or a log the code wrote.** Never type
  a number by hand.

## Next

Schooling hardly changes for these men over 1980–87, so a model with a fixed effect for
each man cannot estimate its return. For what fixed effects can do on the same data
(the union wage premium, for example), see the Further module F1 Panel regressions.
