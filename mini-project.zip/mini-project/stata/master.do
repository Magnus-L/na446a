* =====================================================================
* PURPOSE  Run the whole mini project, from the raw file to the last table and figure.
*          Question: how much more do men earn for each extra year of schooling?
*          (a Mincer wage equation on the Vella-Verbeek panel, 545 men, 1980-87)
* INPUTS   data/raw/wagepan.csv (never changed)
* OUTPUTS  data/processed (two .dta files), output/tables, output/figures, output/logs/master.log
* CREATED  Oct 2026, Magnus Lodefalk, with Claude. Stata 18 or newer, built-in commands only.
* HOW      Open this file in Stata and run it (Do). Everything else runs from here.
*          The test of a good project: delete data/processed and output, run this file,
*          and everything comes back.
* =====================================================================

* ---- CHANGE HERE (only this line) -----------------------------------
* The project folder. "`c(pwd)'" = the folder Stata is in now; when Stata opens
* this file by double-click, that is the folder of this file. If not, write the full
* path instead, for example: global root "C:/Users/me/thesis/stata"
global root "`c(pwd)'"
* ---------------------------------------------------------------------

version 18                     // results stay the same in newer Stata versions
clear all
set more off
capture log close              // closes a log left open if the last run stopped with an error

* Stop at once with a clear message if $root is wrong
capture confirm file "$root/data/raw/wagepan.csv"
if _rc {
    display as error "data/raw/wagepan.csv not found in $root: set global root above."
    exit 601
}

* The folders that the do-files write to (they may have been deleted for the test)
cap mkdir "$root/data/processed"
cap mkdir "$root/output"
cap mkdir "$root/output/tables"
cap mkdir "$root/output/figures"
cap mkdir "$root/output/logs"
log using "$root/output/logs/master.log", replace text

* The steps, in the order they run: one do-file per step
do "$root/do/01_import.do"      // raw csv -> data/processed/wagepan_imported.dta
do "$root/do/02_clean.do"       // checks, new variables, labels -> wagepan_clean.dta
do "$root/do/03_describe.do"    // Table 1: descriptive statistics
do "$root/do/04_estimate.do"    // Table 2: the wage equation, three models
do "$root/do/05_figures.do"     // Figure 1: mean log wage by years of schooling

display as result "master done: log in output/logs/master.log"
log close

* ---------------------------------------------------------------------
* REPRODUCIBILITY CHECKLIST (before you hand in)
* ---------------------------------------------------------------------
* 1. Delete everything in data/processed and output; run master.do; does everything come back?
* 2. Every number in the text comes from a log or a table produced by your do-files.
* 3. Raw data untouched; one do-file per step; a header on each; comments say WHY.
* 4. Lines that came from an AI tool are marked * AI: and you can explain each of them.
* 5. No names or personal identity numbers anywhere in do-files, logs or tables.
