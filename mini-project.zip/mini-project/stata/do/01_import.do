* =====================================================================
* PURPOSE  Step 1: read the raw file, keep what the question needs, check what one row is.
* INPUTS   data/raw/wagepan.csv
* OUTPUTS  data/processed/wagepan_imported.dta
* HOW      Run from master.do (it sets $root).
* =====================================================================

import delimited "$root/data/raw/wagepan.csv", clear varnames(1)
describe, short                          // expect 4,360 rows

* Keep only the variables the question needs: a smaller file is easier to check
keep nr year lwage educ exper expersq black hisp married union

* What is one row? One man (nr) in one year. isid stops with an error if not.
isid nr year
sort nr year

save "$root/data/processed/wagepan_imported.dta", replace
display "01_import: rows in " _N
