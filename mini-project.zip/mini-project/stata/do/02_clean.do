* =====================================================================
* PURPOSE  Step 2: check the data before using it, make the variables, label them.
* INPUTS   data/processed/wagepan_imported.dta
* OUTPUTS  data/processed/wagepan_clean.dta
* HOW      Run from master.do (it sets $root).
* =====================================================================

use "$root/data/processed/wagepan_imported.dta", clear

* ---- Checks: assert stops the run if a statement is false -------------
* A balanced panel: every man is seen in all eight years, 1980-87
assert inrange(year, 1980, 1987)
bysort nr: assert _N == 8
* Possible values only (schooling in years, experience in years, 0/1 dummies)
assert inrange(educ, 0, 20) & inrange(exper, 0, 30)
assert expersq == exper^2                // the square is what it says it is
foreach v in black hisp married union {
    assert inlist(`v', 0, 1)
}
* No missing values in what goes into the regression
assert !missing(lwage, educ, exper, black, hisp, married, union)

* ---- New variables ----------------------------------------------------
* The hourly wage in dollars, to see the level behind the log
generate wage = exp(lwage)
xtset nr year                            // a panel: men followed over years

* ---- Labels: the tables and figures read them ----------------------------
label variable lwage   "Log hourly wage"
label variable wage    "Hourly wage (USD)"
label variable educ    "Years of schooling"
label variable exper   "Years of work experience"
label variable expersq "Experience squared"
label variable black   "Black (0/1)"
label variable hisp    "Hispanic (0/1)"
label variable married "Married (0/1)"
label variable union   "Union member (0/1)"

save "$root/data/processed/wagepan_clean.dta", replace
bysort nr: generate byte first = (_n == 1)    // 1 on each man's first row
count if first
display "02_clean: rows out " _N ", men " r(N)
drop first
