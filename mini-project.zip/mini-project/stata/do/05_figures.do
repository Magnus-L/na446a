* =====================================================================
* PURPOSE  Step 5: Figure 1, mean log wage by years of schooling: the raw pattern
*          behind the coefficient on educ in Table 2.
* INPUTS   data/processed/wagepan_clean.dta
* OUTPUTS  output/figures/figure1_wage_by_school.png and .pdf
* HOW      Run from master.do (it sets $root).
* =====================================================================

use "$root/data/processed/wagepan_clean.dta", clear

* One point per year of schooling: the mean log wage of the men with that schooling
collapse (mean) lwage (count) n = lwage, by(educ)
list, clean noobs                        // look at the numbers the figure shows

* Grey, so it prints well in black and white; the title states the finding.
* Circle size = number of person-years: the few men with under 9 years of school
* make the left part jumpy, and the reader should see that.
twoway scatter lwage educ [fweight = n], msymbol(Oh) mcolor(gs5) ///
    title("Men with more schooling earn more", size(medium)) ///
    ytitle("Mean log hourly wage") xtitle("Years of schooling") ///
    note("Circle size: number of person-years." ///
         "Source: Vella and Verbeek (1998), 545 men, 1980-87, 4,360 person-years.") ///
    graphregion(color(white)) plotregion(color(white))
graph export "$root/output/figures/figure1_wage_by_school.png", replace width(1600)
graph export "$root/output/figures/figure1_wage_by_school.pdf", replace
display "05_figures: figure1 written"
