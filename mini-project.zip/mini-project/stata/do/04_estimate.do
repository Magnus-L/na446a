* =====================================================================
* PURPOSE  Step 4: Table 2, the wage equation (Mincer): log wage on years of schooling
*          and experience. The coefficient on educ is the percentage wage gain from one
*          more year of school (times 100), comparing men with the same experience.
* INPUTS   data/processed/wagepan_clean.dta
* OUTPUTS  output/tables/table2_regressions.csv (to read), results_long.csv (every number),
*          table2_regressions.docx (for Word)
* HOW      Run from master.do (it sets $root).
* =====================================================================

use "$root/data/processed/wagepan_clean.dta", clear

* Standard errors clustered by man (nr): the same man's eight years are not eight
* independent draws, so ordinary standard errors would be too small.
* (1) the textbook Mincer equation
regress lwage educ exper expersq, vce(cluster nr)
estimates store m1
* (2) plus year dummies: wages rose for everyone over 1980-87 (inflation, the cycle)
regress lwage educ exper expersq i.year, vce(cluster nr)
estimates store m2
* (3) plus background: does schooling only stand in for these?
regress lwage educ exper expersq i.year black hisp married union, vce(cluster nr)
estimates store m3

* ---- results_long.csv: every coefficient at full precision (check_same.py reads it)
file open rl using "$root/output/tables/results_long.csv", write replace
file write rl "model,term,coef,se,p" _n
foreach m in m1 m2 m3 {
    estimates restore `m'
    foreach v in educ exper expersq black hisp married union {
        capture local b = _b[`v']        // a variable not in this model is skipped
        if _rc == 0 {
            local se = _se[`v']
            local p = 2 * ttail(e(df_r), abs(`b' / `se'))
            local b = strtrim(string(`b', "%20.12f"))     // text, without padding
            local se = strtrim(string(`se', "%20.12f"))
            local p = strtrim(string(`p', "%20.12f"))
            file write rl "`m',`v',`b',`se',`p'" _n
        }
    }
    file write rl "`m',N," (e(N)) ",," _n
    local r2 = strtrim(string(e(r2), "%20.12f"))
    file write rl "`m',r2,`r2',," _n
}
file close rl

* ---- table2_regressions.csv: the table as it goes in the thesis --------------
* Coefficient with stars, standard error in brackets below: * p<0.10 ** p<0.05 *** p<0.01
file open t2 using "$root/output/tables/table2_regressions.csv", write replace
file write t2 "row,(1),(2),(3)" _n
foreach v in educ exper expersq black hisp married union {
    local lab : variable label `v'
    local line1 "`lab'"
    local line2 ""
    foreach m in m1 m2 m3 {
        estimates restore `m'
        capture local b = _b[`v']
        if _rc == 0 & `b' != 0 {
            local se = _se[`v']
            local p = 2 * ttail(e(df_r), abs(`b' / `se'))
            local stars = cond(`p' < 0.01, "***", cond(`p' < 0.05, "**", cond(`p' < 0.10, "*", "")))
            local bs = strtrim(string(`b', "%9.4f"))     // 4 decimals, as in the thesis
            local ses = strtrim(string(`se', "%9.4f"))
            local line1 "`line1',`bs'`stars'"
            local line2 "`line2',(`ses')"
        }
        else {
            local line1 "`line1',"
            local line2 "`line2',"
        }
    }
    file write t2 `"`line1'"' _n `"`line2'"' _n
}
file write t2 "Year dummies,no,yes,yes" _n
local nline "Observations"
local rline "R-squared"
foreach m in m1 m2 m3 {
    estimates restore `m'
    local nline "`nline',`e(N)'"
    local r2 = strtrim(string(e(r2), "%9.3f"))
    local rline "`rline',`r2'"
}
file write t2 "`nline'" _n "`rline'" _n
file close t2

* The same table for Word, with Stata's built-in etable
etable, estimates(m1 m2 m3) keep(educ exper expersq black hisp married union) ///
    mstat(N) mstat(r2) showstars showstarsnote ///
    export("$root/output/tables/table2_regressions.docx", replace)
display "04_estimate: table2_regressions.csv written"
