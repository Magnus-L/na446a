* =====================================================================
* PURPOSE  Step 3: Table 1, descriptive statistics. Show the data before the regression.
* INPUTS   data/processed/wagepan_clean.dta
* OUTPUTS  output/tables/table1_descriptives.csv
* HOW      Run from master.do (it sets $root).
* =====================================================================

use "$root/data/processed/wagepan_clean.dta", clear
summarize lwage wage educ exper black hisp married union

* Write one row per variable to a csv file (opens in Excel; paste into Word)
file open t1 using "$root/output/tables/table1_descriptives.csv", write replace
file write t1 "variable,label,mean,sd,min,max,n" _n
foreach v in lwage wage educ exper black hisp married union {
    quietly summarize `v'
    local lab : variable label `v'
    local mean = strtrim(string(r(mean), "%12.4f"))   // 4 decimals, no padding
    local sd = strtrim(string(r(sd), "%12.4f"))
    local min = strtrim(string(r(min), "%12.4f"))
    local max = strtrim(string(r(max), "%12.4f"))
    file write t1 "`v',`lab',`mean',`sd',`min',`max',`r(N)'" _n
}
file close t1
display "03_describe: table1_descriptives.csv written"
