"""Do the Stata and the Python versions give the same numbers?

Run both versions first (stata/master.do and python/run_all.py), then, from this folder:
    python check_same.py        (any Python 3 will do: it needs no packages)
Last printed line: "SAME: Stata and Python agree" (or a list of the differences).

It compares Table 1 and every coefficient, standard error, p-value, N and R-squared in
results_long.csv. Tiny differences (below one in a million) come from Stata storing
the log wage with fewer decimals; they are not differences in the results.
"""
import csv
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOLERANCE = 1e-6

def read(path):
    """Read a csv file into {(first column, second column): the other columns}."""
    with open(path, encoding="utf-8") as f:
        rows = list(csv.reader(f))[1:]               # [1:] skips the header line
    return {(r[0], r[1]): r[2:] for r in rows}

differences = []
for name in ["table1_descriptives.csv", "results_long.csv"]:
    stata_file = HERE / "stata" / "output" / "tables" / name
    python_file = HERE / "python" / "output" / "tables" / name
    for f in [stata_file, python_file]:
        if not f.exists():
            sys.exit(f"Not found: {f.relative_to(HERE)}. Run that version first.")
    stata, python = read(stata_file), read(python_file)
    if stata.keys() != python.keys():
        differences.append(f"{name}: not the same rows")
        continue
    for key in stata:
        for a, b in zip(stata[key], python[key]):
            try:
                gap = abs(float(a) - float(b))
            except ValueError:                       # text or empty: must be equal as text
                gap = 0 if a.strip() == b.strip() else 1
            if gap > TOLERANCE:
                differences.append(f"{name} {key}: Stata {a}, Python {b}")
    print(f"compared {name}: {len(stata)} rows")

if differences:
    print("\n".join(differences))
    sys.exit(f"DIFFERENT: {len(differences)} numbers differ")
print("SAME: Stata and Python agree")
