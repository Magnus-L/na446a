"""Step 2: from monthly SCB answers to one quarterly dataset.

Reads every saved answer in data/raw/scb/ with ONE function, in a loop over the
files; turns months into quarters (the mean of three months, complete quarters
only); computes year-on-year inflation; saves the result to data/processed/.

Run from the lab folder:  uv run scripts/02_clean.py   (or through run_all.py)
Runtime: under 1 second.
Last printed line (29 Sep 2026): "  dropped 84 of 186 quarters with a gap (84 before the unemployment data)"
"""
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "scb"
PROCESSED = ROOT / "data" / "processed"
PROCESSED.mkdir(parents=True, exist_ok=True)


def read_scb(path):
    """Read one saved SCB answer; return a monthly Series with dates as its index."""
    text = path.read_text(encoding="utf-8")           # the file, as text
    answer = json.loads(text)                         # read the JSON (as r.json() did)
    d = pd.DataFrame(answer["data"])                  # its rows -> a dataset
    month = d["key"].str[-1]                          # "2026M08": the LAST item of each key list
    d.index = pd.to_datetime(month, format="%YM%m")   # Stata: gen m = monthly(month, "YM"); tsset m
    values = d["values"].str[0]                       # "124.85": the first item of each list
    return pd.to_numeric(values)                      # Stata: destring; stops on SCB's ".."


def to_quarters(monthly):
    """The mean of the three months of each quarter; complete quarters only.

    The mean is the rule for a price index and a rate. A flow (job ads,
    hours worked) would need the sum; a stock at a date, the last value.
    """
    # Stata: collapse (mean) x (count) months=x, by(q), then keep if months == 3
    quarterly = monthly.resample("QE").mean()         # QE = quarter, labelled by its end date
    n_months = monthly.resample("QE").count()         # months with a value, per quarter
    return quarterly[n_months == 3]                   # keep if months == 3; hand it back


# One function, a loop over the files: two files today, fifty tomorrow
series = {}                                           # a dictionary: one named box per file
rows_in = 0                                           # Stata: local rows_in = 0
for path in sorted(RAW.glob("*.json")):               # Stata: foreach f of local files {
    series[path.stem] = read_scb(path)                # cpi.json -> series["cpi"]
    rows_in = rows_in + len(series[path.stem])        # local rows_in = `rows_in' + _N

monthly = pd.concat(series, axis=1)                   # Stata: merge 1:1 on the date, one column per file
monthly.to_parquet(PROCESSED / "monthly.parquet")     # Stata: save

# Both series to quarters, side by side, matched on the quarter
quarterly = pd.DataFrame({"cpi": to_quarters(monthly["cpi"]),
                          "unemp": to_quarters(monthly["unemp"])})
quarterly["infl"] = quarterly["cpi"].pct_change(4) * 100   # gen infl = 100*(cpi/L4.cpi - 1)
quarterly["infl_lag1"] = quarterly["infl"].shift(1)        # gen infl_lag1 = L.infl
n_quarters = len(quarterly)                                # _N, before the drop
n_no_unemp = quarterly["unemp"].isna().sum()               # count if missing(unemp): for the log

# The regression sample: quarters where every variable is present
quarterly = quarterly.dropna()                             # drop if any variable is missing
quarterly = quarterly.reset_index(names="date")            # the date as a column (for DuckDB)
quarterly.to_parquet(PROCESSED / "quarterly.parquet", index=False)   # Stata: save

first = quarterly["date"].min().to_period("Q")
last = quarterly["date"].max().to_period("Q")
print(f"02_clean.py: {rows_in} monthly values in, {len(quarterly)} quarters out "
      f"({first}-{last})")
print(f"  dropped {n_quarters - len(quarterly)} of {n_quarters} quarters with a gap "
      f"({n_no_unemp} before the unemployment data)")
