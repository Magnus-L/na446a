"""Step 3: one regression table at the end of the pipeline.

Reads data/processed/quarterly.parquet; regresses inflation on unemployment
(a Phillips-curve correlation over time, not a causal effect); writes one table
with two models to output/tables/ as CSV (for Excel and Word) and LaTeX (for papers).

Run from the lab folder:  uv run scripts/03_table.py   (or through run_all.py)
Runtime: about 1 second.
Last printed line (29 Sep 2026): "03_table.py: 102 quarters in, 2 models out (output/tables/regression.*)"
"""
from pathlib import Path

import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.iolib.summary2 import summary_col

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "output" / "tables"
TABLES.mkdir(parents=True, exist_ok=True)

q = pd.read_parquet(ROOT / "data" / "processed" / "quarterly.parquet")   # Stata: use

# HAC (Newey-West) standard errors: the errors of a time series are
# correlated from one quarter to the next, and ordinary SEs ignore that.
# Stata: regress infl unemp, vce(robust) is close; over time: newey infl unemp, lag(4)
m1 = smf.ols("infl ~ unemp", data=q).fit(                  # regress infl unemp, ...
    cov_type="HAC", cov_kwds={"maxlags": 4})               # ... SEs robust over 4 quarters
m2 = smf.ols("infl ~ unemp + infl_lag1", data=q).fit(      # regress infl unemp L.infl, ...
    cov_type="HAC", cov_kwds={"maxlags": 4})

# One table: coefficients with stars (* 10%, ** 5%, *** 1%), SEs in
# parentheses, and a row with each model's N.
t = summary_col([m1, m2], stars=True,                      # Stata: esttab m1 m2, star
                float_format="%.2f")                       # b(%9.2f) se(%9.2f)
t.tables[0].loc["N"] = [str(int(m1.nobs)), str(int(m2.nobs))]   # add a row N: each model's obs
# TODO 3: Stata: esttab m1 m2 using regression.csv (then .tex, .txt)
t.tables[0].to_csv(TABLES / "regression.csv")              # the table as CSV
(TABLES / "regression.tex").write_text(t.as_latex())       # path in brackets, then write into it
(TABLES / "regression.txt").write_text(t.as_text())        # the same, as plain text

print(f"03_table.py: {len(q)} quarters in, 2 models out "
      f"(output/tables/regression.*)")
