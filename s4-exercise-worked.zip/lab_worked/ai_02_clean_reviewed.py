"""SOLUTION to the AI task: the AI's script, reviewed with asserts and fixed.

The AI's version ran without an error and was wrong in three ways. Each assert
below tests a case whose answer we know without trusting the code; each one
stopped the AI's version (checked 29 Sep 2026), and each fix is marked FIXED.

Run from the lab folder (s4-lab) after scripts/01_get_data.py:  uv run ai_02_clean_reviewed.py
Runtime: under 1 second. Last printed line: "AI version done"
"""
# AI: everything from here to the review line came from an AI assistant
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw" / "scb"


def load(path):
    d = pd.DataFrame(json.loads(path.read_text(encoding="utf-8"))["data"])
    d.index = pd.to_datetime(d["key"].str[-1], format="%YM%m")
    return pd.to_numeric(d["values"].str[0])


monthly = pd.concat({p.stem: load(p) for p in sorted(RAW.glob("*.json"))}, axis=1)

# Aggregate to quarterly frequency
# FIXED (bug 1): sum() added up three index levels and three rates, and turned
# the empty quarters before 2001 into an unemployment rate of 0. A price index
# and a rate are averaged.
q = monthly.resample("QE").mean()
# FIXED (bug 2): the latest quarter had only two months; keep complete quarters.
n_months = monthly.resample("QE").count()
q = q[(n_months == 3).all(axis=1)]

# Inflation rate
# FIXED (bug 3): pct_change() compared each quarter with the quarter before
# (a quarterly change, with its seasonal pattern). Year on year needs 4.
q["infl"] = q["cpi"].pct_change(4) * 100

q = q.dropna()
print(q.head(2).round(2))
print(q.tail(3).round(2))

# ---- YOUR REVIEW: at least three asserts below this line ----------------
# 1. Every quarter is built from three months (stopped the AI's version: bug 2)
n_months = monthly["cpi"].resample("QE").count()
assert (n_months.loc[q.index] == 3).all(), "a quarter with fewer than three months"

# 2. An unemployment rate lies between 0 and 100, and Sweden's has never been
#    below 2 or above 20 per cent since 2001 (stopped the AI's version: bug 1,
#    sums of about 24 and the zeros before 2001)
assert q["unemp"].between(2, 20).all(), "unemployment outside 2-20 per cent"

# 3. A case computed by hand: inflation over the year to 2025Q4
#    (stopped the AI's version: bug 3, and also bug 1)
cpi_2025q4 = monthly.loc["2025-10":"2025-12", "cpi"].mean()
cpi_2024q4 = monthly.loc["2024-10":"2024-12", "cpi"].mean()
by_hand = (cpi_2025q4 / cpi_2024q4 - 1) * 100
assert abs(q.loc["2025-12-31", "infl"] - by_hand) < 0.001, "inflation 2025Q4 is wrong"
print(f"Inflation 2025Q4, by hand: {by_hand:.2f}; in q: {q.loc['2025-12-31', 'infl']:.2f}")

# %%
print("AI version done")
