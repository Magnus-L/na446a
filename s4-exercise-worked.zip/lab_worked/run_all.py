"""Rebuild everything, from SCB's API to the regression table, in one go.

Run from the lab folder:  uv run run_all.py
Runtime: 2-6 seconds (under 3 with USE_SAVED = True in scripts/01_get_data.py).
Last printed line: "run_all done: log in output/logs/run_log.txt"

The test of a good project: delete data/processed/ and output/, run this,
and everything comes back. The log records rows in and out of every step.
"""
# ---- CHANGE HERE: the scripts, in the order they run -------------------
SCRIPTS = [                     # TODO 4. Stata: the do lines of master.do, in order
    "scripts/01_get_data.py",
    "scripts/02_clean.py",
    "scripts/03_table.py",
]
# ------------------------------------------------------------------------

import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "output" / "logs"
log = [f"run_all started {datetime.now():%Y-%m-%d %H:%M}"]

for script in SCRIPTS:                              # Stata: foreach, one "do" per script
    # Run each script with the same Python as this one. Its normal output is
    # kept for the log; an error message goes straight to the screen.
    result = subprocess.run([sys.executable, ROOT / script],     # Stata: do 01_get_data.do
                            stdout=subprocess.PIPE, text=True, encoding="utf-8")
    print(result.stdout, end="")                    # show what the script printed
    log.append(result.stdout.strip())               # TODO 5: add it to the log (log using does this itself)
    if result.returncode != 0:                      # stop at the first script that fails, as a do-file does
        log.append(f"STOPPED: {script} failed")
        break

LOGS.mkdir(parents=True, exist_ok=True)
(LOGS / "run_log.txt").write_text("\n".join(log) + "\n", encoding="utf-8")   # Stata: log close
if result.returncode != 0:
    sys.exit(f"STOPPED: {script} failed. Its error message is above.")
print("run_all done: log in output/logs/run_log.txt")
