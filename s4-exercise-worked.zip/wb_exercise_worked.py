"""Exercise after Session 4: a World Bank mini-pipeline. SOLUTION (released after three days).

Fetches GDP per person and unemployment for the five Nordic countries from the
World Bank's open API (no key), page by page; checks that every row arrived;
reads the saved pages with one function in a loop; builds a country-year panel;
computes growth within each country; queries the saved panel with DuckDB; and
saves one small table.

Run it cell by cell in VS Code, or all at once from the lab folder:
    uv run wb_exercise_worked.py
Runtime: 5-15 seconds online (14 requests), 1-2 seconds with USE_SAVED = True.
Last printed line: "Exercise done"
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
USE_SAVED = False                     # True: no network needed, use data/raw/saved/wb/
COUNTRIES = "SWE;FIN;NOR;DNK;ISL"     # ISO3 codes, separated by ;
INDICATORS = {"gdp_pc": "NY.GDP.PCAP.KD",    # GDP per person, constant 2015 US$
              "unemp": "SL.UEM.TOTL.ZS"}     # unemployment, % of labour force (ILO estimate)
# ---------------------------------------------------------------------

# %% Step 0: folders and one helper that gets ONE page (done for you)
import json
from pathlib import Path

import duckdb
import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw" / "wb"                   # the pages, as the API sent them
SAVED = ROOT / "data" / "raw" / "saved" / "wb"       # the backup copy (never written)
PROC = ROOT / "data" / "processed"
TABLES = ROOT / "output" / "tables"
for folder in [RAW, PROC, TABLES]:
    folder.mkdir(parents=True, exist_ok=True)
PER_PAGE = 50                                        # rows per page (the API's default)


def get_page(name, page):
    """Get one page of one indicator, save it in data/raw/wb/, return [meta, rows]."""
    file = f"{name}_p{page}.json"
    if USE_SAVED:
        text = (SAVED / file).read_text(encoding="utf-8")
    else:
        url = f"https://api.worldbank.org/v2/country/{COUNTRIES}/indicator/{INDICATORS[name]}"
        response = requests.get(url, params={"format": "json", "per_page": PER_PAGE,
                                             "page": page}, timeout=30)
        response.raise_for_status()
        text = response.text
    (RAW / file).write_text(text, encoding="utf-8")
    return json.loads(text)


# %% Task 1 (easy): one page, and what it hides
meta, rows = get_page("gdp_pc", 1)
n_first_page = len(rows)
n_total = meta["total"]
print(n_total, meta["pages"], n_first_page)
print(rows[0]["countryiso3code"], rows[-1]["countryiso3code"])   # first and last row
# Answer: 330 rows exist, in 7 pages; page 1 holds 50, all of them Denmark
# (the API sorts by country, newest year first). Stopping here would give a
# "Nordic" dataset with one country, and no error message.


# %% Task 2 (medium): every page, with a check
def get_all_pages(name):
    """Get every page of one indicator; stop if any row is missing; return the row count."""
    meta, rows = get_page(name, 1)
    for page in range(2, meta["pages"] + 1):
        more = get_page(name, page)[1]
        rows = rows + more
    assert len(rows) == meta["total"], f"{name}: {len(rows)} of {meta['total']} rows"
    return len(rows)


for name in INDICATORS:
    print(name, get_all_pages(name))
# Answer: gdp_pc 330, unemp 330.


# %% Task 3 (medium): read the saved pages with one function, in a loop
def read_wb(path):
    """One saved page -> a DataFrame with country, year and value."""
    rows = json.loads(path.read_text(encoding="utf-8"))[1]
    d = pd.json_normalize(rows)                       # one column per field
    d = d[["countryiso3code", "date", "value"]]
    d.columns = ["country", "year", "value"]
    d["year"] = d["year"].astype(int)                 # "2025" -> 2025
    d["value"] = pd.to_numeric(d["value"])            # None -> NaN
    return d


frames = []
for path in sorted(RAW.glob("gdp_pc_p*.json")):
    frames.append(read_wb(path))
gdp = pd.concat(frames, ignore_index=True)
assert not gdp.duplicated(["country", "year"]).any(), "a country-year twice: old pages?"
print(len(gdp), gdp["value"].isna().sum())
# Answer: 330 rows, 0 missing values for GDP per person.


# %% Task 4 (medium): both indicators, one panel
def read_indicator(name):
    """All saved pages of one indicator -> one DataFrame, value renamed to the indicator."""
    frames = []
    for path in sorted(RAW.glob(f"{name}_p*.json")):
        frames.append(read_wb(path))
    d = pd.concat(frames, ignore_index=True)
    return d.rename(columns={"value": name})


panel = read_indicator("gdp_pc").merge(read_indicator("unemp"),
                                       on=["country", "year"], how="outer",
                                       validate="1:1", indicator=True)
print(len(panel))
print(panel["_merge"].value_counts())
print(panel["unemp"].isna().sum())
# Answer: 330 rows, all "both"; 155 missing unemployment values (the ILO series
# starts in 1991, so 1960-1990 is missing for all five countries: 31 x 5 = 155).


# %% Task 5 (hard): growth within each country
panel = panel.sort_values(["country", "year"]).reset_index(drop=True)
panel["growth"] = panel.groupby("country")["gdp_pc"].pct_change() * 100
print(panel["growth"].isna().sum())
print(panel.loc[panel["year"] == 1961, ["country", "growth"]].round(1))
# Answer: 5 missing growth rates, one per country (1960 has no year before it).
# Without groupby there is only 1: Finland's 1960 is compared with Denmark's 2025
# and gets a "growth" of -82.1 per cent. The sort: the API sends the newest
# year first (Task 1). Here the outer merge happened to sort the rows already,
# but a pct_change should never rely on an order it did not set itself.


# %% Task 6 (hard): save the panel, ask DuckDB, save one table
panel = panel.drop(columns="_merge")
panel.to_parquet(PROC / "wb_panel.parquet", index=False)
file = (PROC / "wb_panel.parquet").as_posix()
res = duckdb.sql(f"""
    SELECT country,
           AVG(growth) AS growth,
           AVG(unemp) AS unemp
    FROM '{file}'
    WHERE year BETWEEN 2010 AND 2019
    GROUP BY country
    ORDER BY growth DESC
""").df()
res.round(2).to_csv(TABLES / "wb_nordic_2010s.csv", index=False)
print(res.round(2))
# Answer (data of 29 Sep 2026): Sweden grew fastest in the 2010s (1.45 per cent a
# year), Norway slowest (0.68), with the lowest unemployment (3.74 per cent).

# %% If you finish early: see exercise_s4.md (make this a script in your
# lab pipeline and add it to run_all.py). Not checked by the self-check.

# %%
print("Exercise done")
