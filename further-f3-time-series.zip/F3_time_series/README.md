# F3 Time series: a Phillips curve on Swedish data

Optional self-study for NA446A Part II. Not examined.

**What:** Session 4's quarterly inflation and unemployment series, rebuilt from saved SCB answers; a plot before any regression; default, robust and HAC (Newey–West) standard errors side by side; Durbin–Watson and the ACF of the residuals; what that autocorrelation does to the standard errors; an AR(1) for unemployment with its half-life; the regression in first differences. Every result is a correlation over time, not a causal effect, and the slides say so.

**Data:** SCB's answers of 29 Sep 2026 (CPI since 1980; unemployment rate, ages 15–74, seasonally adjusted, since 2001), the same saved copy as Session 4's lab, in `data/raw/scb/`. No network, no API key.

**Prerequisites:** Session 4 (the SCB API, months to quarters, `pct_change(4)`, the Phillips-curve table).

**Time:** about 60–75 minutes.

## Extra packages

None. Everything uses the course environment (pandas, statsmodels, matplotlib). Tested with statsmodels 0.15.0, pandas 3.0.6, matplotlib 3.11, Python 3.12.

## Files

| File | What |
|---|---|
| `F3.pdf` (source `F3.tex`) | 11 slides: goals, six terms, six steps with real output and two figures, one concept check, readings |
| `f3_script.py` | Reproduces every number and both figures. CHANGE HERE block at the top (Newey–West lags) |
| `f3_stata.do`, `f3_stata.log` | The Stata equivalents, run in StataNow 19.5 (`newey`, `estat dwatson`, `reg unemp L.unemp`) |
| `data/raw/scb/` | SCB's saved answers: `cpi.json`, `unemp.json` and their metadata in `meta/` |
| `figures/f3_series.pdf`, `figures/f3_acf.pdf` | Written by the script |
| `output/quarterly.csv` | The 102 quarters, written by the script, for Stata |
| `build/f3_output.txt` | The script's printout of 30 Sep 2026, for comparison |

## Run

```bash
uv run further/F3_time_series/f3_script.py
```

Runtime about 3 seconds. Last printed line: `f3_script.py done: 102 quarters, 2 figures in figures/`.

## What changed since HT25

The material comes from the HT25 script's optional Phillips-curve section (`intro446a.py`, lines 1706–1794), corrected:

- SCB data saved in the folder instead of FRED, which needed a personal API key and the network.
- `ols.params[0]` on a labelled Series (a `KeyError` in pandas 3) is gone; positions are used only on plain arrays.
- HT25 said Newey–West errors are larger than the usual ones. Here they are smaller (0.18 against 0.24), and the slides show why neither is trustworthy when the residuals' autocorrelation is 0.94: a rough rule puts the standard error nearer 1.0.
- HT25 said the HAC correction makes inference reliable despite a Durbin–Watson statistic near zero. The module says the opposite, and adds the first-difference check.
- No `plt.show()`: figures are saved to files, so the script runs in a terminal.
- No name reused for two things (`df` and `ols` each meant two objects in HT25).

Build the slides: `python3 ../scripts/check_deck.py F3.tex` (zero overfull boxes on 30 Sep 2026).
