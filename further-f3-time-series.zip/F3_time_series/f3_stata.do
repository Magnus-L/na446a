* F3 Time series: the Stata equivalents quoted on the slides.
* Data: output/quarterly.csv, written by f3_script.py from SCB's saved answers.
* Run from this folder:  do f3_stata.do   (StataNow 19.5, 30 Sep 2026; log: f3_stata.log)
version 19
import delimited using "output/quarterly.csv", clear
gen q = qofd(date(date, "YMD"))
format q %tq
tsset q
count                                    // 102
reg infl unemp                           // default se
newey infl unemp, lag(0)                 // HAC 0 = robust (White)
newey infl unemp, lag(4)                 // Newey-West, 4 lags
newey infl unemp, lag(12)
quietly reg infl unemp
estat dwatson                            // Durbin-Watson
reg unemp L.unemp                        // AR(1)
newey D.infl D.unemp, lag(4)             // first differences
