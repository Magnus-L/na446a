"""Further topic F3: time series, a Phillips curve on Swedish data.

Optional self-study for NA446A Part II (not examined). Recycled from the HT25
course script (its optional Phillips-curve section, which used FRED and a
personal API key) and moved to the SCB data of Session 4, saved offline.

What it does, one cell per slide of F3.pdf:
  1. Recap of Session 4: read SCB's saved answers with one function, check
     the months, monthly to quarterly (complete quarters only), inflation.
  2. A figure of both series (figures/f3_series.pdf).
  3. Inflation on unemployment: default, robust and HAC (Newey-West)
     standard errors side by side.
  4. How autocorrelated are the residuals? Durbin-Watson and the ACF
     (figures/f3_acf.pdf), and what that implies for the standard errors.
  5. AR(1) for unemployment: persistence and half-life.
  6. The same regression in first differences.
Everything here is a correlation over time, not a causal effect.

Run from this folder:   uv run f3_script.py     (or: python f3_script.py)
Needs only the course environment (pandas, statsmodels, matplotlib).
Data: SCB's answers of 29 Sep 2026, saved in data/raw/scb/ (no network).
Runtime: about 3 seconds.
Last printed line (30 Sep 2026): "f3_script.py done: 102 quarters, 2 figures in figures/"
"""
# ---- CHANGE HERE (only these lines) ------------------------------------
MAXLAGS = 4               # Newey-West lags; the rule of thumb below gives 4
LAG_GRID = [0, 4, 12]     # step 3: HAC standard errors for these lags
# ------------------------------------------------------------------------

# %% Setup
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")                  # save figures to files, no window
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.stats.stattools import durbin_watson
from statsmodels.tsa.ar_model import AutoReg
from statsmodels.tsa.stattools import acf

try:                                   # the folder this file sits in
    HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    HERE = Path.cwd()
RAW = HERE / "data" / "raw" / "scb"
FIG = HERE / "figures"
OUT = HERE / "output"
FIG.mkdir(exist_ok=True)
OUT.mkdir(exist_ok=True)


def read_scb(path):
    """Read one saved SCB answer; return a monthly Series with dates as its index."""
    d = pd.DataFrame(json.loads(path.read_text(encoding="utf-8"))["data"])
    month = d["key"].str[-1]                          # "2026M08"
    d.index = pd.to_datetime(month, format="%YM%m")   # -> 2026-08-01
    return pd.to_numeric(d["values"].str[0])


def to_quarters(monthly):
    """The mean of the three months of each quarter; complete quarters only.

    The mean is the rule for a price index and a rate; a flow would need the sum.
    """
    quarterly = monthly.resample("QE").mean()
    n_months = monthly.resample("QE").count()
    return quarterly[n_months == 3]


# %% Step 1: recap of Session 4, from saved answers to quarters
monthly = {}
for path in sorted(RAW.glob("*.json")):
    monthly[path.stem] = read_scb(path)
    meta = json.loads((RAW / "meta" / path.name).read_text(encoding="utf-8"))
    months = [v for v in meta["variables"] if v["code"] == "Tid"][0]["values"]
    assert len(monthly[path.stem]) == len(months), f"{path.stem}: months missing"
q = pd.DataFrame({"cpi": to_quarters(monthly["cpi"]),
                  "unemp": to_quarters(monthly["unemp"])})
q["infl"] = q["cpi"].pct_change(4) * 100              # vs the same quarter a year earlier
q = q.dropna()                                        # unemployment starts in 2001
print("=== Step 1: the quarterly data ===")
print(len(q), q.index[0].to_period("Q"), q.index[-1].to_period("Q"))
print(q[["infl", "unemp"]].tail(2).round(2).rename_axis(None))
q.reset_index(names="date").to_csv(OUT / "quarterly.csv", index=False)   # for Stata

# %% Step 2: look at the two series first
fig, axes = plt.subplots(2, 1, figsize=(8, 3.3), sharex=True)
axes[0].plot(q.index, q["infl"], color="black")
axes[0].set_ylabel("Inflation, %")
axes[1].plot(q.index, q["unemp"], color="black", linestyle="--")
axes[1].set_ylabel("Unemployment, %")
for ax in axes:
    ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG / "f3_series.pdf")
plt.close(fig)
print("\n=== Step 2: figure saved: figures/f3_series.pdf ===")

# %% Step 3: the static Phillips regression, three kinds of standard errors
# Default: errors independent and equally variable. HC ("robust"): unequal
# variance allowed. HAC (Newey-West): also correlation over time, up to
# `maxlags` quarters. The coefficient is the same; only its uncertainty changes.
model = smf.ols("infl ~ unemp", data=q)
ses = {"default": model.fit().bse["unemp"]}
for L in LAG_GRID:
    ses[f"HAC {L}"] = model.fit(cov_type="HAC", cov_kwds={"maxlags": L}).bse["unemp"]
ols = model.fit()
print("\n=== Step 3: inflation on unemployment ===")
print("coef:", round(ols.params["unemp"], 3))
print("se:", ", ".join(f"{k} {v:.3f}" for k, v in ses.items()))
T = len(q)
print("Newey-West rule of thumb, floor(4(T/100)^(2/9)):", int(np.floor(4 * (T / 100) ** (2 / 9))))

# %% Step 4: how autocorrelated are the residuals?
rho_u = ols.resid.autocorr(1)                         # residual today vs last quarter
rho_x = q["unemp"].autocorr(1)
print("\n=== Step 4: residual autocorrelation ===")
print("Durbin-Watson:", round(durbin_watson(ols.resid), 2),
      "| lag-1 autocorrelation: residuals", round(rho_u, 2), "unemp", round(rho_x, 2))
print("ACF of residuals, lags 1-8:", acf(ols.resid, nlags=8)[1:].round(2).tolist())
# Back of the envelope (x and error both AR(1)): the default variance is too
# small by the factor (1 + rho_x * rho_u) / (1 - rho_x * rho_u).
factor = np.sqrt((1 + rho_x * rho_u) / (1 - rho_x * rho_u))
print("implied se:", round(ses["default"] * factor, 2), f"(default x {factor:.1f})")

fig, axes = plt.subplots(1, 2, figsize=(9, 2.4))
grey = {"color": "black", "vlines_kwargs": {"colors": "black"}}
plot_acf(q["unemp"], lags=12, ax=axes[0], title="Unemployment", **grey)
plot_acf(ols.resid, lags=12, ax=axes[1], title="Residuals", **grey)
for ax in axes:
    for band in ax.collections:                       # the 95% band: light grey
        band.set_facecolor("0.5")
    ax.set_xlabel("Lag (quarters)")
    ax.spines[["top", "right"]].set_visible(False)
fig.tight_layout()
fig.savefig(FIG / "f3_acf.pdf")
plt.close(fig)

# %% Step 5: AR(1) for unemployment (Stata: reg unemp L.unemp)
ar1 = AutoReg(q["unemp"].to_numpy(), lags=1).fit()
rho = ar1.params[1]
print("\n=== Step 5: AR(1) for unemployment ===")
print("rho:", round(rho, 3), "| se:", round(ar1.bse[1], 3),
      "| after 4 quarters:", round(rho ** 4, 2),
      "| half-life, quarters:", round(np.log(0.5) / np.log(rho), 1))

# %% Step 6: the same regression in first differences
dq = q[["infl", "unemp"]].diff().dropna()            # change from last quarter
fd = smf.ols("infl ~ unemp", data=dq).fit(cov_type="HAC", cov_kwds={"maxlags": MAXLAGS})
print("\n=== Step 6: first differences ===")
print("coef:", round(fd.params["unemp"], 3), "| HAC se:", round(fd.bse["unemp"], 3),
      "| N:", int(fd.nobs), "| lag-1 autocorrelation of residuals:",
      round(fd.resid.autocorr(1), 2))

print(f"\nf3_script.py done: {len(q)} quarters, 2 figures in figures/")
