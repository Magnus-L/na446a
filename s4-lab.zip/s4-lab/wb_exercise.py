"""Exercise after Session 4: a World Bank mini-pipeline (formative, no hand-in).

Fetch GDP per person and unemployment for the five Nordic countries from the
World Bank's open API (no key), page by page; check that every row arrived;
read the saved pages with one function in a loop; build a country-year panel;
compute growth within each country; ask DuckDB; save one small table.

The tasks and their times are on the exercise page of the course site (Sessions, Session 4). Fill in every TODO and keep
the names it gives (n_first_page, get_all_pages, read_wb, gdp, panel, res):
the self-check looks for them. Before you run a cell, write down what you expect.

Check your work at any time:  uv run check_exercise_s4.py
Run it cell by cell in VS Code, or all at once:  uv run wb_exercise.py
Runtime: 5-15 seconds online (14 requests), 1-2 seconds with USE_SAVED = True.
Last printed line: "Exercise done"
AI rule: lines that came from an AI get the comment  # AI:
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
# After a change: run this cell again, then the step that uses it.
USE_SAVED = False                     # True: no network needed, use data/raw/saved/wb/
COUNTRIES = "SWE;FIN;NOR;DNK;ISL"     # ISO3 codes, separated by ; (the saved copy has these five)
INDICATORS = {"gdp_pc": "NY.GDP.PCAP.KD",    # GDP per person, constant 2015 US$
              "unemp": "SL.UEM.TOTL.ZS"}     # unemployment, % of labour force (ILO estimate)
# ---------------------------------------------------------------------

# %% Step 0: folders and one helper that gets ONE page (done for you)
import json
from pathlib import Path

import duckdb
try:
    import pandas as pd
except ModuleNotFoundError:            # VS Code is using another Python, not the course's .venv
    raise SystemExit("pandas not found: VS Code is not using the course Python. Put this lab "
                     "folder inside na446a-starter, open na446a-starter in VS Code (File > Open "
                     "Folder), choose Python: Select Interpreter > .venv, then Restart. "
                     "See 'Common problems in class' on the Setup page.")
import requests

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE
RAW = ROOT / "data" / "raw" / "wb"                   # the pages, as the API sent them
SAVED = ROOT / "data" / "raw" / "saved" / "wb"       # the backup copy (never written)
PROC = ROOT / "data" / "processed"
TABLES = ROOT / "output" / "tables"
for folder in [RAW, PROC, TABLES]:
    folder.mkdir(parents=True, exist_ok=True)
PER_PAGE = 50                                        # rows per page (the API's default)


def get_page(name, page):
    """Get one page of one indicator, save it in data/raw/wb/, return [meta, rows]."""
    file = f"{name}_p{page}.json"
    if USE_SAVED:
        text = (SAVED / file).read_text(encoding="utf-8")
    else:
        url = f"https://api.worldbank.org/v2/country/{COUNTRIES}/indicator/{INDICATORS[name]}"
        response = requests.get(url, params={"format": "json", "per_page": PER_PAGE,
                                             "page": page}, timeout=30)
        response.raise_for_status()
        text = response.text
    (RAW / file).write_text(text, encoding="utf-8")
    return json.loads(text)


# %% Task 1 (easy): one page, and what it hides
meta, rows = get_page("gdp_pc", 1)
# Predict first: 5 countries, 1960-2025. How many rows exist? How many are in `rows`?
# TODO 1: n_first_page = the number of rows on this page; n_total = meta["total"].
#   Print n_total, meta["pages"] and n_first_page. Then print the country of the
#   first and the last row (rows[0]["countryiso3code"], rows[-1][...]).
n_first_page = ...
n_total = ...

# Your answer: which countries does page 1 contain, and why is that dangerous? ...


# %% Task 2 (medium): every page, with a check
# TODO 2: complete get_all_pages(name). Get page 1 (it tells you the number of
#   pages), then a for loop over the other pages that adds their rows to `rows`.
#   End with an assert that stops if len(rows) differs from meta["total"],
#   and return len(rows).
def get_all_pages(name):
    """Get every page of one indicator; stop if any row is missing; return the row count."""
    meta, rows = get_page(name, 1)
    ...


for name in INDICATORS:
    print(name, get_all_pages(name))


# %% Task 3 (medium): read the saved pages with one function, in a loop
# TODO 3a: complete read_wb(path): one saved page -> a DataFrame with the
#   columns country, year (an int) and value (a number). Hint: the rows are
#   json.loads(...)[1]; pd.json_normalize(rows) makes one column per field;
#   you need countryiso3code, date and value.
def read_wb(path):
    """One saved page -> a DataFrame with country, year and value."""
    ...


# TODO 3b: loop over sorted(RAW.glob("gdp_pc_p*.json")), read each with read_wb,
#   and stack them into `gdp` (pd.concat, ignore_index=True). Then assert that no
#   country-year appears twice, and print the rows and the missing values.
gdp = ...


# %% Task 4 (medium): both indicators, one panel
# TODO 4: write read_indicator(name) (Task 3b as a function, with "value"
#   renamed to name), then `panel` = gdp_pc merged with unemp on country and
#   year: how="outer", validate="1:1", indicator=True. Print the rows, the
#   _merge counts and the number of missing unemployment values.
panel = ...

# Your answer: why are so many unemployment values missing? ...


# %% Task 5 (hard): growth within each country
# Predict first: in which order did the API send the years?
# TODO 5: sort panel by country and year, then panel["growth"] = the yearly
#   percentage change of gdp_pc WITHIN each country (groupby + pct_change).
#   Print the number of missing growth values.

# Your answer: why exactly that many missing? What would go wrong without the
# sort, and without the groupby? ...


# %% Task 6 (hard): save the panel, ask DuckDB, save one table
# TODO 6: drop the _merge column; save panel to PROC / "wb_panel.parquet";
#   then `res` = a DuckDB query on that FILE giving, per country, the mean growth
#   and the mean unemployment over 2010-2019, fastest growth first (.df() at the
#   end). Save res.round(2) to TABLES / "wb_nordic_2010s.csv" (index=False).
#   Hint: file = (PROC / "wb_panel.parquet").as_posix(), then FROM '{file}'.
res = ...

# Your answer: which country grew fastest in the 2010s? ...

# %% If you finish early: see the exercise page on the course site (make this a script in your
# lab pipeline and add it to run_all.py). Not checked by the self-check.

# %%
print("Exercise done")
