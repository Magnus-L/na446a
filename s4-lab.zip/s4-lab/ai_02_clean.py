"""Session 4 lab, the AI task: review an AI's pipeline with asserts.

A student asked an AI assistant: "Write a Python script that reads the SCB
answers in data/raw/scb/ and gives quarterly unemployment and year-on-year
inflation." This is what came back. It runs without an error.

Your job (about 10 minutes, in your pair):
  1. Run it after scripts/01_get_data.py has run (it reads data/raw/scb/).
     Look at the printed rows. Does anything look odd?
  2. Below the marked line, write at least THREE asserts, each testing a case
     where you know the answer without trusting the code. Ideas:
       - how many months should every quarter have?
       - what range can an unemployment rate have?
       - inflation over the year to 2025Q4, computed by hand from the monthly
         CPI (mean of Oct-Dec 2025 against the mean of Oct-Dec 2024)
  3. Run again: an assert that stops the script has caught a bug. Name the bug
     in a comment, fix the line above, and rerun until every assert passes.

The script writes nothing to disk, so you cannot damage the pipeline.
Runtime: under 1 second. Last printed line: "AI version done"
"""
# AI: everything from here to the review line came from an AI assistant
import json
from pathlib import Path

import pandas as pd

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE
RAW = ROOT / "data" / "raw" / "scb"


def load(path):
    d = pd.DataFrame(json.loads(path.read_text(encoding="utf-8"))["data"])
    d.index = pd.to_datetime(d["key"].str[-1], format="%YM%m")
    return pd.to_numeric(d["values"].str[0])


monthly = pd.concat({p.stem: load(p) for p in sorted(RAW.glob("*.json"))}, axis=1)

# Aggregate to quarterly frequency
q = monthly.resample("QE").sum()

# Inflation rate
q["infl"] = q["cpi"].pct_change() * 100

q = q.dropna()
print(q.head(2).round(2))
print(q.tail(3).round(2))

# ---- YOUR REVIEW: at least three asserts below this line ----------------


# %%
print("AI version done")
