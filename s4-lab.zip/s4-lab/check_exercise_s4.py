"""Self-check for the World Bank exercise: which of your tasks are right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_exercise_s4.py                  checks wb_exercise.py
    uv run check_exercise_s4.py my_copy.py       checks another file

It runs your script cell by cell (a cell that fails is reported and skipped,
so one error does not hide the rest), then recomputes the right answers from
the pages your script saved in data/raw/wb/ and compares. It never changes
your script. Runtime: 5-15 seconds online, about 2 seconds with USE_SAVED = True.
Last printed line: "N of 6 tasks right." (all right: "6 of 6 tasks right.")
"""
import contextlib
import io
import json
import sys
import time
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent


def run_cells(script: Path) -> dict:
    """Run a # %% script cell by cell in one namespace, as VS Code does."""
    ns = {"__file__": str(script), "__name__": "__exercise__"}
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:        # a new cell starts here
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    for i, cell in enumerate(cells):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
    return ns


def expected(raw: Path):
    """The right answers, computed here from the saved pages (not from your code)."""
    meta = json.loads((raw / "gdp_pc_p1.json").read_text(encoding="utf-8"))[0]
    long = {}
    for name in ["gdp_pc", "unemp"]:
        rows = []
        for page in range(1, meta["pages"] + 1):
            rows += json.loads((raw / f"{name}_p{page}.json").read_text(encoding="utf-8"))[1]
        long[name] = pd.DataFrame({"country": [r["countryiso3code"] for r in rows],
                                   "year": [int(r["date"]) for r in rows],
                                   name: [r["value"] for r in rows]})
    panel = long["gdp_pc"].merge(long["unemp"], on=["country", "year"], how="outer")
    panel[["gdp_pc", "unemp"]] = panel[["gdp_pc", "unemp"]].astype(float)
    panel = panel.sort_values(["country", "year"]).reset_index(drop=True)
    panel["growth"] = panel.groupby("country")["gdp_pc"].pct_change() * 100
    s = panel[panel["year"].between(2010, 2019)].groupby("country")[["growth", "unemp"]].mean()
    return meta, panel, s.sort_values("growth", ascending=False)


def main() -> None:
    script = HERE / (sys.argv[1] if len(sys.argv) > 1 else "wb_exercise.py")
    print(f"Checking {script.name} ...\n")
    with contextlib.redirect_stdout(io.StringIO()) as quiet:   # hide your prints
        started = time.time()                          # files must be written by THIS run
        ns = run_cells(script)
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    root = Path(ns.get("ROOT", HERE))                  # the folder your script works in
    raw = root / "data" / "raw" / "wb"
    results = []

    def written(path):
        return path.stat().st_mtime >= started - 1

    def task(name, test, hint):
        """Run one check; print OK or a hint, never crash."""
        try:
            passed = bool(test())
        except Exception:
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    try:
        meta = json.loads((raw / "gdp_pc_p1.json").read_text(encoding="utf-8"))[0]
    except Exception:
        meta = None
    try:
        meta, panel_ok, table_ok = expected(raw)
    except Exception:
        panel_ok = table_ok = None
        print("(Could not read all pages in data/raw/wb/: Task 2 saves them.)\n")

    task("Task 1  one page: n_first_page and n_total",
         lambda: ns["n_first_page"] == 50 and ns["n_total"] == meta["total"],
         "n_first_page = len(rows); n_total = meta[\"total\"].")

    def task2():
        lines = script.read_text(encoding="utf-8").splitlines()
        start = [i for i, ln in enumerate(lines) if ln.startswith("def get_all_pages")][0]
        body = []
        for ln in lines[start + 1:]:
            if ln.strip() and not ln.startswith((" ", "\t")):
                break                                  # the function ends here
            if not ln.strip().startswith("#"):
                body.append(ln)
        source = "\n".join(body)
        files = [raw / f"{n}_p{p}.json" for n in ["gdp_pc", "unemp"]
                 for p in range(1, meta["pages"] + 1)]
        return "assert" in source and "for " in source and all(written(f) for f in files)
    task("Task 2  get_all_pages: every page saved, with an assert on the count",
         task2,
         "loop over range(2, meta[\"pages\"] + 1), add each page's rows, and "
         "assert len(rows) == meta[\"total\"].")

    def task3():
        gdp = ns["gdp"]
        return (len(gdp) == meta["total"] and list(gdp.columns) == ["country", "year", "value"]
                and pd.api.types.is_integer_dtype(gdp["year"])
                and pd.api.types.is_float_dtype(gdp["value"])
                and not gdp.duplicated(["country", "year"]).any())
    task("Task 3  read_wb in a loop: `gdp` with country, year (int) and value",
         task3,
         "read_wb returns the three columns; year with .astype(int); value with "
         "pd.to_numeric; concat the pages with ignore_index=True.")

    def task4():
        p = ns["panel"]
        return (len(p) == len(panel_ok)
                and {"country", "year", "gdp_pc", "unemp"} <= set(p.columns)
                and p["unemp"].isna().sum() == panel_ok["unemp"].isna().sum())
    task("Task 4  `panel`: both indicators, one row per country and year",
         task4,
         "read_indicator(name) renames value to name; merge on [\"country\", \"year\"] "
         "with how=\"outer\", validate=\"1:1\".")

    def task5():
        p = ns["panel"].sort_values(["country", "year"]).reset_index(drop=True)
        diff = (p["growth"] - panel_ok["growth"]).abs()
        return (p["growth"].isna().sum() == panel_ok["growth"].isna().sum()
                and diff.max() < 1e-9)
    task("Task 5  growth within each country, oldest year first",
         task5,
         "sort by country and year first; then panel.groupby(\"country\")[\"gdp_pc\"]"
         ".pct_change() * 100.")

    def task6():
        res = ns["res"].set_index("country")
        file = root / "data" / "processed" / "wb_panel.parquet"
        csv = root / "output" / "tables" / "wb_nordic_2010s.csv"
        return (written(file) and written(csv)
                and list(res.index) == list(table_ok.index)
                and (res["growth"] - table_ok["growth"]).abs().max() < 1e-9
                and (res["unemp"] - table_ok["unemp"]).abs().max() < 1e-9)
    task("Task 6  saved panel, DuckDB query and the table",
         task6,
         "AVG(growth) and AVG(unemp) per country, WHERE year BETWEEN 2010 AND 2019, "
         "ORDER BY growth DESC; save the csv.")

    print(f"\n{sum(results)} of {len(results)} tasks right.")


if __name__ == "__main__":
    main()
