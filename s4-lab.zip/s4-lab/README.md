# Swedish inflation and unemployment: a mini-pipeline (Session 4 lab)

Quarterly year-on-year inflation regressed on the unemployment rate, Sweden 2001–2026,
from Statistics Sweden's open API to one regression table. A correlation over time, not a
causal effect.

## Get started

1. Unzip `s4-lab.zip` and put the folder `s4-lab` inside your course folder (`na446a-starter`).
2. Open `na446a-starter` in VS Code (File → Open Folder; the course folder, never `s4-lab` on its
   own), then open the files in `s4-lab` from the Explorer.
3. The lab's scripts run whole, with no cells: open one and press ▷ (Run Python File); the output
   is in the terminal at the bottom. Or type in the terminal `cd s4-lab` once (the terminal starts
   in `na446a-starter`), then the commands below.
4. **In class:** TODO 1 in `scripts/01_get_data.py`, then TODOs 2a–2d in `scripts/02_clean.py`.
   Each TODO has the Stata line you would write just above it; you write the Python. If time, the
   AI task (`ai_02_clean.py`). **At home:** TODOs 3–5 (`scripts/03_table.py`, `run_all.py`), then
   the self-check `uv run check_s4.py` (all right is all steps right).

## How to rerun

    uv run run_all.py

Runs, in order:

1. `scripts/01_get_data.py`: asks SCB's API for the monthly CPI and the monthly unemployment
   rate (seasonally adjusted, ages 15–74), saves both answers as they came in `data/raw/scb/`
   and checks that every month arrived.
2. `scripts/02_clean.py`: reads every saved answer with one function (`read_scb`), turns months
   into quarters (the mean of three months, complete quarters only), computes year-on-year
   inflation, and writes `data/processed/monthly.parquet` and `data/processed/quarterly.parquet`.
3. `scripts/03_table.py`: two OLS models with HAC standard errors, one table in
   `output/tables/regression.csv`, `.tex` and `.txt`.

Rows in and out of every step: `output/logs/run_log.txt`. Runtime 2–6 seconds (the very first
run can take up to half a minute while Python prepares its packages).

**No network?** Set `USE_SAVED = True` in the CHANGE HERE block of `scripts/01_get_data.py`.
The pipeline then uses `data/raw/saved/scb/`, SCB's answers as fetched on 29 Sep 2026, and runs
the same way.

**The delete-outputs test:** delete `data/processed/` and `output/`, run `run_all.py`, and
everything comes back. `check_s4.py` does exactly this.

## Data

- SCB table PR0101A/KPI2020M, series 00000807: consumer price index, 2020 = 100, monthly from
  January 1980.
- SCB table AM0401A/AKURLBefM: unemployment rate, per cent, seasonally adjusted, ages 15–74,
  monthly from January 2001 (Labour Force Survey).
- `data/raw/saved/`: the backup copy of both answers (and of the World Bank pages for the
  exercise), fetched 29 Sep 2026. Never written by code.

## Also in this folder

- `ai_02_clean.py`: an AI's version of step 2, to review with asserts (the lab's AI task).
- `check_s4.py`: the self-check for the lab (`uv run check_s4.py`).
- `wb_exercise.py`, `check_exercise_s4.py`: the exercise after the session (text on the course site, Sessions page).
