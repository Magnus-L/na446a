"""Session 4 lab: fill in TODOs 4 and 5.

Rebuild everything, from SCB's API to the regression table, in one go.

Run from the lab folder:  uv run run_all.py
Runtime: 2-6 seconds (under 3 with USE_SAVED = True in scripts/01_get_data.py).
Last printed line: "run_all done: log in output/logs/run_log.txt"

The test of a good project: delete data/processed/ and output/, run this,
and everything comes back. The log records rows in and out of every step.
"""
# ---- CHANGE HERE: the scripts, in the order they run -------------------
SCRIPTS = [
    # TODO 4 [slides: "One script rebuilds everything"]: the three scripts, as "scripts/....py", in the order they run
]
# ------------------------------------------------------------------------

import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "output" / "logs"
log = [f"run_all started {datetime.now():%Y-%m-%d %H:%M}"]

result = None
for script in SCRIPTS:
    # Run each script with the same Python as this one. Its normal output is
    # kept for the log; an error message goes straight to the screen.
    result = subprocess.run([sys.executable, ROOT / script],
                            stdout=subprocess.PIPE, text=True, encoding="utf-8")
    print(result.stdout, end="")
    # TODO 5: add what the script printed (result.stdout, without the last
    #   newline: .strip()) to the list `log`

    if result.returncode != 0:                      # stop at the first script that fails
        log.append(f"STOPPED: {script} failed")
        break

LOGS.mkdir(parents=True, exist_ok=True)
(LOGS / "run_log.txt").write_text("\n".join(log) + "\n", encoding="utf-8")
if result is None:
    sys.exit("SCRIPTS is empty: do TODO 4 first.")
if result.returncode != 0:
    sys.exit(f"STOPPED: {script} failed. Its error message is above.")
print("run_all done: log in output/logs/run_log.txt")
