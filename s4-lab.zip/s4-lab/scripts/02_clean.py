"""Session 4 lab: fill in TODOs 2a to 2d (in class).

Step 2: from monthly SCB answers to one quarterly dataset.

Reads every saved answer in data/raw/scb/ with ONE function, in a loop over the
files; turns months into quarters (the mean of three months, complete quarters
only); computes year-on-year inflation; saves the result to data/processed/.

Run the whole file with the play button (Run Python File), after 01_get_data.py:
it always starts from the top. Or, from the lab folder:  uv run scripts/02_clean.py
Runtime: under 1 second.
Last printed line (29 Sep 2026): "  dropped 84 of 186 quarters with a gap (84 before the unemployment data)"
"""
import json
from pathlib import Path

import pandas as pd

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE.parent
RAW = ROOT / "data" / "raw" / "scb"
PROCESSED = ROOT / "data" / "processed"
PROCESSED.mkdir(parents=True, exist_ok=True)


def read_scb(path):
    """Read one saved SCB answer; return a monthly Series with dates as its index."""
    text = path.read_text(encoding="utf-8")           # the file, as text
    answer = json.loads(text)                         # read the JSON (as r.json() did)
    d = pd.DataFrame(answer["data"])                  # its rows -> a dataset
    month = d["key"].str[-1]                          # "2026M08": the LAST item of each key list
    # Stata: gen m = monthly(month, "YM")
    # TODO 2a [slides: Step 4]: turn `month` ("2026M08") into real dates and make them the index
    #   (pd.to_datetime with a format; see Step 4 on the slides)
    d.index = ...
    values = d["values"].str[0]                       # "124.85": the first item of each list
    return pd.to_numeric(values)                      # Stata: destring; stops on SCB's ".."


def to_quarters(monthly):
    """The mean of the three months of each quarter; complete quarters only.

    The mean is the rule for a price index and a rate. A flow (job ads,
    hours worked) would need the sum; a stock at a date, the last value.
    """
    # Stata: collapse (mean) x (count) months=x, by(q), then keep if months == 3
    # TODO 2b [slides: Step 5]: the mean of each quarter ("QE"), the number of months in each
    #   quarter, and return only the quarters with all three months (Step 5)
    return ...


# One function, a loop over the files: two files today, fifty tomorrow
series = {}
rows_in = 0
# Stata: foreach f in cpi unemp { ... }   (the loop from Session 3)
# TODO 2c [slides: Steps 7-8]: loop over sorted(RAW.glob("*.json")). For each path, put
#   read_scb(path) into series[path.stem] (cpi.json -> series["cpi"]) and add
#   its number of rows to rows_in.


monthly = pd.concat(series, axis=1)                   # Stata: merge 1:1 on the date, one column per file
monthly.to_parquet(PROCESSED / "monthly.parquet")

quarterly = pd.DataFrame({"cpi": to_quarters(monthly["cpi"]),
                          "unemp": to_quarters(monthly["unemp"])})
# Stata: tsset q, then gen infl = 100*(cpi/L4.cpi - 1)
# TODO 2d [slides: Step 6]: inflation in per cent, each quarter against the same quarter a year earlier
quarterly["infl"] = ...
quarterly["infl_lag1"] = quarterly["infl"].shift(1)        # last quarter's inflation: L.infl
n_quarters = len(quarterly)
n_no_unemp = quarterly["unemp"].isna().sum()               # for the log: why rows go

# The regression sample: quarters where every variable is present
quarterly = quarterly.dropna()                             # drop if any variable is missing
quarterly = quarterly.reset_index(names="date")            # the date as a column (for DuckDB)
quarterly.to_parquet(PROCESSED / "quarterly.parquet", index=False)

first = quarterly["date"].min().to_period("Q")
last = quarterly["date"].max().to_period("Q")
print(f"02_clean.py: {rows_in} monthly values in, {len(quarterly)} quarters out "
      f"({first}-{last})")
print(f"  dropped {n_quarters - len(quarterly)} of {n_quarters} quarters with a gap "
      f"({n_no_unemp} before the unemployment data)")
