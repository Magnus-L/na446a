"""Session 4 lab: fill in TODO 1 (in class).

Step 1: get the raw data from Statistics Sweden (SCB). Writes data/raw/scb/.

Fetches two monthly series from SCB's open API (no key needed): the consumer
price index (CPI) and the unemployment rate. For each series it asks what the
table holds (the metadata), asks for the data, saves both answers exactly as
they came, and checks that every month the table lists has arrived.

No network, or SCB's API is down? Set USE_SAVED = True. The script then takes
SCB's answers from the copy saved in data/raw/saved/scb/ (fetched 29 Sep 2026),
and every later step runs the same way.

Run the whole file with the play button (Run Python File): it always starts from
the top, so nothing is forgotten. Or, from the lab folder:  uv run scripts/01_get_data.py
Runtime: 1-5 seconds online, under 1 second with the saved copy.
Last printed line (29 Sep 2026): "01_get_data.py: cpi 560/560 months, unemp 308/308 months (SCB API)"
Run it today and you get one or two months more: SCB adds a month every month.
"""
# ---- CHANGE HERE (only these lines) ------------------------------------
USE_SAVED = False          # True: no network needed, use data/raw/saved/scb/
SERIES = {                 # name: (SCB table, the one value to keep of each variable)
    "cpi": ("PR/PR0101/PR0101A/KPI2020M",
            {"ContentsCode": "00000807"}),        # CPI, every month since 1980
    "unemp": ("AM/AM0401/AM0401A/AKURLBefM",
              {"Arbetskraftstillh": "ALÖSP",      # unemployment rate, per cent
               "TypData": "SR_DATA",              # seasonally adjusted
               "Kon": "1+2",                      # women and men
               "Alder": "tot15-74",               # everyone aged 15-74
               "ContentsCode": "000007L9"}),
}
# ------------------------------------------------------------------------

import json
import time
from pathlib import Path

import requests

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE.parent          # the lab folder
RAW = ROOT / "data" / "raw" / "scb"                 # SCB's answers, as they came
SAVED = ROOT / "data" / "raw" / "saved" / "scb"     # the backup copy (never written)
API = "https://api.scb.se/OV0104/v1/doris/en/ssd/"
(RAW / "meta").mkdir(parents=True, exist_ok=True)


# The two functions below send the requests of Steps 1 and 2 on the slides. You need not
# read them line by line: ask() asks and waits if SCB is busy; get_answers() builds the
# QUERY for one table and returns SCB's two answers as text.
def ask(method, url, **options):
    """Send one request to SCB; wait and retry if SCB says 'too many requests'.

    SCB allows only a few calls per address every 10 seconds. A classroom
    shares one address, so a 429 answer ("too many requests") is likely:
    wait, then ask again, at most three times.
    """
    for attempt in range(3):
        response = requests.request(method, url, timeout=30, **options)
        if response.status_code != 429:
            break
        time.sleep(10)
    response.raise_for_status()                     # stop here if the server said no
    return response.text


def get_answers(table, pick):
    """Ask SCB for the metadata and the data of one table; return both as text."""
    url = API + table
    meta_text = ask("GET", url)                     # what the table holds
    query = []
    for code, value in pick.items():                # one value of each variable ...
        query.append({"code": code,
                      "selection": {"filter": "item", "values": [value]}})
    query.append({"code": "Tid",                    # ... and every month ("*")
                  "selection": {"filter": "all", "values": ["*"]}})
    data_text = ask("POST", url, json={"query": query, "response": {"format": "json"}})
    return meta_text, data_text


report = []
for name, (table, pick) in SERIES.items():
    if USE_SAVED:
        meta_text = (SAVED / "meta" / f"{name}.json").read_text(encoding="utf-8")
        data_text = (SAVED / f"{name}.json").read_text(encoding="utf-8")
    else:
        meta_text, data_text = get_answers(table, pick)

    # Save both answers exactly as they came: this is the raw data. f"{name}.json" is the
    # text with name filled in, as "`name'.json" in Stata
    (RAW / "meta" / f"{name}.json").write_text(meta_text, encoding="utf-8")
    (RAW / f"{name}.json").write_text(data_text, encoding="utf-8")

    # The check people skip: did every month the table lists arrive?
    for variable in json.loads(meta_text)["variables"]:   # foreach variable in the metadata
        if variable["code"] == "Tid":               # Tid = time: keep its list of months
            months = variable["values"]
    rows = json.loads(data_text)["data"]
    # Stata: assert _N == 560
    # TODO 1 (in class) [slides: Step 3]: write ONE line that stops the script, with a clear message, if the
    #   number of rows differs from the number of months: assert ..., "..."
    #   Predict first: how many months does the CPI table list today?

    report.append(f"{name} {len(rows)}/{len(months)} months")

source = "saved copy" if USE_SAVED else "SCB API"
print(f"01_get_data.py: {', '.join(report)} ({source})")
