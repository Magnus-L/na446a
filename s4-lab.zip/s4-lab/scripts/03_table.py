"""Session 4 lab: fill in TODO 3 (at home).

Step 3: one regression table at the end of the pipeline.

Reads data/processed/quarterly.parquet; regresses inflation on unemployment
(a Phillips-curve correlation over time, not a causal effect); writes one table
with two models to output/tables/ as CSV (for Excel and Word) and LaTeX (for papers).

Run from the lab folder:  uv run scripts/03_table.py   (or through run_all.py)
Runtime: about 1 second.
Last printed line (29 Sep 2026): "03_table.py: 102 quarters in, 2 models out (output/tables/regression.*)"
"""
from pathlib import Path

import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.iolib.summary2 import summary_col

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE.parent
TABLES = ROOT / "output" / "tables"
TABLES.mkdir(parents=True, exist_ok=True)

q = pd.read_parquet(ROOT / "data" / "processed" / "quarterly.parquet")

# HAC (Newey-West) standard errors: the errors of a time series are
# correlated from one quarter to the next, and ordinary SEs ignore that.
m1 = smf.ols("infl ~ unemp", data=q).fit(
    cov_type="HAC", cov_kwds={"maxlags": 4})
m2 = smf.ols("infl ~ unemp + infl_lag1", data=q).fit(
    cov_type="HAC", cov_kwds={"maxlags": 4})

# One table: coefficients with stars (* 10%, ** 5%, *** 1%), SEs in
# parentheses, and a row with each model's N.
t = summary_col([m1, m2], stars=True,
                float_format="%.2f")
t.tables[0].loc["N"] = [str(int(m1.nobs)), str(int(m2.nobs))]
# Stata: esttab m1 m2 using regression.csv, se   (and again with .tex)
# TODO 3 [slides: Step 10]: save the table t three times in output/tables/: regression.csv
#   (t.tables[0].to_csv), regression.tex (write t.as_latex()) and
#   regression.txt (write t.as_text()); see Step 10 on the slides.
#   Predict first: does the coefficient on unemp shrink in model (2)? Why?


print(f"03_table.py: {len(q)} quarters in, 2 models out "
      f"(output/tables/regression.*)")
