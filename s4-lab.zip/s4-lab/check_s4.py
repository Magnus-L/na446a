"""Self-check for the Session 4 lab: does your pipeline rebuild, and is it right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_s4.py              checks this lab folder
    uv run check_s4.py solution     checks another project folder

What it does, in order:
  1. The delete-outputs test: it DELETES data/processed/ and output/ in the
     project (everything there is rebuilt by code; data/raw/ is never touched),
     then runs your run_all.py and looks at what came back.
  2. If run_all.py did not rebuild everything, it runs your three scripts one
     by one, so that each step can still be checked.
  3. It recomputes the right answers from the raw SCB files on its own, and
     compares them with your files. It never changes your scripts.
  4. It checks the AI task (ai_02_clean.py): your asserts should catch the AI.

Runtime: 3-10 seconds (more if SCB asks your pipeline to wait).
Last printed line: "N of 7 steps right." (all right: "7 of 7 steps right.")
"""
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
SCRIPTS = ["scripts/01_get_data.py", "scripts/02_clean.py", "scripts/03_table.py"]


def run(project, script):
    """Run one script with this Python; return (exit code, printed text, error text)."""
    try:
        r = subprocess.run([sys.executable, str(project / script)], cwd=project,
                           capture_output=True, text=True, encoding="utf-8", timeout=180)
    except subprocess.TimeoutExpired:
        return 1, "", f"{script} took more than 3 minutes"
    return r.returncode, r.stdout, r.stderr


def last_error(text):
    """The last line of an error message, which usually names the problem."""
    lines = [ln for ln in text.strip().splitlines() if ln.strip()]
    return lines[-1] if lines else ""


def expected_quarterly(raw):
    """The right answer, computed here from the raw SCB files (not from your code)."""
    series = {}
    for name in ["cpi", "unemp"]:
        rows = json.loads((raw / f"{name}.json").read_text(encoding="utf-8"))["data"]
        dates = pd.to_datetime([r["key"][-1] for r in rows], format="%YM%m")
        series[name] = pd.Series([float(r["values"][0]) for r in rows], index=dates)
    q = {}
    for name, s in series.items():
        n = s.resample("QE").count()
        q[name] = s.resample("QE").mean()[n == 3]
    q = pd.DataFrame(q)
    q["infl"] = q["cpi"].pct_change(4) * 100
    q["infl_lag1"] = q["infl"].shift(1)
    return q.dropna()


def main() -> None:
    project = (HERE / sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE
    print(f"Checking the project in {project.name}/ ...\n")
    results = []

    def step(name, test, hint):
        """Run one check; print OK or a hint, never crash."""
        try:
            passed = bool(test())
        except Exception:
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    # 1. The delete-outputs test, then run_all.py
    for folder in ["data/processed", "output"]:
        shutil.rmtree(project / folder, ignore_errors=True)
    started = time.time()
    code, out, err = run(project, "run_all.py")
    run_all_ok = code == 0
    if not run_all_ok:
        print("run_all.py did not finish:", last_error(err) or last_error(out))
        print("Running the three scripts one by one instead ...")
        for script in SCRIPTS:
            c, o, e = run(project, script)
            if c != 0:
                print(f"  {script} stopped with: {last_error(e)}")
        print()
    if "ConnectionError" in err or "NameResolution" in err or "HTTPError" in err:
        print("  (No answer from SCB? Set USE_SAVED = True in scripts/01_get_data.py.)\n")

    def written(path):
        """True if the file exists and was written by this run."""
        return path.stat().st_mtime >= started - 1

    raw = project / "data" / "raw" / "scb"
    proc = project / "data" / "processed"
    tables = project / "output" / "tables"
    log_file = project / "output" / "logs" / "run_log.txt"

    def step1():
        code_01 = (project / "scripts" / "01_get_data.py").read_text(encoding="utf-8")
        live = [ln for ln in code_01.splitlines() if not ln.strip().startswith("#")]
        has_assert = any(ln.strip().startswith("assert") and "len(" in ln for ln in live)
        for name in ["cpi", "unemp"]:
            meta = json.loads((raw / "meta" / f"{name}.json").read_text(encoding="utf-8"))
            months = [v for v in meta["variables"] if v["code"] == "Tid"][0]["values"]
            rows = json.loads((raw / f"{name}.json").read_text(encoding="utf-8"))["data"]
            if len(rows) != len(months) or not written(raw / f"{name}.json"):
                return False
        return has_assert
    step("Step 1  01_get_data.py: both SCB answers saved, and an assert on the count",
         step1,
         "TODO 1: assert len(rows) == len(months), \"...\" inside the loop. "
         "No network? Set USE_SAVED = True.")

    def step2():
        q = pd.read_parquet(proc / "quarterly.parquet").set_index("date")
        right = expected_quarterly(raw)
        return (written(proc / "quarterly.parquet") and len(q) == len(right)
                and (q.index == right.index).all()
                and (q["infl"] - right["infl"]).abs().max() < 1e-9
                and (q["unemp"] - right["unemp"]).abs().max() < 1e-9)
    step("Step 2  02_clean.py: dates, complete quarters and inflation",
         step2,
         "TODOs 2a, 2b, 2d: format=\"%YM%m\"; the mean of each quarter, kept only "
         "where the count is 3; pct_change(4) * 100.")

    def step3():
        m = pd.read_parquet(proc / "monthly.parquet")
        return (written(proc / "monthly.parquet") and sorted(m.columns) == ["cpi", "unemp"]
                and m["cpi"].notna().sum() > 500 and m["unemp"].notna().sum() > 250)
    step("Step 2  02_clean.py: the loop reads every file with read_scb",
         step3,
         "TODO 2c: for path in sorted(RAW.glob(\"*.json\")): series[path.stem] = "
         "read_scb(path); then add len(...) to rows_in.")

    def step4():
        csv = (tables / "regression.csv").read_text(encoding="utf-8")
        n = len(pd.read_parquet(proc / "quarterly.parquet"))
        return (all(written(tables / f"regression.{e}") for e in ["csv", "tex", "txt"])
                and "unemp" in csv and f"N,{n},{n}" in csv
                and "tabular" in (tables / "regression.tex").read_text(encoding="utf-8"))
    step("Step 3  03_table.py: one table, saved as .csv, .tex and .txt",
         step4,
         "TODO 3: t.tables[0].to_csv(...); write t.as_latex() and "
         "t.as_text() to regression.tex and regression.txt.")

    def step5():
        log = log_file.read_text(encoding="utf-8")
        found = [log.find(f"{Path(s).name}:") for s in SCRIPTS]
        return run_all_ok and written(log_file) and -1 not in found and found == sorted(found)
    step("run_all run_all.py: the three scripts in order, and the log",
         step5,
         "TODOs 4-5: list the three scripts in SCRIPTS; log.append(result.stdout.strip()). "
         "The log is output/logs/run_log.txt.")

    step("run_all delete-outputs test: data/processed/ and output/ came back",
         lambda: run_all_ok and (proc / "quarterly.parquet").exists()
         and (tables / "regression.csv").exists(),
         "run_all.py must rebuild everything from data/raw/ alone; see the lines above.")

    def step7():
        ai = project / "ai_02_clean.py"
        if not ai.exists():
            ai = project / "ai_02_clean_reviewed.py"
        text = ai.read_text(encoding="utf-8")
        review = text.split("YOUR REVIEW", 1)[1]
        n_asserts = len(re.findall(r"^\s*assert\b", review, flags=re.M))
        if n_asserts < 3:
            return False
        c, o, e = run(project, ai.name)
        if "AssertionError" in e:                    # your asserts caught the AI
            return True
        return c == 0 and "AI version done" in o      # or you fixed it and all pass
    step("AI task ai_02_clean.py: three asserts that catch the AI (or pass once fixed)",
         step7,
         "write at least three assert lines below the review line in ai_02_clean.py, "
         "each testing a case whose answer you know.")

    print(f"\n{sum(results)} of {len(results)} steps right.")


if __name__ == "__main__":
    main()
