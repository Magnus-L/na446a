"""Further topic F1: panel regressions in Python, the way the lab runs them.

########## PREAMBLE ##########
File:     f1_script.py
Created:  30 Sep 2026 (Magnus Lodefalk, NA446A Part II, further topic F1)
Course:   optional self-study, not examined
What:     one step per slide of F1.pdf, top to bottom:
            1. load the wage panel and check its key (Stata: xtset)
            2. pooled OLS (Stata: reg)
            3. three kinds of standard errors: default, robust, clustered
            4. fixed effects for each person (Stata: reghdfe, absorb(nr))
            5. two-way fixed effects: person and year (absorb(nr year))
            6. one table with the three models (pf.etable)
            Appendix: random effects and the Hausman test (linearmodels;
            skipped cleanly if it is not installed)
Data:     data/wage_panel.csv: Vella and Verbeek's panel of 545 young
          American men, 1980-87 (the copy that ships with linearmodels)
Package:  pyfixest, the one the lab uses in its papers (add it once:
          uv add pyfixest). Optional, appendix only: uv add linearmodels
Stata:    the same steps are in f1_stata.do (log in f1_stata.log)
Run:      uv run f1_script.py      or cell by cell (# %%) in VS Code
Runtime:  about 4 seconds (the first run of pyfixest takes longer)
Last printed line: "f1_script.py done: 3 models, table in output/"
##############################
"""

# %% Setup: packages and folders
# Stata: clear all, set more off

from pathlib import Path

import numpy as np
import pandas as pd
import pyfixest as pf
from scipy import stats

# The folder this file sits in (for cell-by-cell runs, the working folder)
try:
    HERE = Path(__file__).resolve().parent
except NameError:
    HERE = Path.cwd()
(HERE / "output").mkdir(exist_ok=True)


# %% Step 1: load the panel and check its key
# Stata: import delimited using "data/wage_panel.csv", clear

df = pd.read_csv(HERE / "data" / "wage_panel.csv")

print("=== Step 1: the panel ===")
print("rows and columns:", df.shape)
print("persons:", df["nr"].nunique())

# Years per person: one number, 8, means the panel is balanced
# Stata: bysort nr: gen n_years = _N, then tab n_years
print("years per person:", df.groupby("nr").size().unique())

# One row per person and year, or something is wrong (Stata: isid nr year)
print("duplicate person-years:", df.duplicated(["nr", "year"]).sum())

# pyfixest needs no xtset: we name the person and year columns in each
# regression instead.


# %% Step 2: pooled OLS
# One regression on all 4,360 person-years, as if they were 4,360 people.
# pyfixest adds the intercept itself, as Stata does.
# Stata: reg lwage educ black hisp exper expersq married union
#   or:  reghdfe lwage educ black hisp exper expersq married union, noabsorb

# The formula, written once and used three times. Python glues two strings
# that stand side by side inside brackets into one.
formula = ("lwage ~ educ + black + hisp"
           " + exper + expersq + married + union")
pooled_default = pf.feols(formula, data=df,
                          vcov="iid")

print("\n=== Step 2: pooled OLS ===")
print(pooled_default.tidy().round(3))


# %% Step 3: three kinds of standard errors, same coefficients
# vcov="iid":         the textbook formula (Stata: default)
# vcov="hetero":      robust to unequal variances (Stata: vce(robust))
# vcov={"CRV1": "nr"}: clustered by person, which allows one man's errors
#                     to be related across his eight years (vce(cluster nr))

pooled_robust = pf.feols(formula, data=df,
                         vcov="hetero")
pooled_cluster = pf.feols(formula, data=df,
                          vcov={"CRV1": "nr"})

# Put the three sets of standard errors side by side
se_table = pd.DataFrame()
se_table["coef"] = pooled_default.coef()
se_table["se_default"] = pooled_default.se()
se_table["se_robust"] = pooled_robust.se()
se_table["se_cluster"] = pooled_cluster.se()

print("\n=== Step 3: standard errors ===")
print(se_table.loc[["educ", "union"]].round(3))

# How much larger are the clustered ones?
ratio = se_table["se_cluster"] / se_table["se_default"]
print("clustered / default, smallest and largest:",
      round(ratio.min(), 1), "and", round(ratio.max(), 1))


# %% Step 4: fixed effects for each person
# "| nr" gives every man his own intercept (Stata: absorb(nr)). Only changes
# WITHIN a man identify the slopes, so a variable that never changes within
# a man (education, race) cannot be estimated and is left out.
# Stata: reghdfe lwage exper expersq married union, absorb(nr) vce(cluster nr)
#   or:  xtreg lwage exper expersq married union, fe vce(cluster nr)

# Does education ever change within a man? The largest within-man sd:
print("\n=== Step 4: person fixed effects ===")
print("largest within-person sd of educ:", df.groupby("nr")["educ"].std().max())

fe_person = pf.feols(
    "lwage ~ exper + expersq + married + union | nr",
    data=df, vcov={"CRV1": "nr"})
print(fe_person.tidy().round(3))


# %% Step 5: two-way fixed effects, person and year
# "| nr+year" adds a dummy for every year as well (Stata: absorb(nr year)):
# wage changes common to everyone in a year no longer count as effects.
# Write "nr+year" without spaces: pyfixest 0.60 mislabels the fixed effects
# in etable (Step 6) otherwise.
# exper is left out: in these data every man gains exactly one year of
# experience per calendar year, so exper is the year minus a constant and
# the person and year effects already contain it (see the concept check).
# Stata: reghdfe lwage expersq married union, absorb(nr year) vce(cluster nr)

print("\n=== Step 5: two-way fixed effects ===")
exper_steps = df.groupby("nr")["exper"].diff()
print("exper rises by exactly 1 each year for everyone:",
      (exper_steps.dropna() == 1).all())

fe_twoway = pf.feols(
    "lwage ~ expersq + married + union | nr+year",
    data=df, vcov={"CRV1": "nr"})
print(fe_twoway.tidy().round(3))

# For the concept check: keep exper in, and see what pyfixest does with it
fe_twoway_exper = pf.feols("lwage ~ exper + expersq + married + union | nr+year",
                           data=df, vcov={"CRV1": "nr"})
print("coefficients kept when exper is in:", list(fe_twoway_exper.coef().index))


# %% Step 6: one table with the three models
# Stata: eststo after each reghdfe, then esttab (or outreg2)

# keep: only these rows; exact_match: "exper" must not also pick "expersq";
# signif_code: stars at 1, 5 and 10 per cent, as in Stata's usual tables;
# coef_fmt: coefficient with stars, then its standard error in brackets
models = [pooled_cluster, fe_person, fe_twoway]
keep = ["educ", "exper", "married", "union"]
table = pf.etable(models, type="df", keep=keep,
    exact_match=True, signif_code=[0.01, 0.05, 0.1],
    coef_fmt="b:.3f* (se:.3f)")

print("\n=== Step 6: the table ===")
print(table.to_string())

# Save it as text and as LaTeX for a paper (Stata: esttab using ..., tex)
(HERE / "output" / "panel_table.txt").write_text(table.to_string(), encoding="utf-8")
table_tex = pf.etable(models, type="tex", keep=keep,
    exact_match=True, signif_code=[0.01, 0.05, 0.1])
(HERE / "output" / "panel_table.tex").write_text(table_tex, encoding="utf-8")
print("saved: output/panel_table.txt and output/panel_table.tex")


# %% Appendix: random effects and the Hausman test (needs linearmodels)
# pyfixest has no random effects, so this step uses linearmodels. If it is
# not installed, the step is skipped and the script still finishes.

try:
    from linearmodels import PanelOLS, RandomEffects
    HAVE_LINEARMODELS = True
except ImportError:
    HAVE_LINEARMODELS = False
    print("\n(Appendix skipped: linearmodels is not installed;"
          " `uv add linearmodels` to try it.)")

if HAVE_LINEARMODELS:
    # linearmodels reads the panel from the index: person first, then year
    # (this line is Stata's xtset nr year)
    panel = df.set_index(["nr", "year"])

    # Random effects, with "1 +": linearmodels adds no intercept by itself
    # Stata: xtreg lwage educ black hisp exper expersq married union, re
    re_model = RandomEffects.from_formula(
        "lwage ~ 1 + educ + black + hisp + exper"
        " + expersq + married + union", data=panel).fit()

    # Fixed effects in linearmodels, for the test (Stata: xtreg ..., fe)
    fe_model = PanelOLS.from_formula(
        "lwage ~ 1 + exper + expersq + married + union + EntityEffects",
        data=panel).fit()

    # Hausman: are FE and RE different beyond chance? It uses the DEFAULT
    # standard errors (no clustering), because it assumes RE is efficient.
    # H = b_diff' * inverse(V_diff) * b_diff; "@" is matrix multiplication.
    # Stata: hausman fe re
    changing = ["exper", "expersq", "married", "union"]
    b_diff = fe_model.params[changing] - re_model.params[changing]
    v_diff = fe_model.cov.loc[changing, changing] - re_model.cov.loc[changing, changing]
    hausman = b_diff @ np.linalg.inv(v_diff) @ b_diff
    p_value = stats.chi2.sf(hausman, len(changing))

    print("\n=== Appendix: random effects and Hausman ===")
    print("union: RE", round(re_model.params["union"], 3),
          "| FE", round(fe_model.params["union"], 3))
    print("Hausman chi2(4) =", round(hausman, 2), "| p =", round(p_value, 6))

print("\nf1_script.py done: 3 models, table in output/")
