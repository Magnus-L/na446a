"""Further topic F1: panel regressions in Python, for readers who know xtreg.

Optional self-study for NA446A Part II (not examined). Recycled from the HT25
course script and corrected (see README.md, "What changed since HT25").

What it does, one cell per slide of F1.pdf:
  1. Loads the Vella-Verbeek wage panel that ships with linearmodels
     (545 young men, 1980-87; no network needed) and checks the panel key.
  2. Pooled OLS, with default and with clustered standard errors.
  3. Fixed effects (the within estimator), clustered by person.
  4. Random effects WITH an intercept, and what goes wrong without one.
  5. FE against RE: the classic Hausman test, and the Mundlak version that
     survives clustered standard errors.
  6. One table with all three models, saved as text and LaTeX.
  7. The same FE model in pyfixest (optional; skipped if not installed).

Run from this folder:   uv run f1_script.py     (or: python f1_script.py)
Needs: pandas, statsmodels, scipy (comes with statsmodels) and linearmodels;
pyfixest is optional. Add them with `uv add linearmodels pyfixest`.
Runtime: about 3 seconds (linearmodels 7.0, pyfixest 0.60, pandas 3.0.6).
Last printed line (30 Sep 2026): "f1_script.py done: 3 models, table in output/"
"""
# ---- CHANGE HERE (only these lines) ------------------------------------
TIME_VARYING = ["exper", "expersq", "married", "union"]   # change within a person
TIME_INVARIANT = ["educ", "black", "hisp"]                # fixed for each person
RUN_PYFIXEST = True        # False: skip step 7 (if pyfixest is not installed)
# ------------------------------------------------------------------------

# %% Setup
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from linearmodels import PanelOLS, PooledOLS, RandomEffects
from linearmodels.datasets import wage_panel
from linearmodels.panel import compare

try:                                   # the folder this file sits in
    HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    HERE = Path.cwd()
OUT = HERE / "output"
OUT.mkdir(exist_ok=True)
X = " + ".join(TIME_INVARIANT + TIME_VARYING)   # "educ + black + ... + union"
TV = TIME_VARYING                                # short name, used from Step 5

# %% Step 1: load the panel and check its key (Stata: xtset nr year)
df = wage_panel.load()                           # ships with linearmodels: offline
print("=== Step 1: the panel ===")
print(df.shape, df["nr"].nunique())
print(df.groupby("nr").size().unique())          # years per person: [8] = balanced
assert not df.duplicated(["nr", "year"]).any()   # the key is unique, or stop
df = df.set_index(["nr", "year"])                # entity first, then time
df.reset_index().to_csv(HERE / "data" / "wage_panel.csv", index=False)  # for Stata

# %% Step 2: pooled OLS, default and clustered standard errors
# Every person appears 8 times, and a person's errors are correlated across
# years (the same unobserved ability every year). Default standard errors
# treat the 4,360 rows as independent; clustering by person does not.
pooled = PooledOLS.from_formula(
    f"lwage ~ 1 + {X}", data=df)                 # "1 +": linearmodels adds no constant
p_default = pooled.fit()
p_cl = pooled.fit(cov_type="clustered",
                  cluster_entity=True)
print("\n=== Step 2: pooled OLS ===")
print(pd.DataFrame({"coef": p_cl.params, "se_default": p_default.std_errors,
                    "se_cluster": p_cl.std_errors}).loc[["educ", "union"]].round(3))

# %% Step 3: fixed effects (Stata: xtreg ..., fe vce(cluster nr))
# EntityEffects removes each person's mean: only changes WITHIN a person
# identify a coefficient. A variable that never changes within a person has
# nothing left, so FE cannot estimate it (xtreg omits it; linearmodels stops,
# or drops it with a warning if drop_absorbed=True).
within = df[TIME_INVARIANT + TIME_VARYING].groupby(level="nr").std().max()
fe = PanelOLS.from_formula(
    "lwage ~ 1 + exper + expersq + married"
    " + union + EntityEffects", data=df
    ).fit(cov_type="clustered", cluster_entity=True)
print("\n=== Step 3: fixed effects ===")
print("largest within-person sd:", within.round(2).to_dict())
print(pd.DataFrame({"coef": fe.params, "se": fe.std_errors})
      .loc[["exper", "married", "union"]].round(3))

# %% Step 4: random effects, WITH an intercept (Stata: xtreg ..., re)
# RE subtracts a share theta of each person's mean (FE subtracts all of it).
# linearmodels adds no constant unless the formula says "1 +". The HT25
# script left it out, so its RE line went through the origin.
re = RandomEffects.from_formula(
    f"lwage ~ 1 + {X}", data=df).fit(
    cov_type="clustered", cluster_entity=True)
re_no_const = RandomEffects.from_formula(f"lwage ~ {X}", data=df).fit(
    cov_type="clustered", cluster_entity=True)
print("\n=== Step 4: random effects ===")
print(pd.DataFrame({"with 1 +": re.params, "without": re_no_const.params})
      .loc[["Intercept", "educ", "union"]].round(3))
print("theta:", round(float(re.theta.iloc[0, 0]), 3),
      "| share of variance from the person effect:",
      round(float(re.variance_decomposition["Percent due to Effects"]), 2))
print("R-squared (overall) with 1 +:", round(re.rsquared_overall, 3),
      "| without:", round(re_no_const.rsquared_overall, 3),
      "| mean educ:", round(df["educ"].mean(), 1))

# %% Step 5a: FE against RE, the classic Hausman test (Stata: hausman fe re)
# H0: the person effect is uncorrelated with the regressors, so RE is
# consistent AND efficient. The classic formula needs that efficiency, which
# fails when errors are correlated within a person, so it uses the default
# (non-robust) covariances of both models: fe_d and re_d.
fe_d = PanelOLS.from_formula(f"lwage ~ 1 + {' + '.join(TV)} + EntityEffects",
                             data=df).fit()
re_d = RandomEffects.from_formula(f"lwage ~ 1 + {X}", data=df).fit()
diff = fe_d.params[TV] - re_d.params[TV]
v_diff = fe_d.cov.loc[TV, TV] - re_d.cov.loc[TV, TV]
h = float(diff @ np.linalg.inv(v_diff) @ diff)
print("\n=== Step 5a: classic Hausman ===")
print(f"chi2({len(TV)}) = {h:.1f}, p = {stats.chi2.sf(h, len(TV)):.6f}")

# %% Step 5b: the Mundlak version, valid with clustered standard errors
# Add each person's mean of every time-varying regressor. If RE's assumption
# holds, the means add nothing: test that they are jointly zero.
for v in TV:
    g = df.groupby(level="nr")[v]
    df["m_" + v] = g.transform("mean")
means = " + ".join("m_" + v for v in TV)
mundlak = RandomEffects.from_formula(f"lwage ~ 1 + {X} + {means}", data=df).fit(
    cov_type="clustered", cluster_entity=True)
test = mundlak.wald_test(formula=", ".join(f"m_{v} = 0" for v in TV))
print("\n=== Step 5b: Mundlak test ===")
print(f"chi2({len(TV)}) = {test.stat:.1f}, p = {test.pval:.6f}")
print("union: FE", round(fe.params["union"], 4),
      "| Mundlak", round(mundlak.params["union"], 4))

# %% Step 6: one table, three models (Stata: esttab)
table = compare({"Pooled": p_cl, "FE": fe, "RE": re},
                precision="std_errors", stars=True)
(OUT / "panel_table.txt").write_text(table.summary.as_text(), encoding="utf-8")
(OUT / "panel_table.tex").write_text(table.summary.as_latex(), encoding="utf-8")
# Print the rows the slide shows; the full table is in output/panel_table.txt
lines = table.summary.as_text().splitlines()
keep = ("Pooled", "No. Observations", "educ", "exper ", "married", "union")
print("\n=== Step 6: the table (selected rows) ===")
for i, line in enumerate(lines):
    if line.strip().startswith(keep):
        print(line)
        if lines[i + 1].strip().startswith("("):      # its standard errors
            print(lines[i + 1])

# %% Check 2: add year effects to FE. What happens to exper?
steps = df.groupby(level="nr")["exper"].diff().dropna()
print("\n=== Check 2: year effects ===")
print("exper rises by exactly 1 every year for everyone:", bool((steps == 1).all()))
try:
    PanelOLS.from_formula("lwage ~ exper + expersq + married + union"
                          " + EntityEffects + TimeEffects", data=df).fit()
except Exception as err:                          # linearmodels refuses the model
    print(type(err).__name__ + ":", str(err).strip().splitlines()[0])

# %% Step 7 (optional): the same FE model in pyfixest (Stata: reghdfe)
try:
    import pyfixest as pf
except ImportError:                                # optional: skip if not installed
    RUN_PYFIXEST = False
    print("\n(Step 7 skipped: pyfixest is not installed; `uv add pyfixest` to try it.)")
if RUN_PYFIXEST:
    d = df.reset_index()                          # pyfixest wants columns, not an index
    fit = pf.feols("lwage ~ exper + expersq"
                   " + married + union | nr",
                   data=d, vcov={"CRV1": "nr"})
    print("\n=== Step 7: pyfixest ===")
    print(pd.DataFrame({"coef": fit.coef(), "se": fit.se()})
          .rename_axis(None).loc[["exper", "union"]].round(4))

print("\nf1_script.py done: 3 models, table in output/")
