# F1 Panel regressions in Python (for readers who know `xtreg`)

Optional self-study for NA446A Part II. Not examined.

**What:** pooled OLS, fixed effects and random effects on a panel, with standard errors clustered by person; FE against RE with the Hausman test and its Mundlak version (which allows clustering); one table with all three models; the same FE model in pyfixest. Data: the Vella–Verbeek wage panel (545 young American men, 1980–87), which ships with `linearmodels`, so it works offline.

**Prerequisites:** Session 3 (panels, `set_index`, `groupby`) and Session 4 (a regression table), plus the regression course the programme requires. Knowing Stata's `xtreg` helps: every slide gives the Stata line.

**Time:** about 90 minutes (slides 30, running and changing the script 60).

## Extra packages

F1 needs `linearmodels` (it adds 3 small packages to the course environment). `pyfixest` is optional (Step 7 only; it brings about 20 more). In your course folder (`na446a-starter`), in the VS Code terminal:

```bash
uv add linearmodels          # required
uv add pyfixest              # optional; or set RUN_PYFIXEST = False in the script
```

`uv add` writes the package into your folder's `pyproject.toml`, so it stays installed. Tested with linearmodels 7.0, pyfixest 0.60, pandas 3.0.6, statsmodels 0.15.0, Python 3.12.

**Why linearmodels as the main package:** it has pooled OLS, fixed effects and random effects with Stata-like options (`cluster_entity=True`) and reads the panel from the index, like `xtset`. pyfixest (the Python port of R's `fixest`, close to Stata's `reghdfe`) is faster and handles many fixed effects, but has no random effects, so it appears once, as a check.

## Files

| File | What |
|---|---|
| `F1.pdf` (source `F1.tex`) | 13 slides: goals, six terms, seven steps with real output, two concept checks, readings |
| `f1_script.py` | Reproduces every number on the slides. CHANGE HERE block at the top (regressors; pyfixest on/off) |
| `f1_stata.do`, `f1_stata.log` | The Stata equivalents, run in StataNow 19.5: same coefficients and clustered standard errors |
| `data/wage_panel.csv` | The panel as CSV, written by the script, for Stata |
| `output/panel_table.txt`, `.tex` | The three-model table, written by the script |
| `build/f1_output.txt` | The script's printout of 30 Sep 2026, for comparison |

## Run

```bash
uv run further/F1_panel_regressions/f1_script.py
```

Runtime about 3 seconds. Last printed line: `f1_script.py done: 3 models, table in output/`. Or run it cell by cell (`# %%`) in VS Code, next to the slides.

## What changed since HT25

The material comes from the HT25 course script (`intro446a.py`, lines 1111–1440 and 1535–1642), corrected:

- Random effects now has an intercept (`1 +`); HT25's RE line went through the origin. The first concept check is built on that bug.
- No `stargazer` (no recent release, and its table duplicated N and R-squared): one table route, `linearmodels.panel.compare`.
- The Hausman test is computed (linearmodels has no command for it) with the default covariances it requires, and paired with the Mundlak test, which is valid with clustered standard errors. HT25 only said "not directly implemented".
- The data ship with the package: no download from a server outside the course.
- Dropped: the regressor built from its own outcome (a year-by-union mean of log wage used to explain log wage), hand-computed t-tests, and `pf.feols(...).summary()` assigned to a variable (it returns `None`). No name reused for two things (`df` was also an integer in HT25).

Build the slides: `python3 ../scripts/check_deck.py F1.tex` (Tectonic; zero overfull boxes on 30 Sep 2026).
