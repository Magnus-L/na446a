# F1 Panel regressions in Python (the lab's way: pyfixest)

Optional self-study for NA446A Part II. Not examined.

**What:** pooled OLS, fixed effects for each person, two-way fixed effects (person and year), standard errors clustered by person, and one table with all three models, in `pyfixest`, the package the AI-Econ Lab uses in its papers. Every slide gives the `reghdfe` line that does the same in Stata. Random effects and the Hausman test are reduced to one appendix slide. Data: the Vella–Verbeek wage panel (545 young American men, 1980–87), saved in `data/`, so it works offline.

**After which session:** Session 3 (panels, `groupby`) and Session 4 (a regression table), plus the regression course the programme requires. Knowing Stata's `reg`, `xtreg` or `reghdfe` helps.

**Time:** about 60–75 minutes (slides 20, running and changing the script 40–55).

## Extra packages

In your course folder (`na446a-starter`), in the VS Code terminal:

```bash
uv add pyfixest          # required (about 20 small packages)
uv add linearmodels      # optional: only the appendix (random effects, Hausman)
```

`uv add` writes the package into your folder's `pyproject.toml`, so it stays installed. Without `linearmodels` the script skips the appendix and still finishes. Tested on 30 Sep 2026 with pyfixest 0.60.0, pandas 3.0.6, Python 3.12, and linearmodels 7.0 for the appendix, in a separate environment (the course `pyproject.toml` and the student starter were not changed).

**Why pyfixest:** it is the Python port of R's `fixest` and works like Stata's `reghdfe`: `pf.feols("y ~ x | nr+year", data=df, vcov={"CRV1": "nr"})` is `reghdfe y x, absorb(nr year) vce(cluster nr)`. The lab's canaries paper runs its job-ad regressions this way (`pf.feols` and `pf.fepois`, clustered by occupation or employer); AI Unboxed runs the same design in Stata with `reghdfe ..., a(ind_y firmID) cluster(firmID)`.

## Files

| File | What |
|---|---|
| `F1.pdf` (source `F1.tex`) | 12 slides plus title: goals, six terms, six steps with real output, two concept checks, summary and readings, one appendix slide |
| `f1_script.py` | Reproduces every number on the slides, one `# %%` cell per step, written like a Stata do-file: one step at a time, a comment and the Stata line above each block |
| `f1_stata.do`, `f1_stata.log` | The Stata equivalents with `reghdfe`, run in StataNow 19.5: identical coefficients and clustered standard errors (to seven digits) |
| `data/wage_panel.csv` | The panel (the copy that ships with `linearmodels`) |
| `output/panel_table.txt`, `.tex` | The three-model table from `pf.etable`, written by the script |
| `build/f1_output.txt` | The script's printout of 30 Sep 2026 (with linearmodels), for comparison |

## Run

```bash
uv run further/F1_panel_regressions/f1_script.py
```

Runtime about 3 seconds (the very first pyfixest run takes longer while it compiles). Last printed line: `f1_script.py done: 3 models, table in output/`. Or run it cell by cell (`# %%`) in VS Code, next to the slides. pyfixest prints one warning at Step 5 ("1 variables dropped due to multicollinearity"): that is the concept check, on purpose.

## Checked against Stata

`reghdfe` (with `ftools`) was already installed in StataNow 19.5; on a new machine, `ssc install reghdfe` and `ssc install ftools` once. Pooled OLS (default, robust, clustered), person FE and two-way FE agree with pyfixest to seven digits; `xtreg, fe vce(cluster nr)` gives the same as `reghdfe, absorb(nr)`. The one gap is the Hausman statistic (Python 31.57, Stata 31.45), because the two programs estimate the RE variance slightly differently.

## What changed

- **30 Sep 2026, rebuilt around pyfixest.** The first version (same day) was built on `linearmodels` with pyfixest as an optional check. The lab estimates with pyfixest and `reghdfe`, so the module now teaches those: two-way fixed effects added, one table via `pf.etable`, random effects and Hausman moved to one appendix slide, the Mundlak test dropped. The script no longer needs `linearmodels` to run.
- **Recycled from HT25** (`intro446a.py`, lines 1111–1440 and 1535–1642), with its bugs fixed: RE now has an intercept (`1 +`), no `stargazer`, no regressor built from its own outcome, no `pf.feols(...).summary()` assigned to a variable (it returns `None`).

Build the slides: `python3 ../scripts/check_deck.py F1.tex` (Tectonic; zero overfull boxes on 30 Sep 2026).
