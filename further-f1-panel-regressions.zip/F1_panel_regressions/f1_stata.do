* F1 Panel regressions: the Stata equivalents quoted on the slides.
* Data: data/wage_panel.csv, written by f1_script.py (the linearmodels copy
* of the Vella-Verbeek panel). Run from this folder:  do f1_stata.do
* Checked in StataNow 19.5 on 30 Sep 2026 (log: f1_stata.log).
version 19
import delimited using "data/wage_panel.csv", clear
xtset nr year                                   // set_index(["nr", "year"])
local x educ black hisp exper expersq married union
reg lwage `x'                                   // PooledOLS, default se
reg lwage `x', vce(cluster nr)                  // PooledOLS, clustered
xtreg lwage exper expersq married union, fe vce(cluster nr)   // PanelOLS + EntityEffects
xtreg lwage `x', re vce(cluster nr)             // RandomEffects "1 + ..."
* Classic Hausman: needs the default (non-robust) variance of both models
quietly xtreg lwage exper expersq married union, fe
estimates store fe
quietly xtreg lwage `x', re
estimates store re
hausman fe re
* Mundlak: person means of the time-varying regressors, clustered se
foreach v in exper expersq married union {
    bysort nr: egen m_`v' = mean(`v')
}
xtreg lwage `x' m_exper m_expersq m_married m_union, re vce(cluster nr)
test m_exper m_expersq m_married m_union
