******** START A LOG-FILE ******
set logtype t
set linesize 120
cap noisily log close
log using "f1_stata.log", replace

********* PREAMBLE ************
* DO-file name: f1_stata.do
* Created: 30 Sep 2026 (Magnus Lodefalk)
* The Stata equivalents of f1_script.py (Further topic F1, NA446A Part II):
* pooled OLS, three kinds of standard errors, person FE, two-way FE, all
* with reghdfe as in the lab's papers; xtreg for the RE/Hausman appendix.
* Data: data/wage_panel.csv (Vella-Verbeek panel, as shipped by linearmodels)
* Needs: reghdfe and ftools (once: ssc install reghdfe, ssc install ftools)
* Run from this folder: do f1_stata.do (StataNow 19.5, 30 Sep 2026)
**********************

clear all
set more off
version 19

********* STEP 1: LOAD AND CHECK THE PANEL
import delimited using "data/wage_panel.csv", clear
isid nr year
xtset nr year

local x educ black hisp exper expersq married union

********* STEP 2 AND 3: POOLED OLS, THREE KINDS OF STANDARD ERRORS
reghdfe lwage `x', noabsorb
reghdfe lwage `x', noabsorb vce(robust)
reghdfe lwage `x', noabsorb vce(cluster nr)
* the same with reg, as in the NA303G lab
reg lwage `x', vce(cluster nr)

********* STEP 4: PERSON FIXED EFFECTS
reghdfe lwage exper expersq married union, absorb(nr) vce(cluster nr)
xtreg lwage exper expersq married union, fe vce(cluster nr)

********* STEP 5: TWO-WAY FIXED EFFECTS (PERSON AND YEAR)
reghdfe lwage expersq married union, absorb(nr year) vce(cluster nr)
* with exper in: reghdfe omits it as collinear
reghdfe lwage exper expersq married union, absorb(nr year) vce(cluster nr)

********* APPENDIX: RANDOM EFFECTS AND HAUSMAN (default standard errors)
quietly xtreg lwage exper expersq married union, fe
estimates store fe
quietly xtreg lwage `x', re
estimates store re
xtreg lwage `x', re
hausman fe re

***** POSTSCRIPT
cap log close
exit
