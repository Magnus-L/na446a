# NA446A course data (public)

| File | Rows × columns | What it is | Source |
|---|---|---|---|
| `auto.csv` | 392 × 9 | Cars from the 1970s–80s: mpg, cylinders, weight, origin (1 US, 2 Europe, 3 Japan), name | The classic "Auto MPG" teaching dataset (originally UCI Machine Learning Repository), copy from github.com/selva86/datasets |
| `auto_messy.csv` | 392 × 9 | `auto.csv` with two planted problems for session 2: "?" in four horsepower values, 999 in three mpg values | Made for the course from `auto.csv` |
| `titanic.csv` | 891 × 12 | Passengers of the Titanic: survival, class, sex, age, fare | The widely used Titanic teaching dataset (Kaggle training set), copy from github.com/datasciencedojo/datasets |

All work offline: download once, then no internet is needed. The session 3 register data
(synthetic, one dataset per pair) is posted before session 3.
