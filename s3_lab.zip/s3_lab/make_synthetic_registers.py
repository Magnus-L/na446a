"""
make_synthetic_registers.py  (Session 3 lab copy)
=================================================

Make the SYNTHETIC register files for the NA446A Session 3 lab. Nothing in them
comes from real data: every person, firm, grade, code and amount is drawn from
a random-number generator with a fixed seed, so the files are identical every
time the script runs. The ids (P000001, F00001) are obviously fake.

You do not need this script if you downloaded pair_NN.zip from the Data page.
It is here so you can make your pair's data offline, and so the self-checks can
compute the right answers for your pair. The documentation of the files is
CODEBOOK.md; read it, then check it against the data.

Run from the lab folder:
    python make_synthetic_registers.py             # pair 00 (default) -> pair_00/data/raw/
    python make_synthetic_registers.py --pair 7    # pair 07 -> pair_07/data/raw/

Every pair gets the same files, columns and codes, but different numbers.
A pair's seed is 446000 + pair number; pair 00 uses seed 446.
Runtime: about 1 second. The last printed line starts "End of generation".

The data-making code below is the same as in the teacher's register-lab
generator; only this text and the folder layout differ (checked byte for byte
by make_pair_zips.py).
"""

import argparse
import time
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Settings. Change the seed and you get a different (but equally fake) world.
# ---------------------------------------------------------------------------
DEFAULT_SEED = 446                   # the answer key is computed on this seed
SEED = DEFAULT_SEED                  # reset by main(); used by every draw below
N_PERSONS = 1000
N_FIRMS = 150
LISA_YEARS = range(2019, 2024)       # 2019-2023
FIRM_YEARS = range(2019, 2024)       # 2019-2023
MIGRATION_YEARS = range(2019, 2025)  # 2019-2024 (one year more, on purpose)
VINTAGE_SWITCH = 2021                # new variable names and codes from this year
STATE_CODE_SWITCH = 2017             # activity codes numeric before, letters from

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "pair_00" / "data" / "raw"   # pair 00 = the default data

rng = np.random.default_rng(SEED)
# A second, independent stream for features added after the first release (the
# AGI employment form and the rows without a person id). Keeping them off the
# main stream means every other number is unchanged for a given seed.
rng_extra = np.random.default_rng([SEED, 1])


def seed_for_pair(pair: int) -> int:
    """Seed for a student pair: same columns, different numbers."""
    return DEFAULT_SEED * 1000 + pair


def output_dir(seed: int, pair: int | None, out: str | None = None) -> Path:
    """Where the raw files go: pair_NN/data/raw/ next to this script."""
    if out:
        return (Path(out) if Path(out).is_absolute() else ROOT / out).resolve()
    if pair is None:
        pair = 0 if seed == DEFAULT_SEED else None
    if pair is not None:
        return ROOT / f"pair_{pair:02d}" / "data" / "raw"
    return ROOT / f"seed_{seed}" / "data" / "raw"

FOREIGN_COUNTRIES = ["FINLAND", "NORGE", "POLEN", "TYSKLAND", "IRAK", "SYRIEN",
                     "SOMALIA", "IRAN", "INDIEN", "KINA", "ERITREA", "THAILAND"]
OECD_DESTINATIONS = ["NORGE", "DANMARK", "FINLAND", "TYSKLAND", "STORBRITANNIEN",
                     "USA", "POLEN", "SPANIEN"]
NON_OECD_DESTINATIONS = ["IRAK", "SYRIEN", "SOMALIA", "INDIEN", "KINA",
                         "THAILAND", "IRAN", "ERITREA"]

# Education level codes, old vintage. First digit = broad level, second digit =
# length. Grouped by the 11-level variable the cleaning scripts build.
EDUC_CODES_OLD = {
    1: [100, 106], 2: [200, 206], 3: [310, 312, 316], 4: [320, 322, 326],
    5: [330, 332, 336], 6: [410, 412, 416], 7: [520, 522, 526],
    8: [530, 532, 536], 9: [540, 546], 10: [550, 556], 11: [600, 640],
}

# Grade-9 subjects (column names in the raw file).
AK9_SUBJECTS = ["BILD", "ENGELSKA", "HEMKUNSKAP", "IDROTT", "MATEMATIK", "MUSIK",
                "BIOLOGI", "FYSIK", "KEMI", "GEOGRAFI", "HISTORIA", "RELIGION",
                "SAMHALL", "SLOJD", "SVENSKA", "TEKNIK", "SPRAK1", "SPRAK2"]
OLD_SCALE = ["IG", "G", "VG", "MVG"]
NEW_SCALE = ["F", "E", "D", "C", "B", "A"]


def new_vintage_code(code: int) -> int:
    """Translate an old-vintage education code into the invented new vintage.

    Codes ending in 6 end in 7 instead; postgraduate codes 600 and 640 merge into
    620. The first digit (the broad level) never changes, which is exactly what a
    careful cleaner can exploit and a careless one never notices.
    """
    if code in (600, 640):
        return 620
    if code % 10 == 6:
        return code + 1
    return code


def pick_education(ability: float) -> tuple[int, int]:
    """Return (11-level group, old-vintage code) for a given latent ability."""
    cut_points = [(-1.8, [1]), (-1.0, [2]), (0.0, [3, 4, 5, 5, 5]),
                  (0.4, [6]), (1.3, [7, 7, 8, 8, 8, 9]), (2.0, [10])]
    group = 11
    for threshold, groups in cut_points:
        if ability < threshold:
            group = int(rng.choice(groups))
            break
    # Codes ending in 6 are made common so the vintage change is visible.
    codes = EDUC_CODES_OLD[group]
    weights = np.array([2.0 if c % 10 == 6 else 1.0 for c in codes])
    code = int(rng.choice(codes, p=weights / weights.sum()))
    return group, code


# ---------------------------------------------------------------------------
# 1. Persons
# ---------------------------------------------------------------------------
def make_persons() -> pd.DataFrame:
    """Build the person file and a hidden 'truth' table used by later steps.

    The truth table (ability, education, death year, firm) is never written to
    disk; it only keeps the yearly files consistent with each other.
    """
    ids = [f"P{i:06d}" for i in range(1, N_PERSONS + 1)]
    birth_year = rng.integers(1985, 2001, N_PERSONS)
    birth_month = rng.integers(1, 13, N_PERSONS)
    foreign = rng.random(N_PERSONS) < 0.15
    death_year = np.where(rng.random(N_PERSONS) < 0.01,
                          rng.integers(2019, 2024, N_PERSONS), 0)

    persons = pd.DataFrame({
        "LopNr": ids,
        "Kon": rng.choice(["1", "2"], N_PERSONS),
        "FodelseAr": birth_year.astype(str),
        "FodelseManad": [f"{y}{m:02d}" for y, m in zip(birth_year, birth_month)],
        "FodelseLandNamn": np.where(foreign,
                                    rng.choice(FOREIGN_COUNTRIES, N_PERSONS),
                                    "SVERIGE"),
        "DodDatum": [f"{d}{rng.integers(1, 13):02d}{rng.integers(1, 29):02d}"
                     if d else "" for d in death_year],
    })

    truth = pd.DataFrame({
        "lopnr": ids, "birth_year": birth_year, "foreign": foreign,
        "death_year": death_year, "ability": rng.normal(0, 1, N_PERSONS),
    })
    edu = [pick_education(a) for a in truth["ability"]]
    truth["educ_group"] = [g for g, _ in edu]
    truth["educ_code"] = [c for _, c in edu]
    truth["immig_year"] = np.where(
        foreign, np.minimum(birth_year + rng.integers(0, 26, N_PERSONS), 2018), 0)

    # Planted problems: 2 ids appear twice with a conflicting country of birth,
    # and 3 rows are exact duplicates.
    conflicting = persons.sample(2, random_state=SEED).copy()
    conflicting["FodelseLandNamn"] = np.where(
        conflicting["FodelseLandNamn"] == "SVERIGE", "NORGE", "SVERIGE")
    exact = persons.sample(3, random_state=SEED + 1)
    persons = (pd.concat([persons, conflicting, exact])
               .sample(frac=1, random_state=SEED)      # shuffle row order
               .reset_index(drop=True))
    return persons, truth


# ---------------------------------------------------------------------------
# 2. Grade 9 (wide, one or two rows per person)
# ---------------------------------------------------------------------------
def grade_from_score(score: float) -> str:
    """Map a latent score to the old four-step scale."""
    if score < -1.3:
        return "IG"
    if score < 0.0:
        return "G"
    if score < 1.0:
        return "VG"
    return "MVG"


def make_ak9(truth: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for p in truth.itertuples():
        if rng.random() < 0.05:            # 5% have no grade-9 record at all
            continue
        row = {"LopNr": p.lopnr, "Ar": str(p.birth_year + 16)}
        all_missing = rng.random() < 0.004  # code "A": no grades in any subject
        for subj in AK9_SUBJECTS:
            if all_missing:
                row[subj] = "A"
                continue
            if subj == "SPRAK2" and rng.random() < 0.45:
                row[subj] = rng.choice(["2", ""])   # not taken / not graded
                continue
            if subj == "SPRAK1" and rng.random() < 0.05:
                row[subj] = ""
                continue
            g = grade_from_score(p.ability + rng.normal(0, 0.8))
            u = rng.random()
            if u < 0.01:
                g = "*"                       # sentinel for "unknown"
            elif u < 0.03:
                g = " " + g                   # leading space, as delivered
            row[subj] = g
        rows.append(row)

        # 6% were graded twice (two consecutive years). The later row is the one
        # that counts; in it 1-3 subjects move one step up OR down.
        if rng.random() < 0.06 and not all_missing:
            later = dict(row)
            later["Ar"] = str(p.birth_year + 17)
            for subj in rng.choice(AK9_SUBJECTS[:16], rng.integers(1, 4),
                                   replace=False):
                old = later[subj].strip()
                if old in OLD_SCALE:
                    i = OLD_SCALE.index(old) + int(rng.choice([-1, 1]))
                    later[subj] = OLD_SCALE[min(max(i, 0), 3)]
            rows.append(later)
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 3. Upper secondary courses (long: one row per course)
# ---------------------------------------------------------------------------
def make_gymn(truth: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for p in truth.itertuples():
        if rng.random() < 0.15:           # 15% have no upper-secondary record
            continue
        end_year = p.birth_year + 19
        new_scale = end_year >= 2014       # A-F scale for later cohorts
        for k in range(rng.integers(18, 29)):
            score = p.ability + rng.normal(0, 0.9)
            if new_scale:
                i = int(np.clip(np.floor(score * 1.2 + 3), 0, 5))
                grade = NEW_SCALE[i]
            else:
                grade = grade_from_score(score)
            rows.append({"LopNr": p.lopnr, "AvgAr": str(end_year),
                         "KursKod": f"K{k + 1:03d}", "Betyg": grade,
                         "Poang": str(rng.choice([50, 100, 100, 100, 150]))})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 4. Yearly individual files (LISA-style)
# ---------------------------------------------------------------------------
def make_lisa_year(truth: pd.DataFrame, year: int,
                   firm_of: dict[str, str]) -> pd.DataFrame:
    new = year >= VINTAGE_SWITCH
    rows = []
    for p in truth.itertuples():
        if p.death_year and p.death_year < year:
            continue
        if rng.random() < 0.02:            # abroad / not in the population
            continue
        age = year - p.birth_year

        # Education code, in the vintage of the year; sentinels on top.
        code = new_vintage_code(p.educ_code) if new else p.educ_code
        sun = "999" if rng.random() < 0.02 else str(code)
        sun_old = "*" if rng.random() < 0.03 else str(code)

        # Current studies: 0 = none, 1-3 = registered with different intensity.
        hs = int(rng.integers(1, 4)) if (age <= 30 and p.ability > -0.2
                                          and rng.random() < 0.35) else 0
        fo = int(rng.integers(1, 4)) if (p.educ_group >= 8 and age >= 25
                                          and rng.random() < 0.08) else 0

        # Employment status: 1 employed, 5/6 not employed; 7 (new vintage only,
        # invented) = employed, reported only through the monthly declarations.
        p_emp = 1 / (1 + np.exp(-(1.0 + 0.8 * p.ability - 1.2 * (hs > 0))))
        employed = rng.random() < p_emp
        if employed:
            status = "7" if (new and rng.random() < 0.05) else "1"
        else:
            status = str(rng.choice(["5", "6"]))

        if employed:
            first = "0" if rng.random() < 0.01 else str(
                int(np.clip(10 - p.educ_group * 0.8 + rng.normal(0, 1.5), 1, 9)))
            ssyk = first + f"{rng.integers(0, 1000):03d}"
            firm = firm_of[p.lopnr]
            wage = int(rng.lognormal(8.2 + 0.25 * p.ability, 0.4))
        else:
            ssyk, firm, wage = "****", "", int(rng.choice([0, 0, 0, 150, 400]))
        stud = int(rng.integers(200, 1100)) if hs > 0 else 0
        alos = int(rng.integers(1, 260)) if (not employed and hs == 0
                                             and rng.random() < 0.6) else 0

        # Children by age band. Missing bands happen in real deliveries.
        n_kids = rng.poisson(max(0.0, (age - 24) * 0.12))
        kid_ages = rng.integers(0, 18, n_kids)
        bands = {"Barn0_3": (0, 3), "Barn4_6": (4, 6), "Barn7_10": (7, 10),
                 "Barn11_15": (11, 15), "Barn16_17": (16, 17)}
        kids = {b: str(int(((kid_ages >= lo) & (kid_ages <= hi)).sum()))
                for b, (lo, hi) in bands.items()}
        if rng.random() < 0.04:
            kids["Barn16_17"] = ""

        exam = (str(min(year, p.birth_year + 19 + int(rng.integers(0, 8))))
                if (p.educ_group >= 4 or rng.random() < 0.5) else "")

        row = {"LopNr": p.lopnr,
               "SenInvAr": str(p.immig_year) if p.foreign else "0000",
               **kids,
               "ExamAr": exam,
               ("Sun2020Niva" if new else "Sun2000Niva"): sun,
               ("Sun2020Niva_Old" if new else "Sun2000Niva_Old"): sun_old,
               "HsDelt": str(hs), "FoDelt": str(fo),
               ("SyssStat19" if new else "SyssStat11"): status,
               ("AGI1SSYK4" if new else "KU1SSYK4"): ssyk,
               ("AGI1PeOrgNr" if new else "KU1PeOrgNr"): firm,
               ("AGI1Ink" if new else "KU1Ink"): str(wage),
               "ForvErs": str(wage + alos * 7 + stud // 3),
               "KapInk": str(int(max(0, rng.normal(20, 40)))),
               "Stud": str(stud),
               # A few blank cells: the register leaves the field empty.
               "AlosDag": "" if rng.random() < 0.015 else str(alos)}
        rows.append(row)
    lisa = pd.DataFrame(rows)
    if year == 2022:                       # one exact duplicate row
        lisa = pd.concat([lisa, lisa.sample(1, random_state=SEED)])
    return lisa.reset_index(drop=True)


# ---------------------------------------------------------------------------
# 5. Firms
# ---------------------------------------------------------------------------
def make_firms() -> dict[int, pd.DataFrame]:
    firm_ids = [f"F{i:05d}" for i in range(1, N_FIRMS + 1)]
    sni_pool = ["01110", "10110", "25110", "41200", "47111", "49410", "56100",
                "62010", "69201", "85201"]
    sni = rng.choice(sni_pool, N_FIRMS)
    sni[rng.choice(N_FIRMS, 2, replace=False)] = "00000"   # sentinel
    size0 = rng.lognormal(3.0, 1.2, N_FIRMS)
    out = {}
    for t, year in enumerate(FIRM_YEARS):
        size = np.maximum(1, size0 * np.exp(rng.normal(0.02 * t, 0.1, N_FIRMS)))
        sales = size * rng.lognormal(7.3, 0.4, N_FIRMS)
        vadd = sales * rng.uniform(0.25, 0.5, N_FIRMS)
        labcost = size * rng.lognormal(6.3, 0.2, N_FIRMS)
        df = pd.DataFrame({
            "PeOrgNr": firm_ids, "SNI2007": sni,
            "MedelAntalAnstallda": np.round(size).astype(int).astype(str),
            "Nettoomsattning": np.round(sales).astype(int).astype(str),
            "Foradlingsvarde": np.round(vadd).astype(int).astype(str),
            "Rorelseresultat": np.round(vadd - labcost).astype(int).astype(str),
            # Accounting sign convention: costs are stored as negative numbers.
            "SummaPersonalkostnader": (-np.round(labcost)).astype(int).astype(str),
        })
        if year == 2021:                   # one firm reported twice
            dup = df.iloc[[41]].copy()
            dup["MedelAntalAnstallda"] = str(int(dup["MedelAntalAnstallda"].iloc[0]) + 7)
            df = pd.concat([df, dup])
        out[year] = df.reset_index(drop=True)
    return out


# ---------------------------------------------------------------------------
# 6. Migration events
# ---------------------------------------------------------------------------
def make_migrations(truth: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for p in truth.itertuples():
        if not (p.foreign and rng.random() < 0.5) and rng.random() > 0.10:
            continue
        for _ in range(rng.integers(1, 4)):
            y = int(rng.choice(list(MIGRATION_YEARS)))
            u = rng.random()
            land = ("OKÄNT" if u < 0.04 else
                    rng.choice(OECD_DESTINATIONS) if u < 0.55 else
                    rng.choice(NON_OECD_DESTINATIONS))
            rows.append({"LopNr": p.lopnr,
                         "Datum": f"{y}-{rng.integers(1, 13):02d}-{rng.integers(1, 29):02d}",
                         "PostTyp": rng.choice(["Inv", "Utv"]),
                         "InUtvLand": land})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 7. Activity spells: two registers, invented codes
# ---------------------------------------------------------------------------
# Letter codes: first letter = category (see README). E30 is a special E code
# ("start-up subsidy") that the analysis wants to EXCLUDE from category E.
# F12, F15 and F18 are the youth placement codes.
LETTERS = list("ABCDEFGHLKRUVYZ")
LETTER_W = np.array([12, 8, 10, 6, 14, 14, 8, 6, 4, 4, 5, 3, 3, 1, 2], float)
# Numeric (old) vintage: first three digits fall in a range per category.
NUMERIC_RANGES = {"AB": (100, 199), "CD": (200, 299), "E": (300, 399),
                  "F": (400, 499), "HL": (500, 649), "REST": (650, 999)}


def letter_code(age: int) -> str:
    letter = str(rng.choice(LETTERS, p=LETTER_W / LETTER_W.sum()))
    if letter == "E" and rng.random() < 0.35:
        return "E30"
    if letter == "F" and rng.random() < (0.7 if age < 25 else 0.35):
        return str(rng.choice(["F12", "F15", "F18"]))
    return f"{letter}{rng.integers(10, 100)}"


def numeric_code() -> str:
    cat = str(rng.choice(list(NUMERIC_RANGES), p=[.2, .16, .14, .14, .16, .2]))
    lo, hi = NUMERIC_RANGES[cat]
    return f"{rng.integers(lo, hi + 1)}{rng.integers(0, 10)}"   # 4 characters


def make_spells(truth: pd.DataFrame, years: range, n_codes: int,
                share: float, numeric_before: int | None) -> pd.DataFrame:
    """One row per spell: person, year, age, main code and up to n_codes codes.

    Kod1 always repeats the main code (HKod); further codes are secondary.
    """
    rows = []
    n_weights = np.array([1 / (k ** 1.1) for k in range(1, n_codes + 1)])
    for p in truth.itertuples():
        if rng.random() > share:
            continue
        for _ in range(rng.integers(1, 6)):
            year = int(rng.choice(list(years)))
            age = year - p.birth_year
            if age < 16:
                continue
            numeric = numeric_before is not None and year < numeric_before
            k = int(rng.choice(np.arange(1, n_codes + 1),
                               p=n_weights / n_weights.sum()))
            codes = [numeric_code() if numeric else letter_code(age)
                     for _ in range(k)]
            row = {"LopNr": p.lopnr, "Ar": str(year), "Alder": str(age),
                   "HKod": codes[0]}
            for j in range(n_codes):
                row[f"Kod{j + 1}"] = codes[j] if j < k else ""
            rows.append(row)
    return pd.DataFrame(rows)



# ---------------------------------------------------------------------------
# 8. Monthly employer declarations, 2023 (AGI-style; column names invented)
# ---------------------------------------------------------------------------
def make_agi(lisa: pd.DataFrame, firm_ids: list[str], year: int) -> pd.DataFrame:
    """One row per person, employer and month with the cash pay in SEK.

    Built from the yearly file so the two agree: the employer in the yearly
    file (AGI1PeOrgNr) is the one that paid the most over the year, and the
    yearly wage income (AGI1Ink, in 100 SEK) is the pay from that employer.
    About 8% of employees also had a smaller second employer during the year.
    Ten rows are exact duplicates (a declaration submitted twice).
    add_agi_extras() then adds the employment form and a few rows without a
    person id, drawn from the second random stream.
    """
    rows = []
    employed = lisa[lisa["AGI1PeOrgNr"].fillna("") != ""]
    for r in employed.itertuples():
        annual_main = int(r.AGI1Ink) * 100
        if rng.random() < 0.85:
            months = list(range(1, 13))
        else:
            start = int(rng.integers(1, 10))
            months = list(range(start, int(rng.integers(start + 2, 13)) + 1))
        for m in months:
            pay = annual_main / len(months) * rng.uniform(0.95, 1.05)
            rows.append({"LopNr": r.LopNr, "PeOrgNr": r.AGI1PeOrgNr,
                         "Period": f"{year}{m:02d}", "Lon": str(int(round(pay)))})
        if rng.random() < 0.08:                      # a second, smaller employer
            other = str(rng.choice([f for f in firm_ids if f != r.AGI1PeOrgNr]))
            share = rng.uniform(0.10, 0.45)
            other_months = rng.choice(np.arange(1, 13), int(rng.integers(1, 5)),
                                      replace=False)
            for m in sorted(other_months):
                pay = annual_main * share / len(other_months)
                rows.append({"LopNr": r.LopNr, "PeOrgNr": other,
                             "Period": f"{year}{m:02d}",
                             "Lon": str(int(round(pay)))})
    agi = pd.DataFrame(rows)
    agi = pd.concat([agi, agi.sample(10, random_state=SEED)])
    agi = agi.sample(frac=1, random_state=SEED).reset_index(drop=True)
    return add_agi_extras(agi, firm_ids, year)


# Employment form (invented codes): 1 permanent, 2 fixed-term, 3 hourly.
ANSTFORM_P = [0.72, 0.17, 0.11]
# Employers leave the field blank more often for short, hourly jobs, so the
# blanks are NOT a random sample of jobs. Setting them to any code biases shares.
BLANK_P = {"1": 0.03, "2": 0.10, "3": 0.35}


def add_agi_extras(agi: pd.DataFrame, firm_ids: list[str], year: int) -> pd.DataFrame:
    """Add AnstForm (per person and employer) and rows without a person id.

    Uses rng_extra only, so all other columns and rows are exactly those of the
    first release for the same seed. The exact duplicates stay exact, because the
    form is set per person-employer pair and a copy shares its pair.
    """
    pairs = agi[["LopNr", "PeOrgNr"]].drop_duplicates()
    form = rng_extra.choice(["1", "2", "3"], len(pairs), p=ANSTFORM_P)
    blank = rng_extra.random(len(pairs)) < np.array([BLANK_P[f] for f in form])
    pairs = pairs.assign(AnstForm=np.where(blank, "", form))
    agi = agi.merge(pairs, on=["LopNr", "PeOrgNr"], how="left", validate="m:1")

    # Workers without a Swedish person number: the firm declares and pays them,
    # but the delivery has no LopNr. Two or three at each of three firms, with
    # overlapping months, so several share a firm and a month.
    rows = []
    for firm in rng_extra.choice(firm_ids, 3, replace=False):
        for _ in range(int(rng_extra.integers(2, 4))):
            start = int(rng_extra.integers(1, 5))
            months = range(start, start + int(rng_extra.integers(4, 9)))
            form = "3" if rng_extra.random() < 0.6 else "2"
            if rng_extra.random() < 0.5:
                form = ""
            monthly = rng_extra.uniform(14000, 26000)
            for m in months:
                rows.append({"LopNr": "", "PeOrgNr": str(firm),
                             "Period": f"{year}{m:02d}",
                             "Lon": str(int(round(monthly * rng_extra.uniform(0.8, 1.2)))),
                             "AnstForm": form})
    no_id = pd.DataFrame(rows)
    # Insert them at random places, keeping the order of the other rows.
    pos = np.sort(rng_extra.choice(len(agi) + len(no_id), len(no_id), replace=False))
    out = pd.DataFrame(index=range(len(agi) + len(no_id)), columns=agi.columns)
    mask = np.zeros(len(out), bool)
    mask[pos] = True
    out.loc[mask, agi.columns] = no_id[agi.columns].to_numpy()
    out.loc[~mask, agi.columns] = agi.to_numpy()
    return out

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(seed: int = DEFAULT_SEED, out_dir: Path = RAW, label: str = "default",
         quiet: bool = False) -> None:
    """Write every raw file for one seed into out_dir."""
    global SEED, rng, rng_extra
    t0 = time.perf_counter()
    SEED = seed
    rng = np.random.default_rng(seed)
    rng_extra = np.random.default_rng([seed, 1])
    raw = Path(out_dir)
    raw.mkdir(parents=True, exist_ok=True)
    # Empty output folders. The flawed scripts, like much real code, assume
    # their folders already exist and never create them.
    home = raw.parent.parent                    # the pair folder, e.g. pair_07/
    for sub in ["flawed_stata", "flawed_py"]:
        (home / "data" / "processed" / sub).mkdir(parents=True, exist_ok=True)
    (home / "output").mkdir(exist_ok=True)

    persons, truth = make_persons()
    persons.to_csv(raw / "persons.csv", index=False)

    make_ak9(truth).to_csv(raw / "betyg_ak9.csv", index=False)
    make_gymn(truth).to_csv(raw / "gymn_kurser.csv", index=False)

    firm_ids = [f"F{i:05d}" for i in range(1, N_FIRMS + 1)]
    firm_of = dict(zip(truth["lopnr"], rng.choice(firm_ids, N_PERSONS)))
    for year in LISA_YEARS:
        lisa = make_lisa_year(truth, year, firm_of)
        lisa.to_csv(raw / f"lisa_{year}.csv", index=False)
    # The monthly file covers the last year only, to keep it small.
    make_agi(lisa.drop_duplicates(), firm_ids, max(LISA_YEARS)).to_csv(
        raw / f"agi_manad_{max(LISA_YEARS)}.csv", index=False)
    for year, df in make_firms().items():
        df.to_csv(raw / f"foretag_{year}.csv", index=False)

    make_migrations(truth).to_csv(raw / "migrationer.csv", index=False)
    make_spells(truth, range(2019, 2024), n_codes=8, share=0.35,
                numeric_before=None).to_csv(raw / "insatser_kommun.csv", index=False)
    make_spells(truth, range(2013, 2024), n_codes=10, share=0.30,
                numeric_before=STATE_CODE_SWITCH).to_csv(raw / "insatser_stat.csv",
                                                         index=False)

    # Record what produced these files (no date, so a rerun is byte-identical).
    (raw / "GENERATED.txt").write_text(f"seed={seed}\npair={label}\n", encoding="utf-8")

    # A short inventory so the teacher sees what was produced.
    if not quiet:
        print(f"seed {seed} ({label}) -> {raw}")
        files = sorted(raw.glob("*.csv"))
        for f in files:
            n = sum(1 for _ in f.open(encoding="utf-8")) - 1
            print(f"{f.name:24s} {n:6d} rows")
        print(f"End of generation: {len(files)} files, seed {seed}, "
              f"{time.perf_counter() - t0:.1f} s")


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Generate the synthetic register files.")
    ap.add_argument("--seed", type=int, default=None,
                    help=f"random seed (default {DEFAULT_SEED}, or 446000 + pair)")
    ap.add_argument("--pair", type=int, default=None,
                    help="student pair number; sets the seed and the folder pair_XX")
    ap.add_argument("--out", default=None,
                    help="output folder (default data/raw/, data/raw/pair_XX/ or data/raw/seed_N/)")
    return ap.parse_args()


if __name__ == "__main__":
    args = parse_args()
    seed = args.seed if args.seed is not None else (
        seed_for_pair(args.pair) if args.pair is not None else DEFAULT_SEED)
    label = f"pair_{args.pair:02d}" if args.pair is not None else (
        "default" if seed == DEFAULT_SEED else f"seed_{seed}")
    main(seed, output_dir(seed, args.pair, args.out), label)
