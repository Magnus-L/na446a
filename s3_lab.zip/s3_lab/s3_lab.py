"""Session 3 lab: combine register files into a person-year panel.

Put this folder inside your course folder (na446a-starter), open it in VS Code,
and run one cell at a time (click "Run Cell" above each # %% line).
Fill in every TODO. Before you run a cell, write down what you expect.

Your data: pick a free number 1-30 on the whiteboard, download pair_NN.zip
from the Data page, unzip it INTO this folder (you get a folder pair_NN next
to this file), and set PAIR below. Late or absent? Use PAIR = "00", which is
already here. The data are synthetic: no real person is in them.

Check your work at any time: open check_s3.py and run it (or, in the
terminal, `uv run check_s3.py`). It computes the right answers for YOUR pair
and tells you which steps are right.

Steps 1-7 take about 30 minutes, Step 8 (the bug race) 12; finish at home if
needed. The last cell prints "Lab done".
AI rule for today: lines that came from an AI get the comment  # AI:
Never paste real personal or register data into a chatbot.
Lab steps have their own numbers; [slides: Step N] in each header says which
slide steps it practises.
"""
# %% ---- CHANGE HERE (only these lines) ------------------------------
# After a change: run this cell again, then the step that uses it.
PAIR = "00"                    # your pair number from the whiteboard, two digits
FIRST_YEAR = 2019              # the yearly files run from ...
LAST_YEAR = 2023               # ... to
KEY = ["LopNr", "year"]        # what identifies one row of the panel
LAG_COL = "ForvErs"            # the variable to lag: income from work
# ---------------------------------------------------------------------

# %% Step 0: find your pair's folder (done for you)
from pathlib import Path
try:
    import pandas as pd
except ModuleNotFoundError:            # VS Code is using another Python, not the course's .venv
    raise SystemExit("pandas not found: VS Code is not using the course Python. Put this lab "
                     "folder inside na446a-starter, open na446a-starter in VS Code (File > Open "
                     "Folder), choose Python: Select Interpreter > .venv, then Restart. "
                     "See 'Common problems in class' on the Setup page.")

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE       # the lab folder
HOME = ROOT / f"pair_{PAIR}"                 # your pair's folder
if not (HOME / "data").exists():             # unzipped one folder too deep?
    HOME = HOME / f"pair_{PAIR}"
RAW = HOME / "data" / "raw"                  # read, never overwrite
PROC = HOME / "data" / "processed"           # data written by code
print((RAW / "GENERATED.txt").read_text().split())   # which data you have

# %% Step 1: stack the yearly files (append)  [slides: Steps 6-8]
# CODEBOOK.md (in your pair folder), table "lisa_YYYY.csv", gives each
# variable's name in 2019-2020 and in 2021-2023.
# TODO 1a: complete RENAME: every 2021-2023 name -> its 2019-2020 name
RENAME = {"SyssStat19": "SyssStat11"}        # one is done for you
frames = []
for year in range(FIRST_YEAR, LAST_YEAR + 1):
    d = pd.read_csv(RAW / f"lisa_{year}.csv", dtype=str)
    # TODO 1b: rename the columns of d with RENAME and add a column `year`
    #   (hint: the two methods on the Session 3 slides, one after the other)
    d = d
    frames.append(d)
lisa = pd.concat(frames, ignore_index=True)
print(lisa.shape)
# The test: every column should have values in every year. The columns that
# are EMPTY in at least one whole year (you want none):
filled = lisa.notna().groupby(lisa["year"]).mean()
print(filled.loc[:, (filled == 0).any()])
# Your answer: which columns were empty in whole years after the codebook's
# renames, and what does that tell you about the codebook? ...

# %% Step 2: check the key of the panel  [slides: Step 9]
# Predict first: how many person-years appear more than once? ...
# TODO 2a: n_dup_key = the number of rows whose KEY repeats an earlier row
n_dup_key = ...
# TODO 2b: n_dup_row = the number of rows that are exact copies of an earlier row
n_dup_row = ...
# TODO 2c: drop the exact copies from lisa, then assert that KEY is unique

print(n_dup_key, n_dup_row, len(lisa))

# %% Step 3a: a merge that fails ON PURPOSE (predict first: will it run?)  [slides: Steps 3-4]
persons = pd.read_csv(RAW / "persons.csv", dtype=str)
try:
    lisa.merge(persons, on="LopNr", how="left", validate="m:1")
    print("It ran.")
except pd.errors.MergeError as err:              # if it fails, show why
    print("MergeError:", str(err).splitlines()[0])
# Your answer: which table is at fault, and why? ...

# %% Step 3b: fix the persons file, then merge  [slides: Steps 2-5]
# TODO 3a: drop the exact copies from persons. Then n_conflict = the number of
#   ids that STILL appear more than once. Print their rows: what differs?
n_conflict = ...
# TODO 3b: keep the first row of each id (write down which ids you changed),
#   then assert that persons["LopNr"] is unique

# TODO 3c: panel = lisa merged with persons: how="left", validate="m:1",
#   indicator=True. Print the counts of _merge. Assert that panel has as many
#   rows as lisa. Then drop the _merge column.
panel = ...

# %% Step 4: catch the wrong merge an AI proposes  [slides: Steps 3 and 5]
# We asked a chatbot: "Add each person's total pay in 2023 from the monthly
# file agi_manad_2023.csv to the 2023 rows of my panel." It answered with the
# line marked # AI: below.
y23 = panel[panel["year"] == LAST_YEAR]
agi = pd.read_csv(RAW / f"agi_manad_{LAST_YEAR}.csv", dtype=str)
# Predict first: how many rows will `pay` have, compared with len(y23)? ...
pay = y23.merge(agi, on="LopNr")      # AI:
n_ai_rows = len(pay)
print(len(y23), "persons in 2023;", n_ai_rows, "rows after the AI's merge")
# Your answer: name TWO things wrong with this merge (hint: look at the rows
#   of one person, and remember pandas' default how=) ...
# TODO 4: write the right version.
#   agi_year = one row per person: Lon as a number, summed by LopNr
#   pay = y23 merged with agi_year: how="left", validate="1:1", indicator=True
#   n_no_pay = the number of 2023 persons with no declared pay (left_only)
#   assert that pay has as many rows as y23
agi_year = ...
pay = ...
n_no_pay = ...

# %% Step 5: wide and long  [slides: Steps 10-11]
# TODO 5a: wide = one row per person, one column per year, values "SyssStat11"
#   (employment status), with pivot. Print its shape.
wide = ...
# Predict first: how many persons are in all five years? Then compute
# n_all_years (hint: notna(), then all(axis=1), then sum()).
n_all_years = ...
# TODO 5b: long = wide back to long with melt (value_name="status"), the
#   missing cells dropped. Predict its number of rows before you run it.
long = ...
print(n_all_years, len(long), len(panel))

# %% Step 6: a lag within each person, and the gap trap  [slides: Steps 12-13]
# TODO 6a: sort panel by KEY; panel["inc"] = LAG_COL as a number;
#   panel["inc_lag"] = the person's previous inc (groupby, then shift(1))

# TODO 6b: panel["gap"] = year minus the person's previous year (same idea).
#   n_gap = the number of rows where gap > 1. Then set inc_lag to missing
#   where gap is not 1 (.where(...)).
n_gap = ...
# Your answer: why is shift(1) wrong for those rows? What does Stata's L. do? ...

# %% Step 7: save the panel  [not on the slides]
# TODO 7: save panel to PROC / "panel.parquet" and print its shape


# %% Step 8: bug race (level 1): 12 minutes, in pairs
# clean_registers_flawed.py (in this folder) is a cleaning script written the
# way real register code often is, errors included.
# 1. Make it run on YOUR data: open it, Find and Replace (Ctrl+H, Mac Cmd+Alt+F)
#    the text   C:/Users/teacher/project/   with the full path of your pair
#    folder, with forward slashes and a slash at the end, for example
#    C:/Users/anna/Documents/na446a/s3-lab/pair_07/  or  /Users/anna/na446a/s3-lab/pair_07/
#    Save it, run the whole file. It writes into data/processed/flawed_py/.
# 2. Read its OUTPUT files (pd.read_csv on FLAWED / "se_....csv") and find what
#    is wrong without reading its logic: rows, years, missing values, keys.
# 3. A bug counts only when you can say: which file, what is wrong, and a number.
FLAWED = PROC / "flawed_py"
# Bug 1: ...
# Bug 2: ...
# Bug 3: ...
# Bug 4: ...
# Bug 5: ...

# %% If you finish early (optional): the person-firm-year join
# Stack foretag_2019.csv ... foretag_2023.csv with a column `year`. Is
# ["PeOrgNr", "year"] a key? Fix what you find, then merge the firms onto the
# panel with left_on=["KU1PeOrgNr", "year"], right_on=["PeOrgNr", "year"],
# how="left", validate="m:1", indicator=True. Does every employed person-year
# find its firm?

# %%
print("Lab done")
