"""Self-check for the Session 3 lab: which of your steps are right, for YOUR pair?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_s3.py                 checks s3_lab.py, for the PAIR set in it
    uv run check_s3.py 07              checks s3_lab.py as pair 07
    uv run check_s3.py my_copy.py 07   checks another file

How it knows the right answers: it makes your pair's data again from
make_synthetic_registers.py (same seed, so the same files), in a temporary
folder, and computes each answer on them. It also warns you if the data in
your pair folder are not your pair's data. It runs your lab script cell by
cell (a cell that fails is reported and skipped, so one error does not hide
the rest). It never changes your script or your data.
Runtime: about 3 seconds. Last line printed: "N of 8 steps right."
"""
import contextlib
import io
import sys
import tempfile
import traceback
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import make_synthetic_registers as gen  # noqa: E402  (the lab's own copy)

# The renames the data need (the reference answer to Step 1)
RENAME = {"SyssStat19": "SyssStat11", "Sun2020Niva": "Sun2000Niva",
          "Sun2020Niva_Old": "Sun2000Niva_Old", "AGI1SSYK4": "KU1SSYK4",
          "AGI1Ink": "KU1Ink", "AGI1PeOrgNr": "KU1PeOrgNr"}
KEY = ["LopNr", "year"]


def split_cells(script: Path) -> list[str]:
    """Split a # %% script into its cells."""
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    return cells


def run_cells(script: Path, pair: str | None) -> dict:
    """Run the script cell by cell in one namespace, as VS Code does.

    If a pair is given, PAIR is set to it right after the CHANGE HERE cell.
    """
    ns = {"__file__": str(script), "__name__": "__lab__"}
    for i, cell in enumerate(split_cells(script)):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
        if pair is not None and "PAIR" in ns and "CHANGE HERE" in cell:
            ns["PAIR"] = pair
    return ns


def expected_answers(pair: int) -> dict:
    """Make the pair's data in a temporary folder and compute every answer."""
    seed = gen.DEFAULT_SEED if pair == 0 else gen.seed_for_pair(pair)
    e = {}
    with tempfile.TemporaryDirectory() as tmp:
        raw = Path(tmp) / "data" / "raw"
        gen.main(seed, raw, "check", quiet=True)
        e["persons_csv"] = (raw / "persons.csv").read_bytes()
        frames = [pd.read_csv(raw / f"lisa_{y}.csv", dtype=str)
                  .rename(columns=RENAME).assign(year=y) for y in range(2019, 2024)]
        lisa = pd.concat(frames, ignore_index=True)
        e["columns"] = set(frames[0].columns)
        e["n_dup_key"] = int(lisa.duplicated(KEY).sum())
        e["n_dup_row"] = int(lisa.duplicated().sum())
        lisa = lisa.drop_duplicates()
        e["n_panel"] = len(lisa)
        persons = pd.read_csv(raw / "persons.csv", dtype=str).drop_duplicates()
        conflict = persons.duplicated("LopNr", keep=False)
        e["n_conflict"] = int(persons.loc[conflict, "LopNr"].nunique())
        persons = persons.drop_duplicates("LopNr")
        panel = lisa.merge(persons, on="LopNr", how="left", validate="m:1")
        y23 = panel[panel["year"] == 2023]
        agi = pd.read_csv(raw / "agi_manad_2023.csv", dtype=str)
        e["n_y23"] = len(y23)
        e["n_ai_rows"] = len(y23.merge(agi, on="LopNr"))
        e["n_no_pay"] = int((~y23["LopNr"].isin(agi["LopNr"])).sum())
        wide = panel.pivot(index="LopNr", columns="year", values="SyssStat11")
        e["wide_shape"] = wide.shape
        e["n_all_years"] = int(wide.notna().all(axis=1).sum())
        panel = panel.sort_values(KEY)
        g = panel.groupby("LopNr")
        gap = panel["year"] - g["year"].shift(1)
        e["n_gap"] = int((gap > 1).sum())
        e["n_lag"] = int((gap == 1).sum())
    return e


def main() -> None:
    args = sys.argv[1:]
    script_arg = next((a for a in args if a.endswith(".py")), "s3_lab.py")
    pair_arg = next((a for a in args if a.isdigit()), None)
    script = HERE / script_arg
    print(f"Checking {script.name} ...")
    before = {}                                  # file times before the run: the
    for f in HERE.glob("*/data/processed/panel.parquet"):   # file must be written
        before[f.resolve()] = f.stat().st_mtime_ns          # by THIS run
    with contextlib.redirect_stdout(io.StringIO()) as quiet:   # hide the lab's prints
        ns = run_cells(script, None if pair_arg is None else f"{int(pair_arg):02d}")
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]

    pair = int(pair_arg) if pair_arg is not None else int(ns.get("PAIR", "0"))
    print(f"Pair {pair:02d}: computing the right answers from the generator ...\n")
    e = expected_answers(pair)

    raw = ns.get("RAW")
    if raw is None or not (Path(raw) / "persons.csv").exists():
        print(f"Warning: no data found for pair {pair:02d}. Unzip pair_{pair:02d}.zip "
              f"into the lab folder, or set PAIR in the CHANGE HERE block.\n")
    elif (Path(raw) / "persons.csv").read_bytes() != e["persons_csv"]:
        print(f"Warning: the files in {raw} are not pair {pair:02d}'s data. "
              f"Is PAIR right, and did you unzip the right pair_NN.zip?\n")
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    lisa, panel, pay = ns.get("lisa"), ns.get("panel"), ns.get("pay")
    results = []

    def step(name, test, hint):
        """Run one check; print OK or a friendly hint, never crash."""
        try:
            passed = bool(test())
        except Exception:                               # missing variable etc.
            passed = False
        results.append(passed)
        print(f"{'OK      ' if passed else 'NOT YET '} {name}")
        if not passed:
            print(f"         hint: {hint}")

    def step1():
        filled = lisa.notna().groupby(lisa["year"]).mean()
        return (set(lisa.columns) >= e["columns"] and "year" in lisa.columns
                and not (filled == 0).any().any())
    step("Step 1  five years stacked, every column filled in every year",
         step1,
         "rename each file with RENAME and add `year` INSIDE the loop; then no column "
         "may be empty in a whole year. Is every renamed variable in RENAME? Compare "
         "the columns of lisa_2020.csv and lisa_2021.csv yourself.")
    step("Step 2  key checked, exact copies dropped",
         lambda: ns["n_dup_key"] == e["n_dup_key"] and ns["n_dup_row"] == e["n_dup_row"]
         and len(lisa) == e["n_panel"] and not lisa.duplicated(KEY).any(),
         f"use lisa.duplicated(KEY).sum() and lisa.duplicated().sum(); after "
         f"drop_duplicates() lisa should have {e['n_panel']} rows.")
    step("Step 3  persons fixed, merged with validate and indicator",
         lambda: ns["n_conflict"] == e["n_conflict"] and ns["persons"]["LopNr"].is_unique
         and len(panel) == len(lisa) and "Kon" in panel.columns
         and "_merge" not in panel.columns,
         "n_conflict counts ids (not rows) still duplicated after drop_duplicates(); keep "
         "the first row per id; a left merge must keep every row of lisa; drop _merge.")
    step("Step 4  the AI's merge caught and fixed",
         lambda: ns["n_ai_rows"] == e["n_ai_rows"] and len(pay) == e["n_y23"]
         and ns["n_no_pay"] == e["n_no_pay"] and pay["LopNr"].is_unique,
         "sum Lon by LopNr first (one row per person), then a LEFT merge with "
         "validate='1:1' and indicator=True; n_no_pay counts left_only.")
    step("Step 5  pivot to wide, melt back to long",
         lambda: ns["wide"].shape == e["wide_shape"]
         and ns["n_all_years"] == e["n_all_years"] and len(ns["long"]) == e["n_panel"],
         "pivot(index='LopNr', columns='year', values='SyssStat11'); after melt, "
         "dropna() so long has one row per person-year, as the panel.")
    step("Step 6  lag within person, gaps set to missing",
         lambda: ns["n_gap"] == e["n_gap"]
         and panel["inc_lag"].notna().sum() == e["n_lag"],
         "sort by KEY first; shift(1) within groupby('LopNr') for inc and for year; "
         "inc_lag must be missing wherever gap is not 1.")

    def saved():
        f = Path(ns["PROC"]) / "panel.parquet"
        return (f.stat().st_mtime_ns > before.get(f.resolve(), 0)
                and len(pd.read_parquet(f)) == e["n_panel"])
    step("Step 7  panel saved to data/processed/panel.parquet", saved,
         'panel.to_parquet(PROC / "panel.parquet"), after Step 6.')

    def race():
        text = script.read_text(encoding="utf-8")
        filled = [ln for ln in text.splitlines()
                  if ln.startswith("# Bug") and not ln.rstrip().endswith("...")]
        return len(filled) >= 3
    step("Step 8  bug race: at least three bugs written down", race,
         "write each bug on its '# Bug n:' line: file, what is wrong, a number "
         "(checked only for being filled in; the class compares answers).")

    print(f"\n{sum(results)} of {len(results)} steps right.")


if __name__ == "__main__":
    main()
