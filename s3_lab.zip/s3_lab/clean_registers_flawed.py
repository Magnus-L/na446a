"""
clean_registers_flawed.py

Cleans the register files before merging. Python version of the do-file,
for those without Stata.

Written in March. Run the whole file from top to bottom.
"""

import numpy as np
import pandas as pd

# ***** START A LOG FILE ****
log = open("C:/Users/teacher/project/output/clean_registers_py.log", "w")


# ******* persons - OK
# Contains everybody in the study population and basic vars
df = pd.read_csv("C:/Users/teacher/project/data/raw/persons.csv", dtype=str)
df.info(buf=log)
# fix lopnr
df = df.rename(columns={"LopNr": "lopnr"})
# fodelsear convert to numeric
df["fodelsear"] = df["FodelseAr"].astype(int)
df["kon"] = df["Kon"].astype(int)          # (2,1) woman, man
# fix fodelsemanad
df["fodelsemanad"] = pd.to_datetime(df["FodelseManad"] + "15", format="%Y%m%d")
# fix fodelselandnamn
df["foddsverige"] = np.where(df["FodelseLandNamn"] == "SVERIGE", 1, 0)
# fix DodDatum
df["doddatum"] = pd.to_datetime(df["DodDatum"], format="%Y%m%d")
df = df.drop(columns=["FodelseAr", "Kon", "FodelseManad", "FodelseLandNamn", "DodDatum"])
# there are some duplicates in the delivery, remove them
df = df.drop_duplicates()
df.sort_values("lopnr")
print(df.describe(include="all"), file=log)
# All vars in correct format and no strange values
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_persons.csv", index=False)


# *** ak9
# Contains grades from grade 9
df = pd.read_csv("C:/Users/teacher/project/data/raw/betyg_ak9.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
df["ak9ar"] = pd.to_datetime(df["Ar"], format="%Y").dt.year
df = df.drop(columns=["Ar"])

# betyg
# convert grades to numerical
# IG = not passed, G = passed, VG = passed with distinction, MVG = passed with special
# distinction, A = no grades in any subject, 2 = subject not taken, * = unknown
df["bild"] = np.nan                                       # grades in art
df.loc[df["BILD"] == "G", "bild"] = 10
df.loc[(df["BILD"] == "V") | (df["BILD"] == "VG"), "bild"] = 15
df.loc[(df["BILD"] == "M") | (df["BILD"] == "MVG"), "bild"] = 20
df.loc[(df["BILD"] == "1") | (df["BILD"] == "I") | (df["BILD"] == "IG"), "bild"] = 0
df.loc[(df["BILD"] == "A") | (df["BILD"] == "*") | (df["BILD"] == "2"), "bild"] = np.nan

df["eng"] = np.nan                                       # grades in English
df.loc[df["ENGELSKA"] == "G", "eng"] = 10
df.loc[(df["ENGELSKA"] == "V") | (df["ENGELSKA"] == "VG"), "eng"] = 15
df.loc[(df["ENGELSKA"] == "M") | (df["ENGELSKA"] == "MVG"), "eng"] = 20
df.loc[(df["ENGELSKA"] == "1") | (df["ENGELSKA"] == "I") | (df["ENGELSKA"] == "IG"), "eng"] = 0
df.loc[(df["ENGELSKA"] == "A") | (df["ENGELSKA"] == "*") | (df["ENGELSKA"] == "2"), "eng"] = np.nan

df["hkk"] = np.nan                                       # grades in home economics
df.loc[df["HEMKUNSKAP"] == "G", "hkk"] = 10
df.loc[(df["HEMKUNSKAP"] == "V") | (df["HEMKUNSKAP"] == "VG"), "hkk"] = 15
df.loc[(df["HEMKUNSKAP"] == "M") | (df["HEMKUNSKAP"] == "MVG"), "hkk"] = 20
df.loc[(df["HEMKUNSKAP"] == "1") | (df["HEMKUNSKAP"] == "I") | (df["HEMKUNSKAP"] == "IG"), "hkk"] = 0
df.loc[(df["HEMKUNSKAP"] == "A") | (df["HEMKUNSKAP"] == "*") | (df["HEMKUNSKAP"] == "2"), "hkk"] = np.nan

df["idh"] = np.nan                                       # grades in physical education
df.loc[df["IDROTT"] == "G", "idh"] = 10
df.loc[(df["IDROTT"] == "V") | (df["IDROTT"] == "VG"), "idh"] = 15
df.loc[(df["IDROTT"] == "M") | (df["IDROTT"] == "MVG"), "idh"] = 20
df.loc[(df["IDROTT"] == "1") | (df["IDROTT"] == "I") | (df["IDROTT"] == "IG"), "idh"] = 0
df.loc[(df["IDROTT"] == "A") | (df["IDROTT"] == "*") | (df["IDROTT"] == "2"), "idh"] = np.nan

df["maths"] = np.nan                                       # grades in mathematics
df.loc[df["MATEMATIK"] == "G", "maths"] = 10
df.loc[(df["MATEMATIK"] == "V") | (df["MATEMATIK"] == "VG"), "maths"] = 15
df.loc[(df["MATEMATIK"] == "M") | (df["MATEMATIK"] == "MVG"), "maths"] = 20
df.loc[(df["MATEMATIK"] == "1") | (df["MATEMATIK"] == "I") | (df["MATEMATIK"] == "IG"), "maths"] = 0
df.loc[(df["MATEMATIK"] == "A") | (df["MATEMATIK"] == "*") | (df["MATEMATIK"] == "2"), "maths"] = np.nan

df["mu"] = np.nan                                       # grades in music
df.loc[df["MUSIK"] == "G", "mu"] = 10
df.loc[(df["MUSIK"] == "V") | (df["MUSIK"] == "VG"), "mu"] = 15
df.loc[(df["MUSIK"] == "M") | (df["MUSIK"] == "MVG"), "mu"] = 20
df.loc[(df["MUSIK"] == "1") | (df["MUSIK"] == "I") | (df["MUSIK"] == "IG"), "mu"] = 0
df.loc[(df["MUSIK"] == "A") | (df["MUSIK"] == "*") | (df["MUSIK"] == "2"), "mu"] = np.nan

df["bi"] = np.nan                                       # grades in biology
df.loc[df["BIOLOGI"] == "G", "bi"] = 10
df.loc[(df["BIOLOGI"] == "V") | (df["BIOLOGI"] == "VG"), "bi"] = 15
df.loc[(df["BIOLOGI"] == "M") | (df["BIOLOGI"] == "MVG"), "bi"] = 20
df.loc[(df["BIOLOGI"] == "1") | (df["BIOLOGI"] == "I") | (df["BIOLOGI"] == "IG"), "bi"] = 0
df.loc[(df["BIOLOGI"] == "A") | (df["BIOLOGI"] == "*") | (df["BIOLOGI"] == "2"), "bi"] = np.nan

df["fy"] = np.nan                                       # grades in physics
df.loc[df["FYSIK"] == "G", "fy"] = 10
df.loc[(df["FYSIK"] == "V") | (df["FYSIK"] == "VG"), "fy"] = 15
df.loc[(df["FYSIK"] == "M") | (df["FYSIK"] == "MVG"), "fy"] = 20
df.loc[(df["FYSIK"] == "1") | (df["FYSIK"] == "I") | (df["FYSIK"] == "IG"), "fy"] = 0
df.loc[(df["FYSIK"] == "A") | (df["FYSIK"] == "*") | (df["FYSIK"] == "2"), "fy"] = np.nan

df["ke"] = np.nan                                       # grades in chemistry
df.loc[df["KEMI"] == "G", "ke"] = 10
df.loc[(df["KEMI"] == "V") | (df["KEMI"] == "VG"), "ke"] = 15
df.loc[(df["KEMI"] == "M") | (df["KEMI"] == "MVG"), "ke"] = 20
df.loc[(df["KEMI"] == "1") | (df["KEMI"] == "I") | (df["KEMI"] == "IG"), "ke"] = 0
df.loc[(df["KEMI"] == "A") | (df["KEMI"] == "*") | (df["KEMI"] == "2"), "ke"] = np.nan

df["geo"] = np.nan                                       # grades in geography
df.loc[df["GEOGRAFI"] == "G", "geo"] = 10
df.loc[(df["GEOGRAFI"] == "V") | (df["GEOGRAFI"] == "VG"), "geo"] = 15
df.loc[(df["GEOGRAFI"] == "M") | (df["GEOGRAFI"] == "MVG"), "geo"] = 20
df.loc[(df["GEOGRAFI"] == "1") | (df["GEOGRAFI"] == "I") | (df["GEOGRAFI"] == "IG"), "geo"] = 0
df.loc[(df["GEOGRAFI"] == "A") | (df["GEOGRAFI"] == "*") | (df["GEOGRAFI"] == "2"), "geo"] = np.nan

df["hi"] = np.nan                                       # grades in history
df.loc[df["HISTORIA"] == "G", "hi"] = 10
df.loc[(df["HISTORIA"] == "V") | (df["HISTORIA"] == "VG"), "hi"] = 15
df.loc[(df["HISTORIA"] == "M") | (df["HISTORIA"] == "MVG"), "hi"] = 20
df.loc[(df["HISTORIA"] == "1") | (df["HISTORIA"] == "I") | (df["HISTORIA"] == "IG"), "hi"] = 0
df.loc[(df["HISTORIA"] == "A") | (df["HISTORIA"] == "*") | (df["HISTORIA"] == "2"), "hi"] = np.nan

df["re"] = np.nan                                       # grades in religion
df.loc[df["RELIGION"] == "G", "re"] = 10
df.loc[(df["RELIGION"] == "V") | (df["RELIGION"] == "VG"), "re"] = 15
df.loc[(df["RELIGION"] == "M") | (df["RELIGION"] == "MVG"), "re"] = 20
df.loc[(df["RELIGION"] == "1") | (df["RELIGION"] == "I") | (df["RELIGION"] == "IG"), "re"] = 0
df.loc[(df["RELIGION"] == "A") | (df["RELIGION"] == "*") | (df["RELIGION"] == "2"), "re"] = np.nan

df["samh"] = np.nan                                       # grades in civics
df.loc[df["SAMHALL"] == "G", "samh"] = 10
df.loc[(df["SAMHALL"] == "V") | (df["SAMHALL"] == "VG"), "samh"] = 15
df.loc[(df["SAMHALL"] == "M") | (df["SAMHALL"] == "MVG"), "samh"] = 20
df.loc[(df["SAMHALL"] == "1") | (df["SAMHALL"] == "I") | (df["SAMHALL"] == "IG"), "samh"] = 0
df.loc[(df["SAMHALL"] == "A") | (df["SAMHALL"] == "*") | (df["SAMHALL"] == "2"), "samh"] = np.nan

df["sl"] = np.nan                                       # grades in crafts
df.loc[df["SLOJD"] == "G", "sl"] = 10
df.loc[(df["SLOJD"] == "V") | (df["SLOJD"] == "VG"), "sl"] = 15
df.loc[(df["SLOJD"] == "M") | (df["SLOJD"] == "MVG"), "sl"] = 20
df.loc[(df["SLOJD"] == "1") | (df["SLOJD"] == "I") | (df["SLOJD"] == "IG"), "sl"] = 0
df.loc[(df["SLOJD"] == "A") | (df["SLOJD"] == "*") | (df["SLOJD"] == "2"), "sl"] = np.nan

df["sv"] = np.nan                                       # grades in Swedish
df.loc[df["SVENSKA"] == "G", "sv"] = 10
df.loc[(df["SVENSKA"] == "V") | (df["SVENSKA"] == "VG"), "sv"] = 15
df.loc[(df["SVENSKA"] == "M") | (df["SVENSKA"] == "MVG"), "sv"] = 20
df.loc[(df["SVENSKA"] == "1") | (df["SVENSKA"] == "I") | (df["SVENSKA"] == "IG"), "sv"] = 0
df.loc[(df["SVENSKA"] == "A") | (df["SVENSKA"] == "*") | (df["SVENSKA"] == "2"), "sv"] = np.nan

df["tk"] = np.nan                                       # grades in technology
df.loc[df["TEKNIK"] == "G", "tk"] = 10
df.loc[(df["TEKNIK"] == "V") | (df["TEKNIK"] == "VG"), "tk"] = 15
df.loc[(df["TEKNIK"] == "M") | (df["TEKNIK"] == "MVG"), "tk"] = 20
df.loc[(df["TEKNIK"] == "1") | (df["TEKNIK"] == "I") | (df["TEKNIK"] == "IG"), "tk"] = 0
df.loc[(df["TEKNIK"] == "A") | (df["TEKNIK"] == "*") | (df["TEKNIK"] == "2"), "tk"] = np.nan

df["mspr1"] = np.nan                                       # grades in modern language 1
df.loc[df["SPRAK1"] == "G", "mspr1"] = 10
df.loc[(df["SPRAK1"] == "V") | (df["SPRAK1"] == "VG"), "mspr1"] = 15
df.loc[(df["SPRAK1"] == "M") | (df["SPRAK1"] == "MVG"), "mspr1"] = 20
df.loc[(df["SPRAK1"] == "1") | (df["SPRAK1"] == "I") | (df["SPRAK1"] == "IG"), "mspr1"] = 0
df.loc[(df["SPRAK1"] == "A") | (df["SPRAK1"] == "*") | (df["SPRAK1"] == "2"), "mspr1"] = np.nan

df["mspr2"] = np.nan                                       # grades in modern language 2
df.loc[df["SPRAK2"] == "G", "mspr2"] = 10
df.loc[(df["SPRAK2"] == "V") | (df["SPRAK2"] == "VG"), "mspr2"] = 15
df.loc[(df["SPRAK2"] == "M") | (df["SPRAK2"] == "MVG"), "mspr2"] = 20
df.loc[(df["SPRAK2"] == "1") | (df["SPRAK2"] == "I") | (df["SPRAK2"] == "IG"), "mspr2"] = 0
df.loc[(df["SPRAK2"] == "A") | (df["SPRAK2"] == "*") | (df["SPRAK2"] == "2"), "mspr2"] = np.nan

subjects = ["bild", "eng", "hkk", "idh", "maths", "mu", "bi", "fy", "ke", "geo", "hi", "re", "samh", "sl", "sv", "tk", "mspr1", "mspr2"]
df = df.drop(columns=["BILD", "ENGELSKA", "HEMKUNSKAP", "IDROTT", "MATEMATIK", "MUSIK", "BIOLOGI", "FYSIK", "KEMI", "GEOGRAFI", "HISTORIA", "RELIGION", "SAMHALL", "SLOJD", "SVENSKA", "TEKNIK", "SPRAK1", "SPRAK2"])

# Total grade (meritvarde) is the sum of the 16 best grades
# Some persons are registered two years after each other. If two grades, it is the latest
# grade that should be used. Taking the max gives the latest grade in most cases, we checked a few.
df = df.groupby("lopnr")[subjects].max().reset_index()

# reshape long
df = df.melt(id_vars="lopnr", value_vars=subjects, value_name="betyg")
df = df.drop(columns=["variable"])

df.loc[df["betyg"] == 0, "betyg"] = np.nan

df = df.sort_values(["lopnr", "betyg"])
df["rank"] = df.groupby("lopnr").cumcount() + 1
df["top16_flag"] = df["rank"] <= 16
df["totalbetyg_ak9"] = df["betyg"].where(df["top16_flag"]).groupby(df["lopnr"]).transform("sum")
df.loc[~df["top16_flag"], "totalbetyg_ak9"] = np.nan
print(df.head(40), file=log)

df = df.drop(columns=["betyg", "top16_flag", "rank"])
df = df.dropna(subset=["totalbetyg_ak9"])
df.drop_duplicates()

df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_ak9.csv", index=False)


# *** gymn
# Contains grades from upper secondary school, one row per course
df = pd.read_csv("C:/Users/teacher/project/data/raw/gymn_kurser.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
df["avgar"] = pd.to_datetime(df["AvgAr"], format="%Y").dt.year
df["poang"] = df["Poang"].astype(float)

# Change grades to nummerical
df["betyg"] = np.nan
df.loc[(df["Betyg"] == "IG") | (df["Betyg"] == "I"), "betyg"] = 0
df.loc[df["Betyg"] == "G", "betyg"] = 10
df.loc[(df["Betyg"] == "VG") | (df["Betyg"] == "V"), "betyg"] = 15
df.loc[(df["Betyg"] == "MVG") | (df["Betyg"] == "M"), "betyg"] = 20

# Try to calculate final grades, slutbetyg (points-weighted average)
df["x"] = df["betyg"] * df["poang"]
df["tot"] = df.groupby("lopnr")["x"].transform("sum")
df["totkursp"] = df.groupby("lopnr")["poang"].transform("sum")

df["slutbetyggym"] = (df["tot"] / df["totkursp"]).astype(int)

df = df[["lopnr", "slutbetyggym"]].drop_duplicates()
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_gymn.csv", index=False)


# ********** LISA *********
# Comment: SCB has good documentation on LISA with detailed info about the vars,
# see the background facts pdf on scb.se

# LISA2019
# contains lots of info for each individual about labour market etc
df = pd.read_csv("C:/Users/teacher/project/data/raw/lisa_2019.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
# Change to lower case var names
df.columns = df.columns.str.lower()

# fix SenInvAr
df.loc[df["seninvar"] == "0000", "seninvar"] = np.nan
df["seninvar"] = pd.to_datetime(df["seninvar"], format="%Y").dt.year

# barn
for b in ["barn0_3", "barn4_6", "barn7_10", "barn11_15", "barn16_17"]:
    df[b] = pd.to_numeric(df[b])
df["barn0_17"] = df["barn0_3"] + df["barn4_6"] + df["barn7_10"] + df["barn11_15"] + df["barn16_17"]
df["barn0_17"] = df["barn0_17"].fillna(0)      # No. of children 0-17, if any, otherwise 0

# fix examar
df["examar"] = pd.to_datetime(df["examar"], format="%Y").dt.year

# replace erroneous missing demarker * with true missing
df.loc[df["sun2000niva_old"] == "*", "sun2000niva_old"] = np.nan
df.loc[df["sun2000niva"] == "999", "sun2000niva"] = np.nan

# destring several vars
for v in ["sun2000niva_old", "sun2000niva", "fodelt", "hsdelt", "syssstat11", "ku1ink", "forvers", "kapink", "stud", "alosdag"]:
    df[v] = pd.to_numeric(df[v])

# educational level- new variable
df["educat_level"] = np.nan
df.loc[(df["sun2000niva"] == 100) | (df["sun2000niva"] == 106), "educat_level"] = 1
df.loc[(df["sun2000niva"] == 200) | (df["sun2000niva"] == 206), "educat_level"] = 2
df.loc[(df["sun2000niva"] == 310) | (df["sun2000niva"] == 312) | (df["sun2000niva"] == 316), "educat_level"] = 3
df.loc[(df["sun2000niva"] == 320) | (df["sun2000niva"] == 322) | (df["sun2000niva"] == 326), "educat_level"] = 4
df.loc[(df["sun2000niva"] == 330) | (df["sun2000niva"] == 332) | (df["sun2000niva"] == 336), "educat_level"] = 5
df.loc[(df["sun2000niva"] == 410) | (df["sun2000niva"] == 412) | (df["sun2000niva"] == 416), "educat_level"] = 6
df.loc[(df["sun2000niva"] == 520) | (df["sun2000niva"] == 522) | (df["sun2000niva"] == 526), "educat_level"] = 7
df.loc[(df["sun2000niva"] == 530) | (df["sun2000niva"] == 532) | (df["sun2000niva"] == 536), "educat_level"] = 8
df.loc[(df["sun2000niva"] == 540) | (df["sun2000niva"] == 546), "educat_level"] = 9
df.loc[(df["sun2000niva"] == 550) | (df["sun2000niva"] == 556), "educat_level"] = 10
df.loc[(df["sun2000niva"] == 600) | (df["sun2000niva"] == 640), "educat_level"] = 11

# higher education current studies
df["hsdelt2"] = df["hsdelt"].replace({2: 1, 3: 1})   # (1,0) registered hi-educ studies (not PhD)
df["fodelt2"] = df["fodelt"].replace({2: 1, 3: 1})   # (1,0) registered PhD studies
df["hieduc"] = np.where((df["hsdelt"] == 1) | (df["fodelt"] == 1), 1, 0)

# employment status: (1,0) employed and/or entrepreneur, or not (categories 5 and 6)
df["working"] = df["syssstat11"].replace({5: 0, 6: 0})

# occupational group
df.loc[df["ku1ssyk4"] == "****", "ku1ssyk4"] = np.nan
df["occgrp"] = pd.to_numeric(df["ku1ssyk4"].str[0])

# studying (getting study income, irrespective of level)
df["stud2"] = np.nan
df.loc[(df["stud"] > 0) & df["stud"].notna(), "stud2"] = 1

# unemployment
df["unemp"] = np.where(df["alosdag"] > 0, 1, 0)

df = df[["lopnr", "educat_level", "ku1peorgnr", "seninvar", "barn0_17", "examar", "hsdelt2", "fodelt2", "hieduc", "working", "occgrp", "stud2", "unemp", "forvers", "kapink", "ku1ink"]]
df["year"] = 2019
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2019.csv", index=False)


# LISA2020
# contains lots of info for each individual about labour market etc
df = pd.read_csv("C:/Users/teacher/project/data/raw/lisa_2020.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
# Change to lower case var names
df.columns = df.columns.str.lower()

# fix SenInvAr
df.loc[df["seninvar"] == "0000", "seninvar"] = np.nan
df["seninvar"] = pd.to_datetime(df["seninvar"], format="%Y").dt.year

# barn
for b in ["barn0_3", "barn4_6", "barn7_10", "barn11_15", "barn16_17"]:
    df[b] = pd.to_numeric(df[b])
df["barn0_17"] = df["barn0_3"] + df["barn4_6"] + df["barn7_10"] + df["barn11_15"] + df["barn16_17"]
df["barn0_17"] = df["barn0_17"].fillna(0)      # No. of children 0-17, if any, otherwise 0

# fix examar
df["examar"] = pd.to_datetime(df["examar"], format="%Y").dt.year

# replace erroneous missing demarker * with true missing
df.loc[df["sun2000niva_old"] == "*", "sun2000niva_old"] = np.nan
df.loc[df["sun2000niva"] == "999", "sun2000niva"] = np.nan

# destring several vars
for v in ["sun2000niva_old", "sun2000niva", "fodelt", "hsdelt", "syssstat11", "ku1ink", "forvers", "kapink", "stud", "alosdag"]:
    df[v] = pd.to_numeric(df[v])

# educational level- new variable
df["educat_level"] = np.nan
df.loc[(df["sun2000niva"] == 100) | (df["sun2000niva"] == 106), "educat_level"] = 1
df.loc[(df["sun2000niva"] == 200) | (df["sun2000niva"] == 206), "educat_level"] = 2
df.loc[(df["sun2000niva"] == 310) | (df["sun2000niva"] == 312) | (df["sun2000niva"] == 316), "educat_level"] = 3
df.loc[(df["sun2000niva"] == 320) | (df["sun2000niva"] == 322) | (df["sun2000niva"] == 326), "educat_level"] = 4
df.loc[(df["sun2000niva"] == 330) | (df["sun2000niva"] == 332) | (df["sun2000niva"] == 336), "educat_level"] = 5
df.loc[(df["sun2000niva"] == 410) | (df["sun2000niva"] == 412) | (df["sun2000niva"] == 416), "educat_level"] = 6
df.loc[(df["sun2000niva"] == 520) | (df["sun2000niva"] == 522) | (df["sun2000niva"] == 526), "educat_level"] = 7
df.loc[(df["sun2000niva"] == 530) | (df["sun2000niva"] == 532) | (df["sun2000niva"] == 536), "educat_level"] = 8
df.loc[(df["sun2000niva"] == 540) | (df["sun2000niva"] == 546), "educat_level"] = 9
df.loc[(df["sun2000niva"] == 550) | (df["sun2000niva"] == 556), "educat_level"] = 10
df.loc[(df["sun2000niva"] == 600) | (df["sun2000niva"] == 640), "educat_level"] = 11

# higher education current studies
df["hsdelt2"] = df["hsdelt"].replace({2: 1, 3: 1})   # (1,0) registered hi-educ studies (not PhD)
df["fodelt2"] = df["fodelt"].replace({2: 1, 3: 1})   # (1,0) registered PhD studies
df["hieduc"] = np.where((df["hsdelt"] == 1) | (df["fodelt"] == 1), 1, 0)

# employment status: (1,0) employed and/or entrepreneur, or not (categories 5 and 6)
df["working"] = df["syssstat11"].replace({5: 0, 6: 0})

# occupational group
df.loc[df["ku1ssyk4"] == "****", "ku1ssyk4"] = np.nan
df["occgrp"] = pd.to_numeric(df["ku1ssyk4"].str[0])

# studying (getting study income, irrespective of level)
df["stud2"] = np.nan
df.loc[(df["stud"] > 0) & df["stud"].notna(), "stud2"] = 1

# unemployment
df["unemp"] = np.where(df["alosdag"] > 0, 1, 0)

df = df[["lopnr", "educat_level", "ku1peorgnr", "seninvar", "barn0_17", "examar", "hsdelt2", "fodelt2", "hieduc", "working", "occgrp", "stud2", "unemp", "forvers", "kapink", "ku1ink"]]
df["year"] = 2019
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2020.csv", index=False)


# LISA2021
# contains lots of info for each individual about labour market etc
df = pd.read_csv("C:/Users/teacher/project/data/raw/lisa_2021.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
# Sun2000Niva and Sun2000Niva_Old do not exist any longer, Sun2020Niva and Sun2020Niva_Old are used now
# Also SyssStat11 is replaced by SyssStat19
# KU1Ink KU1SSYK4 KU1PeOrgNr replaced by AGI1Ink AGI1SSYK4 AGI1PeOrgNr
# Change to lower case var names
df.columns = df.columns.str.lower()

# fix SenInvAr
df.loc[df["seninvar"] == "0000", "seninvar"] = np.nan
df["seninvar"] = pd.to_datetime(df["seninvar"], format="%Y").dt.year

# barn
for b in ["barn0_3", "barn4_6", "barn7_10", "barn11_15", "barn16_17"]:
    df[b] = pd.to_numeric(df[b])
df["barn0_17"] = df["barn0_3"] + df["barn4_6"] + df["barn7_10"] + df["barn11_15"] + df["barn16_17"]
df["barn0_17"] = df["barn0_17"].fillna(0)      # No. of children 0-17, if any, otherwise 0

# fix examar
df["examar"] = pd.to_datetime(df["examar"], format="%Y").dt.year

# replace erroneous missing demarker * with true missing
df.loc[df["sun2020niva_old"] == "*", "sun2020niva_old"] = np.nan
df.loc[df["sun2020niva"] == "999", "sun2020niva"] = np.nan

# destring several vars
for v in ["sun2020niva_old", "sun2020niva", "fodelt", "hsdelt", "syssstat19", "agi1ink", "forvers", "kapink", "stud", "alosdag"]:
    df[v] = pd.to_numeric(df[v])

# educational level- new variable
df["educat_level"] = np.nan
df.loc[(df["sun2020niva"] == 100) | (df["sun2020niva"] == 106), "educat_level"] = 1
df.loc[(df["sun2020niva"] == 200) | (df["sun2020niva"] == 206), "educat_level"] = 2
df.loc[(df["sun2020niva"] == 310) | (df["sun2020niva"] == 312) | (df["sun2020niva"] == 316), "educat_level"] = 3
df.loc[(df["sun2020niva"] == 320) | (df["sun2020niva"] == 322) | (df["sun2020niva"] == 326), "educat_level"] = 4
df.loc[(df["sun2020niva"] == 330) | (df["sun2020niva"] == 332) | (df["sun2020niva"] == 336), "educat_level"] = 5
df.loc[(df["sun2020niva"] == 410) | (df["sun2020niva"] == 412) | (df["sun2020niva"] == 416), "educat_level"] = 6
df.loc[(df["sun2020niva"] == 520) | (df["sun2020niva"] == 522) | (df["sun2020niva"] == 526), "educat_level"] = 7
df.loc[(df["sun2020niva"] == 530) | (df["sun2020niva"] == 532) | (df["sun2020niva"] == 536), "educat_level"] = 8
df.loc[(df["sun2020niva"] == 540) | (df["sun2020niva"] == 546), "educat_level"] = 9
df.loc[(df["sun2020niva"] == 550) | (df["sun2020niva"] == 556), "educat_level"] = 10
df.loc[(df["sun2020niva"] == 600) | (df["sun2020niva"] == 640), "educat_level"] = 11
# Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups

# higher education current studies
df["hsdelt2"] = df["hsdelt"].replace({2: 1, 3: 1})   # (1,0) registered hi-educ studies (not PhD)
df["fodelt2"] = df["fodelt"].replace({2: 1, 3: 1})   # (1,0) registered PhD studies
df["hieduc"] = np.where((df["hsdelt"] == 1) | (df["fodelt"] == 1), 1, 0)

# employment status: (1,0) employed and/or entrepreneur, or not (categories 5 and 6)
df["working"] = df["syssstat19"].replace({5: 0, 6: 0})

# occupational group
df.loc[df["agi1ssyk4"] == "****", "agi1ssyk4"] = np.nan
df["occgrp"] = pd.to_numeric(df["agi1ssyk4"].str[0])

# studying (getting study income, irrespective of level)
df["stud2"] = np.nan
df.loc[(df["stud"] > 0) & df["stud"].notna(), "stud2"] = 1

# unemployment
df["unemp"] = np.where(df["alosdag"] > 0, 1, 0)

df = df.rename(columns={"agi1ink": "ku1ink"})

df = df[["lopnr", "educat_level", "agi1peorgnr", "seninvar", "barn0_17", "examar", "hsdelt2", "fodelt2", "hieduc", "working", "occgrp", "stud2", "unemp", "forvers", "kapink", "ku1ink"]]
df["year"] = 2021
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2021.csv", index=False)


# LISA2022
# contains lots of info for each individual about labour market etc
df = pd.read_csv("C:/Users/teacher/project/data/raw/lisa_2022.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
# Change to lower case var names
df.columns = df.columns.str.lower()

# fix SenInvAr
df.loc[df["seninvar"] == "0000", "seninvar"] = np.nan
df["seninvar"] = pd.to_datetime(df["seninvar"], format="%Y").dt.year

# barn
for b in ["barn0_3", "barn4_6", "barn7_10", "barn11_15", "barn16_17"]:
    df[b] = pd.to_numeric(df[b])
df["barn0_17"] = df["barn0_3"] + df["barn4_6"] + df["barn7_10"] + df["barn11_15"] + df["barn16_17"]
df["barn0_17"] = df["barn0_17"].fillna(0)      # No. of children 0-17, if any, otherwise 0

# fix examar
df["examar"] = pd.to_datetime(df["examar"], format="%Y").dt.year

# replace erroneous missing demarker * with true missing
df.loc[df["sun2020niva_old"] == "*", "sun2020niva_old"] = np.nan
df.loc[df["sun2020niva"] == "999", "sun2020niva"] = np.nan

# destring several vars
for v in ["sun2020niva_old", "sun2020niva", "fodelt", "hsdelt", "syssstat19", "agi1ink", "forvers", "kapink", "stud", "alosdag"]:
    df[v] = pd.to_numeric(df[v])

# educational level- new variable
df["educat_level"] = np.nan
df.loc[(df["sun2020niva"] == 100) | (df["sun2020niva"] == 106), "educat_level"] = 1
df.loc[(df["sun2020niva"] == 200) | (df["sun2020niva"] == 206), "educat_level"] = 2
df.loc[(df["sun2020niva"] == 310) | (df["sun2020niva"] == 312) | (df["sun2020niva"] == 316), "educat_level"] = 3
df.loc[(df["sun2020niva"] == 320) | (df["sun2020niva"] == 322) | (df["sun2020niva"] == 326), "educat_level"] = 4
df.loc[(df["sun2020niva"] == 330) | (df["sun2020niva"] == 332) | (df["sun2020niva"] == 336), "educat_level"] = 5
df.loc[(df["sun2020niva"] == 410) | (df["sun2020niva"] == 412) | (df["sun2020niva"] == 416), "educat_level"] = 6
df.loc[(df["sun2020niva"] == 520) | (df["sun2020niva"] == 522) | (df["sun2020niva"] == 526), "educat_level"] = 7
df.loc[(df["sun2020niva"] == 530) | (df["sun2020niva"] == 532) | (df["sun2020niva"] == 536), "educat_level"] = 8
df.loc[(df["sun2020niva"] == 540) | (df["sun2020niva"] == 546), "educat_level"] = 9
df.loc[(df["sun2020niva"] == 550) | (df["sun2020niva"] == 556), "educat_level"] = 10
df.loc[(df["sun2020niva"] == 600) | (df["sun2020niva"] == 640), "educat_level"] = 11
# Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups

# higher education current studies
df["hsdelt2"] = df["hsdelt"].replace({2: 1, 3: 1})   # (1,0) registered hi-educ studies (not PhD)
df["fodelt2"] = df["fodelt"].replace({2: 1, 3: 1})   # (1,0) registered PhD studies
df["hieduc"] = np.where((df["hsdelt"] == 1) | (df["fodelt"] == 1), 1, 0)

# employment status: (1,0) employed and/or entrepreneur, or not (categories 5 and 6)
df["working"] = df["syssstat19"].replace({5: 0, 6: 0})

# occupational group
df.loc[df["agi1ssyk4"] == "****", "agi1ssyk4"] = np.nan
df["occgrp"] = pd.to_numeric(df["agi1ssyk4"].str[0])

# studying (getting study income, irrespective of level)
df["stud2"] = np.nan
df.loc[(df["stud"] > 0) & df["stud"].notna(), "stud2"] = 1

# unemployment
df["unemp"] = np.where(df["alosdag"] > 0, 1, 0)

df = df.rename(columns={"agi1ink": "ku1ink"})

df = df[["lopnr", "educat_level", "agi1peorgnr", "seninvar", "barn0_17", "examar", "hsdelt2", "fodelt2", "hieduc", "working", "occgrp", "stud2", "unemp", "forvers", "kapink", "ku1ink"]]
df["year"] = 2022
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2022.csv", index=False)


# LISA2023
# contains lots of info for each individual about labour market etc
df = pd.read_csv("C:/Users/teacher/project/data/raw/lisa_2023.csv", dtype=str)
df.info(buf=log)
df = df.rename(columns={"LopNr": "lopnr"})
# Change to lower case var names
df.columns = df.columns.str.lower()

# fix SenInvAr
df.loc[df["seninvar"] == "0000", "seninvar"] = np.nan
df["seninvar"] = pd.to_datetime(df["seninvar"], format="%Y").dt.year

# barn
for b in ["barn0_3", "barn4_6", "barn7_10", "barn11_15", "barn16_17"]:
    df[b] = pd.to_numeric(df[b])
df["barn0_17"] = df["barn0_3"] + df["barn4_6"] + df["barn7_10"] + df["barn11_15"] + df["barn16_17"]
df["barn0_17"] = df["barn0_17"].fillna(0)      # No. of children 0-17, if any, otherwise 0

# fix examar
df["examar"] = pd.to_datetime(df["examar"], format="%Y").dt.year

# replace erroneous missing demarker * with true missing
df.loc[df["sun2020niva_old"] == "*", "sun2020niva_old"] = np.nan
df.loc[df["sun2020niva"] == "999", "sun2020niva"] = np.nan

# destring several vars
for v in ["sun2020niva_old", "sun2020niva", "fodelt", "hsdelt", "syssstat19", "agi1ink", "forvers", "kapink", "stud", "alosdag"]:
    df[v] = pd.to_numeric(df[v])

# educational level- new variable
df["educat_level"] = np.nan
df.loc[(df["sun2020niva"] == 100) | (df["sun2020niva"] == 106), "educat_level"] = 1
df.loc[(df["sun2020niva"] == 200) | (df["sun2020niva"] == 206), "educat_level"] = 2
df.loc[(df["sun2020niva"] == 310) | (df["sun2020niva"] == 312) | (df["sun2020niva"] == 316), "educat_level"] = 3
df.loc[(df["sun2020niva"] == 320) | (df["sun2020niva"] == 322) | (df["sun2020niva"] == 326), "educat_level"] = 4
df.loc[(df["sun2020niva"] == 330) | (df["sun2020niva"] == 332) | (df["sun2020niva"] == 336), "educat_level"] = 5
df.loc[(df["sun2020niva"] == 410) | (df["sun2020niva"] == 412) | (df["sun2020niva"] == 416), "educat_level"] = 6
df.loc[(df["sun2020niva"] == 520) | (df["sun2020niva"] == 522) | (df["sun2020niva"] == 526), "educat_level"] = 7
df.loc[(df["sun2020niva"] == 530) | (df["sun2020niva"] == 532) | (df["sun2020niva"] == 536), "educat_level"] = 8
df.loc[(df["sun2020niva"] == 540) | (df["sun2020niva"] == 546), "educat_level"] = 9
df.loc[(df["sun2020niva"] == 550) | (df["sun2020niva"] == 556), "educat_level"] = 10
df.loc[(df["sun2020niva"] == 600) | (df["sun2020niva"] == 640), "educat_level"] = 11
# Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups

# higher education current studies
df["hsdelt2"] = df["hsdelt"].replace({2: 1, 3: 1})   # (1,0) registered hi-educ studies (not PhD)
df["fodelt2"] = df["fodelt"].replace({2: 1, 3: 1})   # (1,0) registered PhD studies
df["hieduc"] = np.where((df["hsdelt"] == 1) | (df["fodelt"] == 1), 1, 0)

# employment status: (1,0) employed and/or entrepreneur, or not (categories 5 and 6)
df["working"] = df["syssstat19"].replace({5: 0, 6: 0})

# occupational group
df.loc[df["agi1ssyk4"] == "****", "agi1ssyk4"] = np.nan
df["occgrp"] = pd.to_numeric(df["agi1ssyk4"].str[0])

# studying (getting study income, irrespective of level)
df["stud2"] = np.nan
df.loc[(df["stud"] > 0) & df["stud"].notna(), "stud2"] = 1

# unemployment
df["unemp"] = np.where(df["alosdag"] > 0, 1, 0)

df = df.rename(columns={"agi1ink": "ku1ink"})

df = df[["lopnr", "educat_level", "agi1peorgnr", "seninvar", "barn0_17", "examar", "hsdelt2", "fodelt2", "hieduc", "working", "occgrp", "stud2", "unemp", "forvers", "kapink", "ku1ink"]]
df["year"] = 2023
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2023.csv", index=False)


# foretag_2019
# Contains info about firms that persons are employed in
df = pd.read_csv("C:/Users/teacher/project/data/raw/foretag_2019.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
for v in ["sni2007", "medelantalanstallda", "nettoomsattning", "foradlingsvarde", "rorelseresultat", "summapersonalkostnader"]:
    df[v] = pd.to_numeric(df[v])
# a few firms have "00000" as industry, which does not exist, replace with missing
df.loc[df["sni2007"] == 0, "sni2007"] = np.nan
# fix neg values
df["summapersonalkostnader"] = -1 * df["summapersonalkostnader"]
df = df.rename(columns={"sni2007": "industry", "medelantalanstallda": "firmsize",
                        "nettoomsattning": "netsales", "foradlingsvarde": "vadded",
                        "rorelseresultat": "profit", "summapersonalkostnader": "labcosts"})
df["year"] = 2019
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2019.csv", index=False)


# foretag_2020
# Contains info about firms that persons are employed in
df = pd.read_csv("C:/Users/teacher/project/data/raw/foretag_2020.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
for v in ["sni2007", "medelantalanstallda", "nettoomsattning", "foradlingsvarde", "rorelseresultat", "summapersonalkostnader"]:
    df[v] = pd.to_numeric(df[v])
# a few firms have "00000" as industry, which does not exist, replace with missing
df.loc[df["sni2007"] == 0, "sni2007"] = np.nan
# fix neg values
df["summapersonalkostnader"] = -1 * df["summapersonalkostnader"]
df = df.rename(columns={"sni2007": "industry", "medelantalanstallda": "firmsize",
                        "nettoomsattning": "netsales", "foradlingsvarde": "vadded",
                        "rorelseresultat": "profit", "summapersonalkostnader": "labcosts"})
df["year"] = 2020
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2020.csv", index=False)


# foretag_2021
# Contains info about firms that persons are employed in
df = pd.read_csv("C:/Users/teacher/project/data/raw/foretag_2021.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
for v in ["sni2007", "medelantalanstallda", "nettoomsattning", "foradlingsvarde", "rorelseresultat", "summapersonalkostnader"]:
    df[v] = pd.to_numeric(df[v])
# a few firms have "00000" as industry, which does not exist, replace with missing
df.loc[df["sni2007"] == 0, "sni2007"] = np.nan
# fix neg values
df["summapersonalkostnader"] = -1 * df["summapersonalkostnader"]
df = df.rename(columns={"sni2007": "industry", "medelantalanstallda": "firmsize",
                        "nettoomsattning": "netsales", "foradlingsvarde": "vadded",
                        "rorelseresultat": "profit", "summapersonalkostnader": "labcosts"})
df["year"] = 2021
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2021.csv", index=False)


# foretag_2022
# Contains info about firms that persons are employed in
df = pd.read_csv("C:/Users/teacher/project/data/raw/foretag_2022.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
for v in ["sni2007", "medelantalanstallda", "nettoomsattning", "foradlingsvarde", "rorelseresultat", "summapersonalkostnader"]:
    df[v] = pd.to_numeric(df[v])
# a few firms have "00000" as industry, which does not exist, replace with missing
df.loc[df["sni2007"] == 0, "sni2007"] = np.nan
# fix neg values
df["summapersonalkostnader"] = -1 * df["summapersonalkostnader"]
df = df.rename(columns={"sni2007": "industry", "medelantalanstallda": "firmsize",
                        "nettoomsattning": "netsales", "foradlingsvarde": "vadded",
                        "rorelseresultat": "profit", "summapersonalkostnader": "labcosts"})
df["year"] = 2022
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2022.csv", index=False)


# foretag_2023
# Contains info about firms that persons are employed in
df = pd.read_csv("C:/Users/teacher/project/data/raw/foretag_2023.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
for v in ["sni2007", "medelantalanstallda", "nettoomsattning", "foradlingsvarde", "rorelseresultat", "summapersonalkostnader"]:
    df[v] = pd.to_numeric(df[v])
# a few firms have "00000" as industry, which does not exist, replace with missing
df.loc[df["sni2007"] == 0, "sni2007"] = np.nan
# fix neg values
df["summapersonalkostnader"] = -1 * df["summapersonalkostnader"]
df = df.rename(columns={"sni2007": "industry", "medelantalanstallda": "firmsize",
                        "nettoomsattning": "netsales", "foradlingsvarde": "vadded",
                        "rorelseresultat": "profit", "summapersonalkostnader": "labcosts"})
df["year"] = 2023
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2023.csv", index=False)


# *** agi_manad_2023
# Contains monthly pay per person and employer (employer declarations), 2023
df = pd.read_csv("C:/Users/teacher/project/data/raw/agi_manad_2023.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
df["lon"] = pd.to_numeric(df["lon"])
df["manad"] = df["period"].str[4:6].astype(int)
# yearly pay per person and employer
df = df.groupby(["lopnr", "peorgnr"], as_index=False)["lon"].sum()
# keep the main employer = the one that pays most
df = df.sort_values(["lopnr", "lon"]).groupby("lopnr").head(1)
df = df.rename(columns={"peorgnr": "agi_peorgnr", "lon": "agi_lon"})
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_agi_2023.csv", index=False)


# *** migrationer
df = pd.read_csv("C:/Users/teacher/project/data/raw/migrationer.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()

df["migyear"] = pd.to_datetime(df["datum"], format="%Y-%m-%d").dt.year
df = df.drop(columns=["datum"])

df["oecd"] = np.nan
df.loc[(df["inutvland"] == "NORGE") | (df["inutvland"] == "DANMARK") | (df["inutvland"] == "FINLAND") | (df["inutvland"] == "ISLAND") | (df["inutvland"] == "TYSKLAND") | (df["inutvland"] == "FRANKRIKE") | (df["inutvland"] == "STORBRITANNIEN") | (df["inutvland"] == "USA") | (df["inutvland"] == "KANADA") | (df["inutvland"] == "POLEN") | (df["inutvland"] == "SPANIEN") | (df["inutvland"] == "ITALIEN") | (df["inutvland"] == "NEDERLÄNDERNA") | (df["inutvland"] == "JAPAN"), "oecd"] = 1
df.loc[df["oecd"].isna() & (df["inutvland"] != "OKÄNT"), "oecd"] = 0
# some have inutvland == "OKÄNT", these become missing.

df["posttyp"] = np.where(df["posttyp"] == "Inv", 1, 2)   # (1,2) for immigration, or emigration

df["utvoecd"] = np.where((df["oecd"] == 1) & (df["posttyp"] == 2), 1, 0)
df["invoecd"] = np.where((df["oecd"] == 1) & (df["posttyp"] == 1), 1, 0)
df["utvnonoecd"] = np.where((df["oecd"] == 0) & (df["posttyp"] == 2), 1, 0)
df["invnonoecd"] = np.where((df["oecd"] == 0) & (df["posttyp"] == 1), 1, 0)

df = df.groupby(["lopnr", "migyear"], as_index=False)[["utvoecd", "invoecd", "utvnonoecd", "invnonoecd"]].sum()

# In order to merge 1:1 we reshape wide migration/ year for migration
df = df.pivot(index="lopnr", columns="migyear")
df.columns = [f"{v}{y}" for v, y in df.columns]
df = df.reset_index()

# Replace missing values for all new variables to 0, have not found a command for this
df["utvoecd2019"] = df["utvoecd2019"].fillna(0)
df["utvoecd2020"] = df["utvoecd2020"].fillna(0)
df["utvoecd2021"] = df["utvoecd2021"].fillna(0)
df["utvoecd2022"] = df["utvoecd2022"].fillna(0)
df["utvoecd2023"] = df["utvoecd2023"].fillna(0)
df["utvoecd2024"] = df["utvoecd2024"].fillna(0)
df["invoecd2019"] = df["invoecd2019"].fillna(0)
df["invoecd2020"] = df["invoecd2020"].fillna(0)
df["invoecd2021"] = df["invoecd2021"].fillna(0)
df["invoecd2022"] = df["invoecd2022"].fillna(0)
df["invoecd2023"] = df["invoecd2023"].fillna(0)
df["invoecd2024"] = df["invoecd2024"].fillna(0)
df["utvnonoecd2019"] = df["utvnonoecd2019"].fillna(0)
df["utvnonoecd2020"] = df["utvnonoecd2020"].fillna(0)
df["utvnonoecd2021"] = df["utvnonoecd2021"].fillna(0)
df["utvnonoecd2022"] = df["utvnonoecd2022"].fillna(0)
df["utvnonoecd2023"] = df["utvnonoecd2023"].fillna(0)
df["utvnonoecd2024"] = df["utvnonoecd2024"].fillna(0)
df["invnonoecd2019"] = df["invnonoecd2019"].fillna(0)
df["invnonoecd2020"] = df["invnonoecd2020"].fillna(0)
df["invnonoecd2021"] = df["invnonoecd2021"].fillna(0)
df["invnonoecd2022"] = df["invnonoecd2022"].fillna(0)
df["invnonoecd2024"] = df["invnonoecd2024"].fillna(0)

df = df.drop_duplicates()
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_migrationer.csv", index=False)


# ****Information about activity spells, municipal activity register****
df = pd.read_csv("C:/Users/teacher/project/data/raw/insatser_kommun.csv", dtype=str)
df.columns = df.columns.str.lower()
df.info(buf=log)
df["ar"] = df["ar"].astype(int)
df["alder"] = df["alder"].astype(int)

# Youth placement flag: codes F12, F15, F18 AND age under 25 years
df["youth_kommun"] = np.where((df["kod1"] == "F12") | (df["kod2"] == "F12") | (df["kod3"] == "F12") | (df["kod4"] == "F12") | (df["kod5"] == "F12") | (df["kod6"] == "F12") | (df["kod7"] == "F12") | (df["kod8"] == "F12") | (df["kod1"] == "F15") | (df["kod2"] == "F15") | (df["kod3"] == "F15") | (df["kod4"] == "F15") | (df["kod5"] == "F15") | (df["kod6"] == "F15") | (df["kod7"] == "F15") | (df["kod8"] == "F15") | (df["kod1"] == "F18") | (df["kod2"] == "F18") | (df["kod3"] == "F18") | (df["kod4"] == "F18") | (df["kod5"] == "F18") | (df["kod6"] == "F18") | (df["kod7"] == "F18") | (df["kod8"] == "F18") & (df["alder"] < 25), 1, 0)

# Change to fewer categories
df["catAB"] = np.nan
df.loc[(df["hkod"].str[0] == "A") | (df["kod1"].str[0] == "A") | (df["kod2"].str[0] == "A") | (df["kod3"].str[0] == "A") | (df["kod3"].str[0] == " A") | (df["kod4"].str[0] == "A") | (df["kod5"].str[0] == "A") | (df["kod6"].str[0] == "A") | (df["kod7"].str[0] == "A") | (df["kod8"].str[0] == "A") | (df["hkod"].str[0] == "B") | (df["kod1"].str[0] == "B") | (df["kod2"].str[0] == "B") | (df["kod3"].str[0] == "B") | (df["kod4"].str[0] == "B") | (df["kod5"].str[0] == "B") | (df["kod6"].str[0] == "B") | (df["kod7"].str[0] == "B") | (df["kod8"].str[0] == "B"), "catAB"] = 1
# catAB: (1,0) job-search support

df["catCD"] = np.nan
df.loc[(df["hkod"].str[0] == "C") | (df["kod1"].str[0] == "C") | (df["kod2"].str[0] == "C") | (df["kod3"].str[0] == "C") | (df["kod4"].str[0] == "C") | (df["kod5"].str[0] == "C") | (df["kod6"].str[0] == "C") | (df["kod7"].str[0] == "C") | (df["kod8"].str[0] == "C") | (df["hkod"].str[0] == "D") | (df["kod1"].str[0] == "D") | (df["kod2"].str[0] == "D") | (df["kod3"].str[0] == "D") | (df["kod4"].str[0] == "D") | (df["kod5"].str[0] == "D") | (df["kod6"].str[0] == "D") | (df["kod7"].str[0] == "D") | (df["kod8"].str[0] == "D"), "catCD"] = 1
# catCD: (1,0) training

df["catE"] = np.nan
df.loc[(df["hkod"].str[0] == "E") | (df["kod1"].str[0] == "E") | (df["kod2"].str[0] == "E") | (df["kod3"].str[0] == "E") | (df["kod4"].str[0] == "E") | (df["kod5"].str[0] == "E") | (df["kod6"].str[0] == "E") | (df["kod7"].str[0] == "E") | (df["kod8"].str[0] == "E"), "catE"] = 1
df.loc[(df["hkod"].str[:3] == "E30") | (df["kod1"].str[:3] == "E30") | (df["kod2"].str[:3] == "E30") | (df["kod3"].str[:3] == "E30") | (df["kod4"].str[:3] == "E30") | (df["kod5"].str[:3] == "E30") | (df["kod6"].str[:3] == "E30") | (df["kod7"].str[:3] == "E30") | (df["kod8"].str[:3] == "E30"), "catE"] = 0
# catE: (1,0) employment subsidy, start-up subsidy E30 not included

df["catF"] = np.nan
df.loc[(df["hkod"].str[0] == "F") | (df["kod1"].str[0] == "F") | (df["kod2"].str[0] == "F") | (df["kod3"].str[0] == "F") | (df["kod4"].str[0] == "F") | (df["kod5"].str[0] == "F") | (df["kod6"].str[0] == "F") | (df["kod7"].str[0] == "F") | (df["kod8"].str[0] == "F"), "catF"] = 1
# catF: (1,0) work placement

df["catHL"] = np.nan
df.loc[(df["hkod"].str[0] == "H") | (df["kod1"].str[0] == "H") | (df["kod2"].str[0] == "H") | (df["kod3"].str[0] == "H") | (df["kod4"].str[0] == "H") | (df["kod5"].str[0] == "H") | (df["kod6"].str[0] == "H") | (df["kod7"].str[0] == "H") | (df["kod8"].str[0] == "H") | (df["hkod"].str[0] == "L") | (df["kod1"].str[0] == "L") | (df["kod2"].str[0] == "L") | (df["kod3"].str[0] == "L") | (df["kod4"].str[0] == "L") | (df["kod5"].str[0] == "L") | (df["kod6"].str[0] == "L") | (df["kod7"].str[0] == "L") | (df["kod8"].str[0] == "L"), "catHL"] = 1
# catHL: (1,0) matching services

df["catREST"] = np.nan
df.loc[(df["hkod"].str[0] == "G") | (df["kod1"].str[0] == "G") | (df["kod2"].str[0] == "G") | (df["kod3"].str[0] == "G") | (df["kod4"].str[0] == "G") | (df["kod5"].str[0] == "G") | (df["kod6"].str[0] == "G") | (df["kod7"].str[0] == "G") | (df["kod8"].str[0] == "G") | (df["hkod"].str[0] == "K") | (df["kod1"].str[0] == "K") | (df["kod2"].str[0] == "K") | (df["kod3"].str[0] == "K") | (df["kod4"].str[0] == "K") | (df["kod5"].str[0] == "K") | (df["kod6"].str[0] == "K") | (df["kod7"].str[0] == "K") | (df["kod8"].str[0] == "K") | (df["hkod"].str[0] == "R") | (df["kod1"].str[0] == "R") | (df["kod2"].str[0] == "R") | (df["kod3"].str[0] == "R") | (df["kod4"].str[0] == "R") | (df["kod5"].str[0] == "R") | (df["kod6"].str[0] == "R") | (df["kod7"].str[0] == "R") | (df["kod8"].str[0] == "R") | (df["hkod"].str[0] == "U") | (df["kod1"].str[0] == "U") | (df["kod2"].str[0] == "U") | (df["kod3"].str[0] == "U") | (df["kod4"].str[0] == "U") | (df["kod5"].str[0] == "U") | (df["kod6"].str[0] == "U") | (df["kod7"].str[0] == "U") | (df["kod8"].str[0] == "U") | (df["hkod"].str[0] == "V") | (df["kod1"].str[0] == "V") | (df["kod2"].str[0] == "V") | (df["kod3"].str[0] == "V") | (df["kod4"].str[0] == "V") | (df["kod5"].str[0] == "V") | (df["kod6"].str[0] == "V") | (df["kod7"].str[0] == "V") | (df["kod8"].str[0] == "V") | (df["hkod"].str[0] == "Y") | (df["kod1"].str[0] == "Y") | (df["kod2"].str[0] == "Y") | (df["kod3"].str[0] == "Y") | (df["kod4"].str[0] == "Y") | (df["kod5"].str[0] == "Y") | (df["kod6"].str[0] == "Y") | (df["kod7"].str[0] == "Y") | (df["kod8"].str[0] == "Y") | (df["hkod"].str[0] == "Z") | (df["kod1"].str[0] == "Z") | (df["kod2"].str[0] == "Z") | (df["kod3"].str[0] == "Z") | (df["kod4"].str[0] == "Z") | (df["kod5"].str[0] == "Z") | (df["kod6"].str[0] == "Z") | (df["kod7"].str[0] == "Z") | (df["kod8"].str[0] == "Z"), "catREST"] = 1
# catREST: (1,0) other and administrative codes

# replace with 0 all that are not in the groups
df.loc[df["catAB"] != 1, "catAB"] = 0
df.loc[df["catCD"] != 1, "catCD"] = 0
df.loc[df["catE"] != 1, "catE"] = 0
df.loc[df["catF"] != 1, "catF"] = 0
df.loc[df["catHL"] != 1, "catHL"] = 0
df.loc[df["catREST"] != 1, "catREST"] = 0

# Drop code variables
df = df.drop(columns=["hkod", "kod1", "kod2", "kod3", "kod4", "kod5", "kod6", "kod7", "kod8"])

# Set cut off age 20 years. prior: activity before age 20, post: at 20 or older
df["ncatAB_prior"] = np.where((df["catAB"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatAB_post"] = np.where((df["catAB"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatCD_prior"] = np.where((df["catCD"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatCD_post"] = np.where((df["catCD"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatE_prior"] = np.where((df["catE"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatE_post"] = np.where((df["catE"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatF_prior"] = np.where((df["catF"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatF_post"] = np.where((df["catF"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatHL_prior"] = np.where((df["catHL"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatHL_post"] = np.where((df["catHL"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatREST_prior"] = np.where((df["catREST"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatREST_post"] = np.where((df["catREST"] == 1) & (df["alder"] >= 20), 1, 0)

df["nncatAB_prior"] = df.groupby("lopnr")["ncatAB_prior"].transform("max")
df["nncatAB_post"] = df.groupby("lopnr")["ncatAB_post"].transform("max")
df["nncatCD_prior"] = df.groupby("lopnr")["ncatCD_prior"].transform("max")
df["nncatCD_post"] = df.groupby("lopnr")["ncatCD_post"].transform("max")
df["nncatE_prior"] = df.groupby("lopnr")["ncatE_prior"].transform("max")
df["nncatE_post"] = df.groupby("lopnr")["ncatE_post"].transform("max")
df["nncatF_prior"] = df.groupby("lopnr")["ncatF_prior"].transform("max")
df["nncatF_post"] = df.groupby("lopnr")["ncatF_post"].transform("max")
df["nncatHL_prior"] = df.groupby("lopnr")["ncatHL_prior"].transform("max")
df["nncatHL_post"] = df.groupby("lopnr")["ncatHL_post"].transform("max")
df["nncatREST_prior"] = df.groupby("lopnr")["ncatREST_prior"].transform("max")
df["nncatREST_post"] = df.groupby("lopnr")["ncatREST_post"].transform("max")
df["youth"] = df.groupby("lopnr")["youth_kommun"].transform("max")

df = df.drop(columns=["catAB", "ncatAB_post", "ncatAB_prior", "catCD", "ncatCD_post", "ncatCD_prior", "catE", "ncatE_post", "ncatE_prior", "catF", "ncatF_post", "ncatF_prior", "catHL", "ncatHL_post", "ncatHL_prior", "catREST", "ncatREST_post", "ncatREST_prior", "youth_kommun"])

# In order to merge 1:1 drop the time variables, they are included in the dichotomous variables
df = df.drop(columns=["ar", "alder"])
df = df.drop_duplicates()
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_insatser_kommun.csv", index=False)


# ****Information about activity spells, state programme register****
df = pd.read_csv("C:/Users/teacher/project/data/raw/insatser_stat.csv", dtype=str)
df.columns = df.columns.str.lower()
df.info(buf=log)
df["ar"] = df["ar"].astype(int)
df["alder"] = df["alder"].astype(int)

# Youth placement flag: codes F12, F15, F18 AND age under 25 years
df["youth_stat"] = np.where((df["kod1"] == "F12") | (df["kod2"] == "F12") | (df["kod3"] == "F12") | (df["kod4"] == "F12") | (df["kod5"] == "F12") | (df["kod6"] == "F12") | (df["kod7"] == "F12") | (df["kod8"] == "F12") | (df["kod9"] == "F12") | (df["kod10"] == "F12") | (df["kod1"] == "F15") | (df["kod2"] == "F15") | (df["kod3"] == "F15") | (df["kod4"] == "F15") | (df["kod5"] == "F15") | (df["kod6"] == "F15") | (df["kod7"] == "F15") | (df["kod8"] == "F15") | (df["kod9"] == "F15") | (df["kod10"] == "F15") | (df["kod1"] == "F18") | (df["kod2"] == "F18") | (df["kod3"] == "F18") | (df["kod4"] == "F18") | (df["kod5"] == "F18") | (df["kod6"] == "F18") | (df["kod7"] == "F18") | (df["kod8"] == "F18") | (df["kod9"] == "F18") | (df["kod10"] == "F18") & (df["alder"] < 25), 1, 0)

# Change to fewer categories
df["catAB"] = np.nan
df.loc[(df["hkod"].str[0] == "A") | (df["kod1"].str[0] == "A") | (df["kod2"].str[0] == "A") | (df["kod3"].str[0] == "A") | (df["kod3"].str[0] == " A") | (df["kod4"].str[0] == "A") | (df["kod5"].str[0] == "A") | (df["kod6"].str[0] == "A") | (df["kod7"].str[0] == " A") | (df["kod8"].str[0] == "A") | (df["kod9"].str[0] == "A") | (df["kod10"].str[0] == "A") | (df["hkod"].str[0] == "B") | (df["kod1"].str[0] == "B") | (df["kod2"].str[0] == "B") | (df["kod3"].str[0] == "B") | (df["kod4"].str[0] == "B") | (df["kod5"].str[0] == "B") | (df["kod6"].str[0] == "B") | (df["kod7"].str[0] == "B") | (df["kod8"].str[0] == "B") | (df["kod9"].str[0] == "B") | (df["kod10"].str[0] == "B"), "catAB"] = 1
# catAB: (1,0) job-search support

df["catCD"] = np.nan
df.loc[(df["hkod"].str[0] == "C") | (df["kod1"].str[0] == "C") | (df["kod2"].str[0] == "C") | (df["kod3"].str[0] == "C") | (df["kod4"].str[0] == "C") | (df["kod5"].str[0] == "C") | (df["kod6"].str[0] == "C") | (df["kod7"].str[0] == "C") | (df["kod8"].str[0] == "C") | (df["kod9"].str[0] == "C") | (df["kod10"].str[0] == "C") | (df["hkod"].str[0] == "D") | (df["kod1"].str[0] == "D") | (df["kod2"].str[0] == "D") | (df["kod3"].str[0] == "D") | (df["kod4"].str[0] == "D") | (df["kod5"].str[0] == "D") | (df["kod6"].str[0] == "D") | (df["kod7"].str[0] == "D") | (df["kod8"].str[0] == "D") | (df["kod9"].str[0] == "D") | (df["kod10"].str[0] == "D"), "catCD"] = 1
# catCD: (1,0) training

df["catE"] = np.nan
df.loc[(df["hkod"].str[:3] == "E30") | (df["kod1"].str[:3] == "E30") | (df["kod2"].str[:3] == "E30") | (df["kod3"].str[:3] == "E30") | (df["kod4"].str[:3] == "E30") | (df["kod5"].str[:3] == "E30") | (df["kod6"].str[:3] == "E30") | (df["kod7"].str[:3] == "E30") | (df["kod8"].str[:3] == "E30") | (df["kod9"].str[:3] == "E30") | (df["kod10"].str[:3] == "E30"), "catE"] = 0
df.loc[((df["hkod"].str[0] == "E") | (df["kod1"].str[0] == "E") | (df["kod2"].str[0] == "E") | (df["kod3"].str[0] == "E") | (df["kod4"].str[0] == "E") | (df["kod5"].str[0] == "E") | (df["kod6"].str[0] == "E") | (df["kod7"].str[0] == "E") | (df["kod8"].str[0] == "E") | (df["kod9"].str[0] == "E") | (df["kod10"].str[0] == "E")) & (df["ar"] > 2016), "catE"] = 1
# OBS!! before 2017 the codes are numeric (old code list), so letter E only from 2017. Important to remember!
# catE: (1,0) employment subsidy, start-up subsidy E30 not included

df["catF"] = np.nan
df.loc[(df["hkod"].str[0] == "F") | (df["kod1"].str[0] == "F") | (df["kod2"].str[0] == "F") | (df["kod3"].str[0] == "F") | (df["kod4"].str[0] == "F") | (df["kod5"].str[0] == "F") | (df["kod6"].str[0] == "F") | (df["kod7"].str[0] == "F") | (df["kod8"].str[0] == "F") | (df["kod9"].str[0] == "F") | (df["kod10"].str[0] == "F"), "catF"] = 1
# catF: (1,0) work placement

df["catHL"] = np.nan
df.loc[(df["hkod"].str[0] == "H") | (df["kod1"].str[0] == "H") | (df["kod2"].str[0] == "H") | (df["kod3"].str[0] == "H") | (df["kod4"].str[0] == "H") | (df["kod5"].str[0] == "H") | (df["kod6"].str[0] == "H") | (df["kod7"].str[0] == "H") | (df["kod8"].str[0] == "H") | (df["kod9"].str[0] == "H") | (df["kod10"].str[0] == "H") | (df["hkod"].str[0] == "L") | (df["kod1"].str[0] == "L") | (df["kod2"].str[0] == "L") | (df["kod3"].str[0] == "L") | (df["kod4"].str[0] == "L") | (df["kod5"].str[0] == "L") | (df["kod6"].str[0] == "L") | (df["kod7"].str[0] == "L") | (df["kod8"].str[0] == "L") | (df["kod9"].str[0] == "L") | (df["kod10"].str[0] == "L"), "catHL"] = 1
# catHL: (1,0) matching services

df["catREST"] = np.nan
df.loc[(df["hkod"].str[0] == "G") | (df["kod1"].str[0] == "G") | (df["kod2"].str[0] == "G") | (df["kod3"].str[0] == "G") | (df["kod4"].str[0] == "G") | (df["kod5"].str[0] == "G") | (df["kod6"].str[0] == "G") | (df["kod7"].str[0] == "G") | (df["kod8"].str[0] == "G") | (df["kod9"].str[0] == "G") | (df["kod10"].str[0] == "G") | (df["hkod"].str[0] == "K") | (df["kod1"].str[0] == "K") | (df["kod2"].str[0] == "K") | (df["kod3"].str[0] == "K") | (df["kod4"].str[0] == "K") | (df["kod5"].str[0] == "K") | (df["kod6"].str[0] == "K") | (df["kod7"].str[0] == "K") | (df["kod8"].str[0] == "K") | (df["kod9"].str[0] == "K") | (df["kod10"].str[0] == "K") | (df["hkod"].str[0] == "R") | (df["kod1"].str[0] == "R") | (df["kod2"].str[0] == "R") | (df["kod3"].str[0] == "R") | (df["kod4"].str[0] == "R") | (df["kod5"].str[0] == "R") | (df["kod6"].str[0] == "R") | (df["kod7"].str[0] == "R") | (df["kod8"].str[0] == "R") | (df["kod9"].str[0] == "R") | (df["kod10"].str[0] == "R") | (df["hkod"].str[0] == "U") | (df["kod1"].str[0] == "U") | (df["kod2"].str[0] == "U") | (df["kod3"].str[0] == "U") | (df["kod4"].str[0] == "U") | (df["kod5"].str[0] == "U") | (df["kod6"].str[0] == "U") | (df["kod7"].str[0] == "U") | (df["kod8"].str[0] == "U") | (df["kod9"].str[0] == "U") | (df["kod10"].str[0] == "U") | (df["hkod"].str[0] == "V") | (df["kod1"].str[0] == "V") | (df["kod2"].str[0] == "V") | (df["kod3"].str[0] == "V") | (df["kod4"].str[0] == "V") | (df["kod5"].str[0] == "V") | (df["kod6"].str[0] == "V") | (df["kod7"].str[0] == "V") | (df["kod8"].str[0] == "V") | (df["kod9"].str[0] == "V") | (df["kod10"].str[0] == "V") | (df["hkod"].str[0] == "Y") | (df["kod1"].str[0] == "Y") | (df["kod2"].str[0] == "Y") | (df["kod3"].str[0] == "Y") | (df["kod4"].str[0] == "Y") | (df["kod5"].str[0] == "Y") | (df["kod6"].str[0] == "Y") | (df["kod7"].str[0] == "Y") | (df["kod8"].str[0] == "Y") | (df["kod9"].str[0] == "Y") | (df["kod10"].str[0] == "Y") | (df["hkod"].str[0] == "Z") | (df["kod1"].str[0] == "Z") | (df["kod2"].str[0] == "Z") | (df["kod3"].str[0] == "Z") | (df["kod4"].str[0] == "Z") | (df["kod5"].str[0] == "Z") | (df["kod6"].str[0] == "Z") | (df["kod7"].str[0] == "Z") | (df["kod8"].str[0] == "Z") | (df["kod9"].str[0] == "Z") | (df["kod10"].str[0] == "Z"), "catREST"] = 1
# catREST: (1,0) other and administrative codes

# Keep only codes starting with digits, i.e. the old numeric code list
df["hk"] = df["hkod"].where((df["hkod"].str[0] == "0") | (df["hkod"].str[0] == "1") | (df["hkod"].str[0] == "2") | (df["hkod"].str[0] == "3") | (df["hkod"].str[0] == "4") | (df["hkod"].str[0] == "5") | (df["hkod"].str[0] == "6") | (df["hkod"].str[0] == "7") | (df["hkod"].str[0] == "8") | (df["hkod"].str[0] == "9"))
df["ko1"] = df["kod1"].where((df["kod1"].str[0] == "0") | (df["kod1"].str[0] == "1") | (df["kod1"].str[0] == "2") | (df["kod1"].str[0] == "3") | (df["kod1"].str[0] == "4") | (df["kod1"].str[0] == "5") | (df["kod1"].str[0] == "6") | (df["kod1"].str[0] == "7") | (df["kod1"].str[0] == "8") | (df["kod1"].str[0] == "9"))
df["ko2"] = df["kod2"].where((df["kod2"].str[0] == "0") | (df["kod2"].str[0] == "1") | (df["kod2"].str[0] == "2") | (df["kod2"].str[0] == "3") | (df["kod2"].str[0] == "4") | (df["kod2"].str[0] == "5") | (df["kod2"].str[0] == "6") | (df["kod2"].str[0] == "7") | (df["kod2"].str[0] == "8") | (df["kod2"].str[0] == "9"))
df["ko3"] = df["kod3"].where((df["kod3"].str[0] == "0") | (df["kod3"].str[0] == "1") | (df["kod3"].str[0] == "2") | (df["kod3"].str[0] == "3") | (df["kod3"].str[0] == "4") | (df["kod3"].str[0] == "5") | (df["kod3"].str[0] == "6") | (df["kod3"].str[0] == "7") | (df["kod3"].str[0] == "8") | (df["kod3"].str[0] == "9"))
df["ko4"] = df["kod4"].where((df["kod4"].str[0] == "0") | (df["kod4"].str[0] == "1") | (df["kod4"].str[0] == "2") | (df["kod4"].str[0] == "3") | (df["kod4"].str[0] == "4") | (df["kod4"].str[0] == "5") | (df["kod4"].str[0] == "6") | (df["kod4"].str[0] == "7") | (df["kod4"].str[0] == "8") | (df["kod4"].str[0] == "9"))
df["ko5"] = df["kod5"].where((df["kod5"].str[0] == "0") | (df["kod5"].str[0] == "1") | (df["kod5"].str[0] == "2") | (df["kod5"].str[0] == "3") | (df["kod5"].str[0] == "4") | (df["kod5"].str[0] == "5") | (df["kod5"].str[0] == "6") | (df["kod5"].str[0] == "7") | (df["kod5"].str[0] == "8") | (df["kod5"].str[0] == "9"))
df["ko6"] = df["kod6"].where((df["kod6"].str[0] == "0") | (df["kod6"].str[0] == "1") | (df["kod6"].str[0] == "2") | (df["kod6"].str[0] == "3") | (df["kod6"].str[0] == "4") | (df["kod6"].str[0] == "5") | (df["kod6"].str[0] == "6") | (df["kod6"].str[0] == "7") | (df["kod6"].str[0] == "8") | (df["kod6"].str[0] == "9"))
df["ko7"] = df["kod7"].where((df["kod7"].str[0] == "0") | (df["kod7"].str[0] == "1") | (df["kod7"].str[0] == "2") | (df["kod7"].str[0] == "3") | (df["kod7"].str[0] == "4") | (df["kod7"].str[0] == "5") | (df["kod7"].str[0] == "6") | (df["kod7"].str[0] == "7") | (df["kod7"].str[0] == "8") | (df["kod7"].str[0] == "9"))
df["ko8"] = df["kod8"].where((df["kod8"].str[0] == "0") | (df["kod8"].str[0] == "1") | (df["kod8"].str[0] == "2") | (df["kod8"].str[0] == "3") | (df["kod8"].str[0] == "4") | (df["kod8"].str[0] == "5") | (df["kod8"].str[0] == "6") | (df["kod8"].str[0] == "7") | (df["kod8"].str[0] == "8") | (df["kod8"].str[0] == "9"))
df["ko9"] = df["kod9"].where((df["kod9"].str[0] == "0") | (df["kod9"].str[0] == "1") | (df["kod9"].str[0] == "2") | (df["kod9"].str[0] == "3") | (df["kod9"].str[0] == "4") | (df["kod9"].str[0] == "5") | (df["kod9"].str[0] == "6") | (df["kod9"].str[0] == "7") | (df["kod9"].str[0] == "8") | (df["kod9"].str[0] == "9"))
df["ko10"] = df["kod10"].where((df["kod10"].str[0] == "0") | (df["kod10"].str[0] == "1") | (df["kod10"].str[0] == "2") | (df["kod10"].str[0] == "3") | (df["kod10"].str[0] == "4") | (df["kod10"].str[0] == "5") | (df["kod10"].str[0] == "6") | (df["kod10"].str[0] == "7") | (df["kod10"].str[0] == "8") | (df["kod10"].str[0] == "9"))

# Keep only the 3 first digits and change to numeric
df["hvd"] = pd.to_numeric(df["hk"].str[:3])
df["k1"] = pd.to_numeric(df["ko1"].str[:3])
df["k2"] = pd.to_numeric(df["ko2"].str[:3])
df["k3"] = pd.to_numeric(df["ko3"].str[:3])
df["k4"] = pd.to_numeric(df["ko4"].str[:3])
df["k5"] = pd.to_numeric(df["ko5"].str[:3])
df["k6"] = pd.to_numeric(df["ko6"].str[:3])
df["k7"] = pd.to_numeric(df["ko7"].str[:3])
df["k8"] = pd.to_numeric(df["ko8"].str[:3])
df["k9"] = pd.to_numeric(df["ko9"].str[:3])
df["k10"] = pd.to_numeric(df["ko10"].str[:3])
df = df.drop(columns=["hk", "ko1", "ko2", "ko3", "ko4", "ko5", "ko6", "ko7", "ko8", "ko9", "ko10"])

# Change missing to 0, otherwise missing codes end up in the groups below
for v in ["hvd", "k1", "k2", "k3", "k4", "k5", "k6", "k7", "k8", "k9", "k10"]:
    df[v] = df[v].fillna(0)

df.loc[(df["hvd"] < 200) & (df["hvd"] != 0) | (df["k1"] < 200) & (df["k1"] != 0) | (df["k2"] < 200) & (df["k2"] != 0) | (df["k3"] < 200) & (df["k3"] != 0) | (df["k4"] < 200) & (df["k4"] != 0) | (df["k5"] < 200) & (df["k5"] != 0) | (df["k6"] < 200) & (df["k6"] != 0) | (df["k7"] < 200) & (df["k7"] != 0) | (df["k8"] < 200) & (df["k8"] != 0) | (df["k9"] < 200) & (df["k9"] != 0) | (df["k10"] < 200) & (df["k10"] != 0), "catAB"] = 1
df.loc[df["catAB"] != 1, "catAB"] = 0

df.loc[(df["hvd"] >= 200) & (df["hvd"] <= 299) | (df["k1"] >= 200) & (df["k1"] <= 299) | (df["k2"] >= 200) & (df["k2"] <= 299) | (df["k3"] >= 200) & (df["k3"] <= 299) | (df["k4"] >= 200) & (df["k4"] <= 299) | (df["k5"] >= 200) & (df["k5"] <= 299) | (df["k6"] >= 200) & (df["k6"] >= 299) | (df["k7"] >= 200) & (df["k7"] <= 299) | (df["k8"] >= 200) & (df["k8"] <= 299) | (df["k9"] >= 200) & (df["k9"] <= 299) | (df["k10"] >= 200) & (df["k10"] <= 299), "catCD"] = 1
df.loc[df["catCD"] != 1, "catCD"] = 0

df.loc[(df["hvd"] > 299) & (df["hvd"] < 400) | (df["k1"] > 299) & (df["k1"] < 400) | (df["k2"] > 299) & (df["k2"] < 400) | (df["k3"] > 299) & (df["k3"] < 400) | (df["k4"] > 299) & (df["k4"] < 400) | (df["k5"] > 299) & (df["k5"] < 400) | (df["k6"] > 299) & (df["k6"] > 400) | (df["k7"] > 299) & (df["k7"] < 400) | (df["k8"] > 299) & (df["k8"] < 400) | (df["k9"] > 299) & (df["k9"] < 400) | (df["k10"] > 299) & (df["k10"] < 400), "catE"] = 1
df.loc[df["catE"] != 1, "catE"] = 0

df.loc[(df["hvd"] > 399) & (df["hvd"] < 500) | (df["k1"] > 399) & (df["k1"] < 500) | (df["k2"] > 399) & (df["k2"] < 500) | (df["k3"] > 399) & (df["k3"] < 500) | (df["k4"] > 399) & (df["k4"] < 500) | (df["k5"] > 399) & (df["k5"] < 500) | (df["k6"] > 399) & (df["k6"] > 500) | (df["k7"] > 399) & (df["k7"] < 500) | (df["k8"] > 399) & (df["k8"] < 500) | (df["k9"] > 399) & (df["k9"] < 500) | (df["k10"] > 399) & (df["k10"] < 500), "catF"] = 1
df.loc[df["catF"] != 1, "catF"] = 0

df.loc[(df["hvd"] > 499) & (df["hvd"] < 650) | (df["k1"] > 499) & (df["k1"] < 650) | (df["k2"] > 499) & (df["k2"] < 650) | (df["k3"] > 499) & (df["k3"] < 650) | (df["k4"] > 499) & (df["k4"] < 650) | (df["k5"] > 499) & (df["k5"] < 650) | (df["k6"] > 499) & (df["k6"] > 650) | (df["k7"] > 499) & (df["k7"] < 650) | (df["k8"] > 499) & (df["k8"] < 650) | (df["k9"] > 499) & (df["k9"] < 650) | (df["k10"] > 499) & (df["k10"] < 650), "catHL"] = 1
df.loc[df["catHL"] != 1, "catHL"] = 0

df.loc[(df["hvd"] > 649) & (df["hvd"] < 1000) | (df["k1"] > 649) & (df["k1"] < 1000) | (df["k2"] > 649) & (df["k2"] < 1000) | (df["k3"] > 549) & (df["k3"] < 1000) | (df["k4"] > 649) & (df["k4"] < 1000) | (df["k5"] > 649) & (df["k5"] < 1000) | (df["k6"] > 649) & (df["k6"] > 1000) | (df["k7"] > 649) & (df["k7"] < 1000) | (df["k8"] > 649) & (df["k8"] < 1000) | (df["k9"] > 649) & (df["k9"] < 1000) | (df["k10"] > 649) & (df["k10"] < 1000), "catREST"] = 1
df.loc[df["catREST"] != 1, "catREST"] = 0

df = df.drop(columns=["hkod", "kod1", "kod2", "kod3", "kod4", "kod5", "kod6", "kod7", "kod8", "kod9", "kod10", "hvd", "k1", "k2", "k3", "k4", "k5", "k6", "k7", "k8", "k9", "k10"])

# Set cut off age 20 years. prior: activity before age 20, post: at 20 or older
df["ncatAB_prior"] = np.where((df["catAB"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatAB_post"] = np.where((df["catAB"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatCD_prior"] = np.where((df["catCD"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatCD_post"] = np.where((df["catCD"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatE_prior"] = np.where((df["catE"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatE_post"] = np.where((df["catE"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatF_prior"] = np.where((df["catF"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatF_post"] = np.where((df["catF"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatHL_prior"] = np.where((df["catHL"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatHL_post"] = np.where((df["catHL"] == 1) & (df["alder"] >= 20), 1, 0)
df["ncatREST_prior"] = np.where((df["catREST"] == 1) & (df["alder"] < 20), 1, 0)
df["ncatREST_post"] = np.where((df["catREST"] == 1) & (df["alder"] >= 20), 1, 0)

df["SnncatAB_prior"] = df.groupby("lopnr")["ncatAB_prior"].transform("max")
df["SnncatAB_post"] = df.groupby("lopnr")["ncatAB_post"].transform("max")
df["SnncatCD_prior"] = df.groupby("lopnr")["ncatCD_prior"].transform("max")
df["SnncatCD_post"] = df.groupby("lopnr")["ncatCD_post"].transform("max")
df["SnncatE_prior"] = df.groupby("lopnr")["ncatE_prior"].transform("max")
df["SnncatE_post"] = df.groupby("lopnr")["ncatE_post"].transform("max")
df["SnncatF_prior"] = df.groupby("lopnr")["ncatF_prior"].transform("max")
df["SnncatF_post"] = df.groupby("lopnr")["ncatF_post"].transform("max")
df["SnncatHL_prior"] = df.groupby("lopnr")["ncatHL_prior"].transform("max")
df["SnncatHL_post"] = df.groupby("lopnr")["ncatHL_post"].transform("max")
df["SnncatREST_prior"] = df.groupby("lopnr")["ncatREST_prior"].transform("max")
df["SnncatREST_post"] = df.groupby("lopnr")["ncatREST_post"].transform("max")
df["Syouth"] = df.groupby("lopnr")["youth_stat"].transform("max")

df = df.drop(columns=["catAB", "ncatAB_post", "ncatAB_prior", "catCD", "ncatCD_post", "ncatCD_prior", "catE", "ncatE_post", "ncatE_prior", "catF", "ncatF_post", "ncatF_prior", "catHL", "ncatHL_post", "ncatHL_prior", "catREST", "ncatREST_post", "ncatREST_prior", "youth_stat"])

# In order to merge 1:1 drop the time variables, they are included in the dichotomous variables
df = df.drop(columns=["ar", "alder"])
df = df.drop_duplicates()
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_insatser_stat.csv", index=False)


# *****Appending- all files from LISA 2019-2023***
df = pd.concat([pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2019.csv"), pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2020.csv"),
                pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2021.csv"), pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2022.csv"),
                pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa2023.csv")])
# variables ku1peorgnr agi1peorgnr are the same employer id, for 2019-2020 and 2021-2023, respectively

# Change educational level to 3-levels variable instead of 11-levels variable
df = df.rename(columns={"educat_level": "educ_level_eleven"})
df["educat_level"] = np.nan
df.loc[(df["educ_level_eleven"] == 1) | (df["educ_level_eleven"] == 2), "educat_level"] = 1
df.loc[(df["educ_level_eleven"] == 3) | (df["educ_level_eleven"] == 4) | (df["educ_level_eleven"] == 5), "educat_level"] = 2
df.loc[(df["educ_level_eleven"] >= 6), "educat_level"] = 3
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_lisa_appended.csv", index=False)

# Append all files from foretag 2019-2023
df = pd.concat([pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2019.csv"), pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2020.csv"),
                pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2021.csv"), pd.read_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_2022.csv")])
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_foretag_appended.csv", index=False)


# *** agi_manad_2023, firm level (added in April)
# wage bill and share on permanent contracts per firm 2023, for the firm panel
df = pd.read_csv("C:/Users/teacher/project/data/raw/agi_manad_2023.csv", dtype=str)
df.info(buf=log)
df.columns = df.columns.str.lower()
df["lon"] = pd.to_numeric(df["lon"])
# a declaration can be sent twice, keep one row per person, employer and month
df = df.drop_duplicates(subset=["lopnr", "peorgnr", "period"])
# anstform: 1 permanent, 2 fixed-term, 3 hourly. Some are empty, set to 0 so no rows are lost
df["anstform"] = pd.to_numeric(df["anstform"]).fillna(0)
df["permanent"] = np.where(df["anstform"] < 2, 1, 0)   # (1,0) permanent contract
df = df.groupby("peorgnr", as_index=False).agg(wagebill=("lon", "sum"), permshare=("permanent", "mean"))
print(df.describe(), file=log)
df.to_csv("C:/Users/teacher/project/data/processed/flawed_py/se_agi_foretag_2023.csv", index=False)


"""
Other datasets to work with:
(merge everything on lopnr and year, the grades, the spells, agi against lisa 2023)



log.close()
"""
