# Codebook: the register lab files

This codebook documents the files in `data/raw/`. They are **synthetic**: made by a random-number generator, with fake ids, invented values and no real person or firm behind any row. They imitate the layout of Swedish register deliveries of the kind economists receive on SCB's MONA system.

Like any real codebook, this one was written by people, from an earlier delivery. It may not match the files you received in every detail. Where the codebook and the data disagree, the data are what you have to clean: check every file with the intake checklist, and write down each place where the documentation is wrong.

## General conventions

- Every file is a CSV file in UTF-8 (Swedish letters such as Ä appear in the data). Every value is stored as text, exactly as delivered, so check values before you convert them to numbers.
- Column names are in mixed case, as delivered.
- **`LopNr`** is the person id: `P` followed by six digits. It is never missing, in any file.
- **`PeOrgNr`** is the firm id: `F` followed by five digits.
- Persons and firms are linked through the person's employer id in the yearly individual file (and through `PeOrgNr` in the monthly declarations), so person-firm-year joins are possible.
- Money is in SEK or in hundreds of SEK; each variable says which.
- Variable names follow SCB's published LISA documentation where a public name exists (`Kon`, `FodelseAr`, `SenInvAr`, `Sun2000Niva`, `SyssStat11`, `ForvErs`, `KapInk`, ...). The activity codes, the new education-code vintage, the employment-status code 7, the column names of the monthly declarations and the employment-form codes are invented for teaching. Do not use them as a guide to the real classifications.

## Files

| File | Each row is | Years |
|---|---|---|
| `persons.csv` | a person, with fixed characteristics | |
| `lisa_2019.csv` ... `lisa_2023.csv` | a person in a year (LISA style) | 2019-2023, one file per year |
| `foretag_2019.csv` ... `foretag_2023.csv` | a firm in a year | 2019-2023, one file per year |
| `agi_manad_2023.csv` | pay from one employer to one person in one month (employer declarations, AGI style) | 2023 |
| `betyg_ak9.csv` | a grading at the end of compulsory school (grade 9), wide: one column per subject | year of grading |
| `gymn_kurser.csv` | one course in upper secondary school, with its grade | year of leaving |
| `migrationer.csv` | a migration event (into or out of Sweden) | 2019-2024 |
| `insatser_kommun.csv` | an activity spell in the municipal activity register | 2019-2023 |
| `insatser_stat.csv` | an activity spell in the state programme register | 2013-2023 |
| `GENERATED.txt` | the seed and pair label your files were generated with | |

## persons.csv

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `Kon` | sex | 0 = man, 1 = woman |
| `FodelseAr` | year of birth | YYYY |
| `FodelseManad` | year and month of birth | YYYYMM |
| `FodelseLandNamn` | country of birth, Swedish name in capitals | `SVERIGE` = born in Sweden |
| `DodDatum` | date of death | YYYYMMDD; empty if the person was alive at the end of 2023 |

## lisa_YYYY.csv (yearly individual file)

Several variables were renamed in 2021, when the file moved to a new vintage. The table gives the name used in each vintage.

| Name 2019-2020 | Name 2021-2023 | Description | Codes and missing values |
|---|---|---|---|
| `LopNr` | `LopNr` | person id | never missing |
| `SenInvAr` | `SenInvAr` | year of the most recent immigration | YYYY; `0000` = never immigrated |
| `Barn0_3`, `Barn4_6`, `Barn7_10`, `Barn11_15`, `Barn16_17` | same | number of children in the household in each age band | counts; an empty cell means not reported |
| `ExamAr` | `ExamAr` | year of the most recent education credit (a completed course, not necessarily a degree) | YYYY; empty if none |
| `Sun2000Niva` | `Sun2020Niva` | highest education, 3-digit level code | see *Education codes*; `999` = unknown |
| `Sun2000Niva_Old` | `Sun2020Niva_Old` | highest education, coded by the earlier definition of the level variable | `*` = unknown |
| `HsDelt` | `HsDelt` | registered in higher education (not PhD) | 0 = no; 1, 2, 3 = yes, with rising study intensity |
| `FoDelt` | `FoDelt` | registered in PhD studies | 0 = no; 1, 2, 3 = yes, with rising study intensity |
| `SyssStat11` | `SyssStat19` | employment status | see *Employment status* |
| `KU1SSYK4` | `AGI1SSYK4` | occupation at the main employer, 4-digit code in the SSYK style (values invented) | `****` = not employed |
| `KU1PeOrgNr` | `KU1PeOrgNr` | id of the main employer (the one that paid the most in the year) | empty if not employed |
| `KU1Ink` | `AGI1Ink` | wage income from the main employer, hundreds of SEK | |
| `ForvErs` | `ForvErs` | income from work and work-related benefits, hundreds of SEK | |
| `KapInk` | `KapInk` | income from capital, hundreds of SEK | |
| `Stud` | `Stud` | study support received, hundreds of SEK | 0 = none |
| `AlosDag` | `AlosDag` | days registered as unemployed in the year | an empty cell means not reported |

**Education codes** (`Sun2000Niva`, from 2021 `Sun2020Niva`). Three digits. The first digit is the broad level: 1 primary (shorter than 9 years), 2 compulsory school (9 years), 3 upper secondary, 4 short post-secondary, 5 higher education, 6 postgraduate. The second digit is the length within the level. The code list was revised in 2021, and some codes changed; the first two digits keep their meaning.

**Employment status** (`SyssStat11`, from 2021 `SyssStat19`). 1 = employed (including self-employed); 5 and 6 = not employed. From 2021 also 7 = employed, known only from the monthly employer declarations.

## foretag_YYYY.csv (yearly firm file)

| Variable | Description | Codes and missing values |
|---|---|---|
| `PeOrgNr` | firm id | |
| `SNI2007` | industry, 5-digit code; keep it as text (leading zeros matter) | `00000` = unknown |
| `MedelAntalAnstallda` | average number of employees | |
| `Nettoomsattning` | net sales, thousands of SEK | |
| `Foradlingsvarde` | value added, thousands of SEK | |
| `Rorelseresultat` | operating profit, thousands of SEK | can be negative |
| `SummaPersonalkostnader` | total personnel costs (wages and social fees), thousands of SEK | stored as negative numbers (accounting sign convention) |

## agi_manad_2023.csv (monthly employer declarations)

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `PeOrgNr` | id of the employer that declared the pay | |
| `Period` | month of payment | YYYYMM |
| `Lon` | cash pay in the month, SEK | |
| `AnstForm` | form of employment | 1 = permanent, 2 = fixed-term, 3 = hourly; empty = not reported by the employer |

A person can have more than one employer in a year. The main employer in the yearly file is the employer that paid the most over the year.

## betyg_ak9.csv (grade 9)

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `Ar` | year of grading | YYYY. A person graded in two years has two rows; the later grading counts. |
| `BILD`, `ENGELSKA`, `HEMKUNSKAP`, `IDROTT`, `MATEMATIK`, `MUSIK`, `BIOLOGI`, `FYSIK`, `KEMI`, `GEOGRAFI`, `HISTORIA`, `RELIGION`, `SAMHALL`, `SLOJD`, `SVENSKA`, `TEKNIK`, `SPRAK1`, `SPRAK2` | grade in each subject (art, English, home economics, physical education, mathematics, music, biology, physics, chemistry, geography, history, religion, civics, crafts, Swedish, technology, modern languages 1 and 2) | see below |

Grade codes: `IG` fail (0 points), `G` pass (10), `VG` pass with distinction (15), `MVG` pass with special distinction (20). `A` = no grades in any subject; `2` = subject not taken; `*` = unknown; an empty cell = no grade. The total grade (*meritvärde*) is the sum of the 16 best subject grades.

## gymn_kurser.csv (upper secondary courses)

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `AvgAr` | year of leaving upper secondary school | YYYY |
| `KursKod` | course code | |
| `Betyg` | course grade | leavers before 2014: `IG`, `G`, `VG`, `MVG` (0, 10, 15, 20 points); leavers from 2014: `F`, `E`, `D`, `C`, `B`, `A` (0, 10, 12.5, 15, 17.5, 20 points) |
| `Poang` | course points (the course's weight) | |

The final grade is the points-weighted average of the course grades.

## migrationer.csv

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `Datum` | date of the event | YYYY-MM-DD |
| `PostTyp` | type of event | `Inv` = immigration, `Utv` = emigration |
| `InUtvLand` | country moved from or to, Swedish name in capitals | `OKÄNT` = unknown |

## insatser_kommun.csv and insatser_stat.csv (activity spells)

| Variable | Description | Codes and missing values |
|---|---|---|
| `LopNr` | person id | never missing |
| `Ar` | year of the spell | YYYY |
| `Alder` | the person's age that year | years |
| `HKod` | main activity code of the spell | see *Activity codes* |
| `Kod1` ... `Kod8` (municipal), `Kod1` ... `Kod10` (state) | all activity codes of the spell; `Kod1` repeats the main code, the others are secondary codes | empty = no further code |

**Activity codes** (invented). Letter codes, by first letter: A and B job-search support; C and D training; E employment subsidy, except `E30` (start-up subsidy), which is not part of E; F work placement (`F12`, `F15` and `F18` are youth placements, meant for persons under 25); H and L matching services; every other letter is an other or administrative code. The municipal register uses letter codes in every year. Before 2017 the state register uses 4-digit numeric codes, whose first three digits give the category: 100-199 AB, 200-299 CD, 300-399 E, 400-499 F, 500-649 HL, 650-999 other; from 2017 it uses the letter codes.

## Sentinel codes: values that look like data but mean "missing"

| Code | Where | Meaning |
|---|---|---|
| `0000` | `SenInvAr` | never immigrated |
| `999` | `Sun2000Niva`, `Sun2020Niva` | education unknown |
| `*` | `Sun2000Niva_Old`, `Sun2020Niva_Old`; grade-9 subjects | unknown |
| `****` | `KU1SSYK4`, `AGI1SSYK4` | not employed |
| `00000` | `SNI2007` | industry unknown |
