"""Self-check for the bug hunt after Session 3: which of your answers are right?

Run it from VS Code (open this file, press the play button) or in the
terminal from the lab folder:
    uv run check_exercise_s3.py                    checks bug_hunt_s3.py, for its PAIR
    uv run check_exercise_s3.py 07                 checks bug_hunt_s3.py as pair 07
    uv run check_exercise_s3.py my_copy.py 07      checks another file

The right answers differ from pair to pair. They are stored in answers_s3.json
as fingerprints (SHA-256 hashes), so reading that file does not give them away:
the check turns YOUR answer into a fingerprint the same way and compares.
Numbers that are not whole are compared at three decimals; names ignore
upper/lower case; lists ignore order.
It runs your script cell by cell and never changes it.
Runtime: under 3 seconds. Last line printed: "N of 6 tasks right."
"""
import contextlib
import hashlib
import io
import json
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent

# The answer names, task by task (the names in bug_hunt_s3.py)
TASKS = {
    "Task 1  the flawed script ran on your data": ["n_outputs"],
    "Task 2  the level-1 bugs in numbers": ["ak9_rows_per_person", "lisa_years",
                                            "firm_years", "n_mig_missing"],
    "Task 3  three codebook errata": ["kon_codes", "employer_col_2021",
                                      "missing_id_file", "n_missing_id"],
    "Task 4  the youth flag (level 2)": ["n_youth_flawed", "n_youth_right"],
    "Task 5  education after the new vintage (level 3)": [
        "share_educ_missing_2021_flawed", "share_educ_missing_2021_right"],
    "Task 6  the firm block from April (level 3)": ["n_dropped_by_dedup",
                                                    "n_exact_copies", "permshare_right"],
}
HINTS = {
    "Task 1": "run clean_registers_flawed.py on your pair (lab Step 8) until it finishes.",
    "Task 2": "open the outputs with pd.read_csv(FLAWED / ...); count rows, years and missing values.",
    "Task 3": "value_counts() of Kon; the columns of lisa_2021.csv; isna().sum() of LopNr in EVERY raw file.",
    "Task 4": "the flawed count is in the output; the right one needs a condition with brackets (or isin).",
    "Task 5": "a share is a mean of True/False; the right share counts only the codebook's 'unknown' code.",
    "Task 6": "compare len() before and after each drop; blanks in AnstForm are not a code.",
}


def normalise(x) -> str:
    """Turn an answer into one standard text, so equal answers match."""
    if hasattr(x, "tolist") and not isinstance(x, str):
        x = x.tolist()
    if isinstance(x, (list, tuple, set)):
        return ",".join(sorted(normalise(v) for v in x))
    if isinstance(x, str):
        return x.strip().lower()
    try:
        f = float(x)
    except (TypeError, ValueError):
        return str(x)
    return str(int(f)) if f.is_integer() else f"{f:.3f}"


def fingerprint(pair: int, name: str, value) -> str:
    """The SHA-256 hash of one answer for one pair."""
    text = f"na446a-s3|{pair:02d}|{name}|{normalise(value)}"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def run_cells(script: Path, pair: str | None) -> dict:
    """Run a # %% script cell by cell in one namespace, as VS Code does."""
    ns = {"__file__": str(script), "__name__": "__exercise__"}
    cells, current = [], []
    for line in script.read_text(encoding="utf-8").splitlines(keepends=True):
        if line.startswith("# %%") and current:
            cells.append("".join(current))
            current = []
        current.append(line)
    cells.append("".join(current))
    for i, cell in enumerate(cells):
        try:
            exec(compile(cell, f"{script.name}, cell {i}", "exec"), ns)
        except Exception as err:                       # report, keep going
            last = traceback.format_exception_only(type(err), err)[-1].strip()
            first = cell.strip().splitlines()[0].lstrip("# %").strip()
            print(f"  (cell '{first[:45]}' stopped with: {last})")
        if pair is not None and "CHANGE HERE" in cell:
            ns["PAIR"] = pair
    return ns


def main() -> None:
    args = sys.argv[1:]
    script = HERE / next((a for a in args if a.endswith(".py")), "bug_hunt_s3.py")
    pair_arg = next((a for a in args if a.isdigit()), None)
    print(f"Checking {script.name} ...")
    with contextlib.redirect_stdout(io.StringIO()) as quiet:   # hide your prints
        ns = run_cells(script, None if pair_arg is None else f"{int(pair_arg):02d}")
    pair = int(pair_arg) if pair_arg is not None else int(ns.get("PAIR", "0"))
    print(f"Pair {pair:02d}\n")
    errors = [ln for ln in quiet.getvalue().splitlines() if ln.startswith("  (cell")]
    if errors:
        print("Some cells stopped with an error (fix these first):")
        print("\n".join(errors), "\n")

    answers = json.loads((HERE / "answers_s3.json").read_text(encoding="utf-8"))
    if f"{pair:02d}" not in answers:
        sys.exit(f"No answers stored for pair {pair:02d} (pairs 00-{max(answers)}).")
    right = answers[f"{pair:02d}"]
    n_right = 0
    for task, names in TASKS.items():
        wrong = [n for n in names
                 if n not in ns or ns[n] is Ellipsis
                 or fingerprint(pair, n, ns[n]) != right[n]]
        n_right += not wrong
        print(f"{'OK      ' if not wrong else 'NOT YET '} {task}")
        if wrong:
            print(f"         not yet right: {', '.join(wrong)}")
            print(f"         hint: {HINTS[task.split('  ')[0]]}")
    print(f"\n{n_right} of {len(TASKS)} tasks right.")


if __name__ == "__main__":
    main()
