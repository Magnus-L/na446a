***** START A LOG FILE ****
set logtype t
set linesize 120
cap noisily log close
cd "C:/Users/teacher/project/"
pwd
log using "C:/Users/teacher/project/output/clean_registers.log", replace

****** PREAMBLE ****
* DO-file: clean_registers_flawed.do
* Created: 3 March
* Modified: 11 March
* This do-file cleans the register files and produces some stats, before merging
***
clear all
set more off
********************


******* persons - OK
* Contains everybody in the study population and basic vars
clear all
import delimited using "C:/Users/teacher/project/data/raw/persons.csv", varnames(1) case(preserve) stringcols(_all) clear
* descriptives
des
* fix lopnr
rename LopNr lopnr, replace
* fodelsear convert to numeric
destring FodelseAr, replace
rename FodelseAr fodelsear
* fix kon
destring Kon, replace
rename Kon kon
label var kon "(2,1) woman, man"
* fix fodelsemanad
replace FodelseManad = FodelseManad + "15"
gen fodelsemanad = date(FodelseManad, "YMD")
format fodelsemanad %td
label var fodelsemanad "Year and month of birth + 15th of each month"
drop FodelseManad
* fix fodelselandnamn
gen foddsverige = 1 if FodelseLandNamn == "SVERIGE"
replace foddsverige = 0 if FodelseLandNamn != "SVERIGE" & !mi(FodelseLandNamn)
label var foddsverige "(1,0) Swedish-born, foreign-born"
drop FodelseLandNamn
* fix DodDatum
gen doddatum = date(DodDatum, "YMD")
format doddatum %td
label var doddatum "Date of death"
drop DodDatum
* Note: a handful of persons dead during the period, others are missing values
* there are some duplicates in the delivery, remove them
duplicates drop
sort lopnr
compress
codebook, compact
* All vars in correct format and no strange values
save "C:/Users/teacher/project/data/processed/flawed_stata/se_persons.dta", replace
*********


*** ak9
* Contains grades from grade 9
clear all
import delimited using "C:/Users/teacher/project/data/raw/betyg_ak9.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace
* fix ar
gen xx = date(Ar, "Y")
format xx %td
gen ak9ar = year(xx)
label var ak9ar "Year of graduating, grade 9"
drop xx Ar

* betyg
***convert grades to numerical
***Explanation of the values: IG = not passed, G = passed, VG = passed with distinction,
***MVG = passed with special distinction, A = no grades in any subject, 2 = subject not taken
***the * is used in the delivery for unknown
gen bild = 10 if BILD == "G"
replace bild = 15 if BILD == "V" | BILD == "VG"
replace bild = 20 if BILD == "M" | BILD == "MVG"
replace bild = 0 if BILD == "1" | BILD == "I" | BILD == "IG"
replace bild = . if BILD == "A" | BILD == "*" | BILD == "2"
label var bild "Grades in art"
gen eng = 10 if ENGELSKA == "G"
replace eng = 15 if ENGELSKA == "V" | ENGELSKA == "VG"
replace eng = 20 if ENGELSKA == "M" | ENGELSKA == "MVG"
replace eng = 0 if ENGELSKA == "1" | ENGELSKA == "I" | ENGELSKA == "IG"
replace eng = . if ENGELSKA == "A" | ENGELSKA == "*" | ENGELSKA == "2"
label var eng "Grades in English"
gen hkk = 10 if HEMKUNSKAP == "G"
replace hkk = 15 if HEMKUNSKAP == "V" | HEMKUNSKAP == "VG"
replace hkk = 20 if HEMKUNSKAP == "M" | HEMKUNSKAP == "MVG"
replace hkk = 0 if HEMKUNSKAP == "1" | HEMKUNSKAP == "I" | HEMKUNSKAP == "IG"
replace hkk = . if HEMKUNSKAP == "A" | HEMKUNSKAP == "*" | HEMKUNSKAP == "2"
label var hkk "Grades in home economics"
gen idh = 10 if IDROTT == "G"
replace idh = 15 if IDROTT == "V" | IDROTT == "VG"
replace idh = 20 if IDROTT == "M" | IDROTT == "MVG"
replace idh = 0 if IDROTT == "1" | IDROTT == "I" | IDROTT == "IG"
replace idh = . if IDROTT == "A" | IDROTT == "*" | IDROTT == "2"
label var idh "Grades in physical education"
gen maths = 10 if MATEMATIK == "G"
replace maths = 15 if MATEMATIK == "V" | MATEMATIK == "VG"
replace maths = 20 if MATEMATIK == "M" | MATEMATIK == "MVG"
replace maths = 0 if MATEMATIK == "1" | MATEMATIK == "I" | MATEMATIK == "IG"
replace maths = . if MATEMATIK == "A" | MATEMATIK == "*" | MATEMATIK == "2"
label var maths "Grades in mathematics"
gen mu = 10 if MUSIK == "G"
replace mu = 15 if MUSIK == "V" | MUSIK == "VG"
replace mu = 20 if MUSIK == "M" | MUSIK == "MVG"
replace mu = 0 if MUSIK == "1" | MUSIK == "I" | MUSIK == "IG"
replace mu = . if MUSIK == "A" | MUSIK == "*" | MUSIK == "2"
label var mu "Grades in music"
gen bi = 10 if BIOLOGI == "G"
replace bi = 15 if BIOLOGI == "V" | BIOLOGI == "VG"
replace bi = 20 if BIOLOGI == "M" | BIOLOGI == "MVG"
replace bi = 0 if BIOLOGI == "1" | BIOLOGI == "I" | BIOLOGI == "IG"
replace bi = . if BIOLOGI == "A" | BIOLOGI == "*" | BIOLOGI == "2"
label var bi "Grades in biology"
gen fy = 10 if FYSIK == "G"
replace fy = 15 if FYSIK == "V" | FYSIK == "VG"
replace fy = 20 if FYSIK == "M" | FYSIK == "MVG"
replace fy = 0 if FYSIK == "1" | FYSIK == "I" | FYSIK == "IG"
replace fy = . if FYSIK == "A" | FYSIK == "*" | FYSIK == "2"
label var fy "Grades in physics"
gen ke = 10 if KEMI == "G"
replace ke = 15 if KEMI == "V" | KEMI == "VG"
replace ke = 20 if KEMI == "M" | KEMI == "MVG"
replace ke = 0 if KEMI == "1" | KEMI == "I" | KEMI == "IG"
replace ke = . if KEMI == "A" | KEMI == "*" | KEMI == "2"
label var ke "Grades in chemistry"
gen geo = 10 if GEOGRAFI == "G"
replace geo = 15 if GEOGRAFI == "V" | GEOGRAFI == "VG"
replace geo = 20 if GEOGRAFI == "M" | GEOGRAFI == "MVG"
replace geo = 0 if GEOGRAFI == "1" | GEOGRAFI == "I" | GEOGRAFI == "IG"
replace geo = . if GEOGRAFI == "A" | GEOGRAFI == "*" | GEOGRAFI == "2"
label var geo "Grades in geography"
gen hi = 10 if HISTORIA == "G"
replace hi = 15 if HISTORIA == "V" | HISTORIA == "VG"
replace hi = 20 if HISTORIA == "M" | HISTORIA == "MVG"
replace hi = 0 if HISTORIA == "1" | HISTORIA == "I" | HISTORIA == "IG"
replace hi = . if HISTORIA == "A" | HISTORIA == "*" | HISTORIA == "2"
label var hi "Grades in history"
gen re = 10 if RELIGION == "G"
replace re = 15 if RELIGION == "V" | RELIGION == "VG"
replace re = 20 if RELIGION == "M" | RELIGION == "MVG"
replace re = 0 if RELIGION == "1" | RELIGION == "I" | RELIGION == "IG"
replace re = . if RELIGION == "A" | RELIGION == "*" | RELIGION == "2"
label var re "Grades in religion"
gen samh = 10 if SAMHALL == "G"
replace samh = 15 if SAMHALL == "V" | SAMHALL == "VG"
replace samh = 20 if SAMHALL == "M" | SAMHALL == "MVG"
replace samh = 0 if SAMHALL == "1" | SAMHALL == "I" | SAMHALL == "IG"
replace samh = . if SAMHALL == "A" | SAMHALL == "*" | SAMHALL == "2"
label var samh "Grades in civics"
gen sl = 10 if SLOJD == "G"
replace sl = 15 if SLOJD == "V" | SLOJD == "VG"
replace sl = 20 if SLOJD == "M" | SLOJD == "MVG"
replace sl = 0 if SLOJD == "1" | SLOJD == "I" | SLOJD == "IG"
replace sl = . if SLOJD == "A" | SLOJD == "*" | SLOJD == "2"
label var sl "Grades in crafts"
gen sv = 10 if SVENSKA == "G"
replace sv = 15 if SVENSKA == "V" | SVENSKA == "VG"
replace sv = 20 if SVENSKA == "M" | SVENSKA == "MVG"
replace sv = 0 if SVENSKA == "1" | SVENSKA == "I" | SVENSKA == "IG"
replace sv = . if SVENSKA == "A" | SVENSKA == "*" | SVENSKA == "2"
label var sv "Grades in Swedish"
gen tk = 10 if TEKNIK == "G"
replace tk = 15 if TEKNIK == "V" | TEKNIK == "VG"
replace tk = 20 if TEKNIK == "M" | TEKNIK == "MVG"
replace tk = 0 if TEKNIK == "1" | TEKNIK == "I" | TEKNIK == "IG"
replace tk = . if TEKNIK == "A" | TEKNIK == "*" | TEKNIK == "2"
label var tk "Grades in technology"
gen mspr1 = 10 if SPRAK1 == "G"
replace mspr1 = 15 if SPRAK1 == "V" | SPRAK1 == "VG"
replace mspr1 = 20 if SPRAK1 == "M" | SPRAK1 == "MVG"
replace mspr1 = 0 if SPRAK1 == "1" | SPRAK1 == "I" | SPRAK1 == "IG"
replace mspr1 = . if SPRAK1 == "A" | SPRAK1 == "*" | SPRAK1 == "2"
label var mspr1 "Grades in modern language 1"
gen mspr2 = 10 if SPRAK2 == "G"
replace mspr2 = 15 if SPRAK2 == "V" | SPRAK2 == "VG"
replace mspr2 = 20 if SPRAK2 == "M" | SPRAK2 == "MVG"
replace mspr2 = 0 if SPRAK2 == "1" | SPRAK2 == "I" | SPRAK2 == "IG"
replace mspr2 = . if SPRAK2 == "A" | SPRAK2 == "*" | SPRAK2 == "2"
label var mspr2 "Grades in modern language 2"
drop BILD ENGELSKA HEMKUNSKAP IDROTT MATEMATIK MUSIK BIOLOGI FYSIK KEMI GEOGRAFI HISTORIA RELIGION SAMHALL SLOJD SVENSKA TEKNIK SPRAK1 SPRAK2

**Total grade (meritvarde) needs to be calculated. It is the sum of the 16 best grades***
*** Some persons are registered two years after each other. If two grades, it is the latest grade
*** that should be used. Collapsing by max gives the latest grade in most cases, we checked a few.

sort lopnr
collapse (max) bild eng hkk idh maths mu bi fy ke geo hi re samh sl sv tk mspr1 mspr2, by(lopnr)

rename (bild-mspr2) (betyg#), addnumber

reshape long betyg, i(lopnr) j(j)

drop j

replace betyg=. if betyg==0

bysort lopnr (betyg): gen rank = _n
gen top16_flag = rank <=16
bysort lopnr: egen totalbetyg_ak9 = total(betyg) if top16_flag
list lopnr totalbetyg_ak9 in 1/40, sepby(lopnr)

drop betyg top16_flag rank
drop if mi(totalbetyg_ak9)
duplicates drop

compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_ak9.dta", replace
*********



*** gymn
* Contains grades from upper secondary school, one row per course
clear all
import delimited using "C:/Users/teacher/project/data/raw/gymn_kurser.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace
* fix avgar
gen xx = date(AvgAr, "Y")
format xx %td
gen avgar = year(xx)
label var avgar "Year of graduation, gymnasium"
drop xx AvgAr
destring Poang, replace
rename Poang poang

***Change grades to nummerical**
gen betyg = 0 if Betyg == "IG" | Betyg == "I"
replace betyg = 10 if Betyg == "G"
replace betyg = 15 if Betyg == "VG" | Betyg == "V"
replace betyg = 20 if Betyg == "MVG" | Betyg == "M"

drop Betyg
***Try to calculate final grades, slutbetyg (points-weighted average)*****
gen x = betyg*poang
bys lopnr : egen tot = total(x)
bys lopnr : egen totkursp = total(poang)

gen int slutbetyggym = tot/totkursp

keep lopnr slutbetyggym
duplicates drop
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_gymn.dta", replace
********



********** LISA *********

* Comment: SCB has good documentation on LISA with detailed info about the vars,
*see the background facts pdf on scb.se

*LISA2019

* contains lots of info for each individual about labour market etc
clear all
import delimited using "C:/Users/teacher/project/data/raw/lisa_2019.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace

* Change to lower case var names
rename *, lower

* fix SenInvAr
replace seninvar="." if seninvar=="0000"
gen xx = date(seninvar, "Y")
format xx %td
drop seninvar
gen seninvar = year(xx)
label var seninvar "Most recent year of immigration, otherwise missing value"
notes seninvar: Most obs missing, not having immigrated.
drop xx

* barn
destring barn0_3 barn4_6 barn7_10 barn11_15 barn16_17, replace
gen barn0_17 = barn0_3 + barn4_6 + barn7_10 + barn11_15 + barn16_17
replace barn0_17=0 if mi(barn0_17)
label var barn0_17 "No. of children, aged 0-17 yrs, if any, otherwise 0"
drop barn0_3 barn4_6 barn7_10 barn11_15 barn16_17

* fix examar
gen xx = date(examar, "Y")
format xx %td
drop examar
gen examar = year(xx)
label var examar "Most recent year of education credits, see var note"
notes examar: Completion year of educ, e.g., completing a course, not necessarily finishing the whole educ. Many missing values.
drop xx

* replace erroneous missing demarker * with true missing
replace sun2000niva_old = "." if sun2000niva_old=="*"
replace sun2000niva = "." if sun2000niva== "999"

* destring several vars
destring sun2000niva_old sun2000niva fodelt hsdelt syssstat11 ku1ink forvers kapink stud alosdag, replace

* educational level- new variable
gen educat_level = 1 if sun2000niva == 100 | sun2000niva == 106
replace educat_level = 2 if sun2000niva == 200 | sun2000niva == 206
replace educat_level = 3 if sun2000niva == 310 | sun2000niva == 312 | sun2000niva == 316
replace educat_level = 4 if sun2000niva == 320 | sun2000niva == 322 | sun2000niva == 326
replace educat_level = 5 if sun2000niva == 330 | sun2000niva == 332 | sun2000niva == 336
replace educat_level = 6 if sun2000niva == 410 | sun2000niva == 412 | sun2000niva == 416
replace educat_level = 7 if sun2000niva == 520 | sun2000niva == 522 | sun2000niva == 526
replace educat_level = 8 if sun2000niva == 530 | sun2000niva == 532 | sun2000niva == 536
replace educat_level = 9 if sun2000niva == 540 | sun2000niva == 546
replace educat_level = 10 if sun2000niva == 550 | sun2000niva == 556
replace educat_level = 11 if sun2000niva == 600 | sun2000niva == 640

label var educat_level "Educational level"
notes educat_level: 1: primary <9y, 2: primary 9 years, 3: upper sec < 2y, 4: upper sec 2y, 5: upper sec 3y, 6: post-sec <2y, 7: post-sec 2y, 8: university 3y, 9: university 4y, 10: university 5y or more, 11: postgraduate

* higher education current studies
rename hsdelt xx
recode xx (1 2 3 =1), gen(hsdelt2)
label var hsdelt2 "(1,0) registered hi-educ studies (not PhD stud), or not"
rename fodelt yy
recode yy (1 2 3 =1), gen(fodelt2)
label var fodelt2 "(1,0) registered PhD studies, or not"
*drop xx yy
gen hieduc = 1 if hsdelt==1 | fodelt==1
replace hieduc = 0 if mi(hieduc)
label var hieduc "(1,0) registered hi-educ studies (lower or PhD), or not"

* employment status
recode syssstat11 (5 6 = 0), gen(working)
label var working "(1,0) employed and/or entrepreneur, or not"
notes working: Employed or own business, category 1 of syssstat11, or not (categories 5 and 6).

* occupational group
replace ku1ssyk4 = "." if ku1ssyk4 == "****"
gen occgrp = substr(ku1ssyk4, 1, 1)
destring occgrp, replace
label var occgrp "1-digit occupational SSYK code at main employer, if employed"

* studying (getting study income, irrespective of level)
gen stud2 = 1 if stud >0 & !mi(stud)
label var stud2 "(1,0) studying, or not, as indicated by studies income support"

* unemployment
gen unemp = 1 if alosdag > 0
replace unemp = 0 if mi(unemp)
label var unemp "(1,0) if unemployed > 0 days, or not"

* incomes
label var forvers "Income (100 SEK) from employment or business or related support"
label var kapink "Income (100 SEK) from capital"

keep lopnr educat_level ku1peorgnr seninvar barn0_17 examar hsdelt2 fodelt2 hieduc working occgrp stud2 unemp forvers kapink ku1ink

gen int year=2019
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2019.dta", replace
*******

*LISA2020

* contains lots of info for each individual about labour market etc
clear all
import delimited using "C:/Users/teacher/project/data/raw/lisa_2020.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace

* Change to lower case var names
rename *, lower

* fix SenInvAr
replace seninvar="." if seninvar=="0000"
gen xx = date(seninvar, "Y")
format xx %td
drop seninvar
gen seninvar = year(xx)
label var seninvar "Most recent year of immigration, otherwise missing value"
notes seninvar: Most obs missing, not having immigrated.
drop xx

* barn
destring barn0_3 barn4_6 barn7_10 barn11_15 barn16_17, replace
gen barn0_17 = barn0_3 + barn4_6 + barn7_10 + barn11_15 + barn16_17
replace barn0_17=0 if mi(barn0_17)
label var barn0_17 "No. of children, aged 0-17 yrs, if any, otherwise 0"
drop barn0_3 barn4_6 barn7_10 barn11_15 barn16_17

* fix examar
gen xx = date(examar, "Y")
format xx %td
drop examar
gen examar = year(xx)
label var examar "Most recent year of education credits, see var note"
notes examar: Completion year of educ, e.g., completing a course, not necessarily finishing the whole educ. Many missing values.
drop xx

* replace erroneous missing demarker * with true missing
replace sun2000niva_old = "." if sun2000niva_old=="*"
replace sun2000niva = "." if sun2000niva== "999"

* destring several vars
destring sun2000niva_old sun2000niva fodelt hsdelt syssstat11 ku1ink forvers kapink stud alosdag, replace

* educational level- new variable
gen educat_level = 1 if sun2000niva == 100 | sun2000niva == 106
replace educat_level = 2 if sun2000niva == 200 | sun2000niva == 206
replace educat_level = 3 if sun2000niva == 310 | sun2000niva == 312 | sun2000niva == 316
replace educat_level = 4 if sun2000niva == 320 | sun2000niva == 322 | sun2000niva == 326
replace educat_level = 5 if sun2000niva == 330 | sun2000niva == 332 | sun2000niva == 336
replace educat_level = 6 if sun2000niva == 410 | sun2000niva == 412 | sun2000niva == 416
replace educat_level = 7 if sun2000niva == 520 | sun2000niva == 522 | sun2000niva == 526
replace educat_level = 8 if sun2000niva == 530 | sun2000niva == 532 | sun2000niva == 536
replace educat_level = 9 if sun2000niva == 540 | sun2000niva == 546
replace educat_level = 10 if sun2000niva == 550 | sun2000niva == 556
replace educat_level = 11 if sun2000niva == 600 | sun2000niva == 640

label var educat_level "Educational level"
notes educat_level: 1: primary <9y, 2: primary 9 years, 3: upper sec < 2y, 4: upper sec 2y, 5: upper sec 3y, 6: post-sec <2y, 7: post-sec 2y, 8: university 3y, 9: university 4y, 10: university 5y or more, 11: postgraduate

* higher education current studies
rename hsdelt xx
recode xx (1 2 3 =1), gen(hsdelt2)
label var hsdelt2 "(1,0) registered hi-educ studies (not PhD stud), or not"
rename fodelt yy
recode yy (1 2 3 =1), gen(fodelt2)
label var fodelt2 "(1,0) registered PhD studies, or not"
*drop xx yy
gen hieduc = 1 if hsdelt==1 | fodelt==1
replace hieduc = 0 if mi(hieduc)
label var hieduc "(1,0) registered hi-educ studies (lower or PhD), or not"

* employment status
recode syssstat11 (5 6 = 0), gen(working)
label var working "(1,0) employed and/or entrepreneur, or not"
notes working: Employed or own business, category 1 of syssstat11, or not (categories 5 and 6).

* occupational group
replace ku1ssyk4 = "." if ku1ssyk4 == "****"
gen occgrp = substr(ku1ssyk4, 1, 1)
destring occgrp, replace
label var occgrp "1-digit occupational SSYK code at main employer, if employed"

* studying (getting study income, irrespective of level)
gen stud2 = 1 if stud >0 & !mi(stud)
label var stud2 "(1,0) studying, or not, as indicated by studies income support"

* unemployment
gen unemp = 1 if alosdag > 0
replace unemp = 0 if mi(unemp)
label var unemp "(1,0) if unemployed > 0 days, or not"

* incomes
label var forvers "Income (100 SEK) from employment or business or related support"
label var kapink "Income (100 SEK) from capital"

keep lopnr educat_level ku1peorgnr seninvar barn0_17 examar hsdelt2 fodelt2 hieduc working occgrp stud2 unemp forvers kapink ku1ink

gen int year=2019
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2020.dta", replace
*******

*LISA2021

* contains lots of info for each individual about labour market etc
clear all
import delimited using "C:/Users/teacher/project/data/raw/lisa_2021.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace

***variables Sun2000Niva and Sun2000Niva_Old do not exist any longer, Sun2020Niva and Sun2020Niva_Old are used now***
*****Also SyssStat11 is replaced by SyssStat19****
***Variables KU1Ink KU1SSYK4 KU1PeOrgNr replaced by AGI1Ink AGI1SSYK4 AGI1PeOrgNr**

* Change to lower case var names
rename *, lower

* fix SenInvAr
replace seninvar="." if seninvar=="0000"
gen xx = date(seninvar, "Y")
format xx %td
drop seninvar
gen seninvar = year(xx)
label var seninvar "Most recent year of immigration, otherwise missing value"
notes seninvar: Most obs missing, not having immigrated.
drop xx

* barn
destring barn0_3 barn4_6 barn7_10 barn11_15 barn16_17, replace
gen barn0_17 = barn0_3 + barn4_6 + barn7_10 + barn11_15 + barn16_17
replace barn0_17=0 if mi(barn0_17)
label var barn0_17 "No. of children, aged 0-17 yrs, if any, otherwise 0"
drop barn0_3 barn4_6 barn7_10 barn11_15 barn16_17

* fix examar
gen xx = date(examar, "Y")
format xx %td
drop examar
gen examar = year(xx)
label var examar "Most recent year of education credits, see var note"
notes examar: Completion year of educ, e.g., completing a course, not necessarily finishing the whole educ. Many missing values.
drop xx

* replace erroneous missing demarker * with true missing
replace sun2020niva_old = "." if sun2020niva_old=="*"
replace sun2020niva = "." if sun2020niva== "999"

* destring several vars
destring sun2020niva_old sun2020niva fodelt hsdelt syssstat19 agi1ink forvers kapink stud alosdag, replace

* educational level- new variable
gen educat_level = 1 if sun2020niva == 100 | sun2020niva == 106
replace educat_level = 2 if sun2020niva == 200 | sun2020niva == 206
replace educat_level = 3 if sun2020niva == 310 | sun2020niva == 312 | sun2020niva == 316
replace educat_level = 4 if sun2020niva == 320 | sun2020niva == 322 | sun2020niva == 326
replace educat_level = 5 if sun2020niva == 330 | sun2020niva == 332 | sun2020niva == 336
replace educat_level = 6 if sun2020niva == 410 | sun2020niva == 412 | sun2020niva == 416
replace educat_level = 7 if sun2020niva == 520 | sun2020niva == 522 | sun2020niva == 526
replace educat_level = 8 if sun2020niva == 530 | sun2020niva == 532 | sun2020niva == 536
replace educat_level = 9 if sun2020niva == 540 | sun2020niva == 546
replace educat_level = 10 if sun2020niva == 550 | sun2020niva == 556
replace educat_level = 11 if sun2020niva == 600 | sun2020niva == 640

label var educat_level "Educational level"
notes educat_level: 1: primary <9y, 2: primary 9 years, 3: upper sec < 2y, 4: upper sec 2y, 5: upper sec 3y, 6: post-sec <2y, 7: post-sec 2y, 8: university 3y, 9: university 4y, 10: university 5y or more, 11: postgraduate
***Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups****

* higher education current studies
rename hsdelt xx
recode xx (1 2 3 =1), gen(hsdelt2)
label var hsdelt2 "(1,0) registered hi-educ studies (not PhD stud), or not"
rename fodelt yy
recode yy (1 2 3 =1), gen(fodelt2)
label var fodelt2 "(1,0) registered PhD studies, or not"
*drop xx yy
gen hieduc = 1 if hsdelt==1 | fodelt==1
replace hieduc = 0 if mi(hieduc)
label var hieduc "(1,0) registered hi-educ studies (lower or PhD), or not"

* employment status
recode syssstat19 (5 6 = 0), gen(working)
label var working "(1,0) employed and/or entrepreneur, or not"
notes working: Employed or own business, category 1 of syssstat19, or not (categories 5 and 6).

* occupational group
replace agi1ssyk4 = "." if agi1ssyk4 == "****"
gen occgrp = substr(agi1ssyk4, 1, 1)
destring occgrp, replace
label var occgrp "1-digit occupational SSYK code at main employer, if employed"

* studying (getting study income, irrespective of level)
gen stud2 = 1 if stud >0 & !mi(stud)
label var stud2 "(1,0) studying, or not, as indicated by studies income support"

* unemployment
gen unemp = 1 if alosdag > 0
replace unemp = 0 if mi(unemp)
label var unemp "(1,0) if unemployed > 0 days, or not"

* incomes
label var forvers "Income (100 SEK) from employment or business or related support"
label var kapink "Income (100 SEK) from capital"

rename agi1ink ku1ink

keep lopnr educat_level agi1peorgnr seninvar barn0_17 examar hsdelt2 fodelt2 hieduc working occgrp stud2 unemp forvers kapink ku1ink

gen int year=2021
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2021.dta", replace
*******

*LISA2022

* contains lots of info for each individual about labour market etc
clear all
import delimited using "C:/Users/teacher/project/data/raw/lisa_2022.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace

* Change to lower case var names
rename *, lower

* fix SenInvAr
replace seninvar="." if seninvar=="0000"
gen xx = date(seninvar, "Y")
format xx %td
drop seninvar
gen seninvar = year(xx)
label var seninvar "Most recent year of immigration, otherwise missing value"
notes seninvar: Most obs missing, not having immigrated.
drop xx

* barn
destring barn0_3 barn4_6 barn7_10 barn11_15 barn16_17, replace
gen barn0_17 = barn0_3 + barn4_6 + barn7_10 + barn11_15 + barn16_17
replace barn0_17=0 if mi(barn0_17)
label var barn0_17 "No. of children, aged 0-17 yrs, if any, otherwise 0"
drop barn0_3 barn4_6 barn7_10 barn11_15 barn16_17

* fix examar
gen xx = date(examar, "Y")
format xx %td
drop examar
gen examar = year(xx)
label var examar "Most recent year of education credits, see var note"
notes examar: Completion year of educ, e.g., completing a course, not necessarily finishing the whole educ. Many missing values.
drop xx

* replace erroneous missing demarker * with true missing
replace sun2020niva_old = "." if sun2020niva_old=="*"
replace sun2020niva = "." if sun2020niva== "999"

* destring several vars
destring sun2020niva_old sun2020niva fodelt hsdelt syssstat19 agi1ink forvers kapink stud alosdag, replace

* educational level- new variable
gen educat_level = 1 if sun2020niva == 100 | sun2020niva == 106
replace educat_level = 2 if sun2020niva == 200 | sun2020niva == 206
replace educat_level = 3 if sun2020niva == 310 | sun2020niva == 312 | sun2020niva == 316
replace educat_level = 4 if sun2020niva == 320 | sun2020niva == 322 | sun2020niva == 326
replace educat_level = 5 if sun2020niva == 330 | sun2020niva == 332 | sun2020niva == 336
replace educat_level = 6 if sun2020niva == 410 | sun2020niva == 412 | sun2020niva == 416
replace educat_level = 7 if sun2020niva == 520 | sun2020niva == 522 | sun2020niva == 526
replace educat_level = 8 if sun2020niva == 530 | sun2020niva == 532 | sun2020niva == 536
replace educat_level = 9 if sun2020niva == 540 | sun2020niva == 546
replace educat_level = 10 if sun2020niva == 550 | sun2020niva == 556
replace educat_level = 11 if sun2020niva == 600 | sun2020niva == 640

label var educat_level "Educational level"
notes educat_level: 1: primary <9y, 2: primary 9 years, 3: upper sec < 2y, 4: upper sec 2y, 5: upper sec 3y, 6: post-sec <2y, 7: post-sec 2y, 8: university 3y, 9: university 4y, 10: university 5y or more, 11: postgraduate
***Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups****

* higher education current studies
rename hsdelt xx
recode xx (1 2 3 =1), gen(hsdelt2)
label var hsdelt2 "(1,0) registered hi-educ studies (not PhD stud), or not"
rename fodelt yy
recode yy (1 2 3 =1), gen(fodelt2)
label var fodelt2 "(1,0) registered PhD studies, or not"
*drop xx yy
gen hieduc = 1 if hsdelt==1 | fodelt==1
replace hieduc = 0 if mi(hieduc)
label var hieduc "(1,0) registered hi-educ studies (lower or PhD), or not"

* employment status
recode syssstat19 (5 6 = 0), gen(working)
label var working "(1,0) employed and/or entrepreneur, or not"
notes working: Employed or own business, category 1 of syssstat19, or not (categories 5 and 6).

* occupational group
replace agi1ssyk4 = "." if agi1ssyk4 == "****"
gen occgrp = substr(agi1ssyk4, 1, 1)
destring occgrp, replace
label var occgrp "1-digit occupational SSYK code at main employer, if employed"

* studying (getting study income, irrespective of level)
gen stud2 = 1 if stud >0 & !mi(stud)
label var stud2 "(1,0) studying, or not, as indicated by studies income support"

* unemployment
gen unemp = 1 if alosdag > 0
replace unemp = 0 if mi(unemp)
label var unemp "(1,0) if unemployed > 0 days, or not"

* incomes
label var forvers "Income (100 SEK) from employment or business or related support"
label var kapink "Income (100 SEK) from capital"

rename agi1ink ku1ink

keep lopnr educat_level agi1peorgnr seninvar barn0_17 examar hsdelt2 fodelt2 hieduc working occgrp stud2 unemp forvers kapink ku1ink

gen int year=2022
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2022.dta", replace
*******

*LISA2023

* contains lots of info for each individual about labour market etc
clear all
import delimited using "C:/Users/teacher/project/data/raw/lisa_2023.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* fix LopNr
rename LopNr lopnr, replace

* Change to lower case var names
rename *, lower

* fix SenInvAr
replace seninvar="." if seninvar=="0000"
gen xx = date(seninvar, "Y")
format xx %td
drop seninvar
gen seninvar = year(xx)
label var seninvar "Most recent year of immigration, otherwise missing value"
notes seninvar: Most obs missing, not having immigrated.
drop xx

* barn
destring barn0_3 barn4_6 barn7_10 barn11_15 barn16_17, replace
gen barn0_17 = barn0_3 + barn4_6 + barn7_10 + barn11_15 + barn16_17
replace barn0_17=0 if mi(barn0_17)
label var barn0_17 "No. of children, aged 0-17 yrs, if any, otherwise 0"
drop barn0_3 barn4_6 barn7_10 barn11_15 barn16_17

* fix examar
gen xx = date(examar, "Y")
format xx %td
drop examar
gen examar = year(xx)
label var examar "Most recent year of education credits, see var note"
notes examar: Completion year of educ, e.g., completing a course, not necessarily finishing the whole educ. Many missing values.
drop xx

* replace erroneous missing demarker * with true missing
replace sun2020niva_old = "." if sun2020niva_old=="*"
replace sun2020niva = "." if sun2020niva== "999"

* destring several vars
destring sun2020niva_old sun2020niva fodelt hsdelt syssstat19 agi1ink forvers kapink stud alosdag, replace

* educational level- new variable
gen educat_level = 1 if sun2020niva == 100 | sun2020niva == 106
replace educat_level = 2 if sun2020niva == 200 | sun2020niva == 206
replace educat_level = 3 if sun2020niva == 310 | sun2020niva == 312 | sun2020niva == 316
replace educat_level = 4 if sun2020niva == 320 | sun2020niva == 322 | sun2020niva == 326
replace educat_level = 5 if sun2020niva == 330 | sun2020niva == 332 | sun2020niva == 336
replace educat_level = 6 if sun2020niva == 410 | sun2020niva == 412 | sun2020niva == 416
replace educat_level = 7 if sun2020niva == 520 | sun2020niva == 522 | sun2020niva == 526
replace educat_level = 8 if sun2020niva == 530 | sun2020niva == 532 | sun2020niva == 536
replace educat_level = 9 if sun2020niva == 540 | sun2020niva == 546
replace educat_level = 10 if sun2020niva == 550 | sun2020niva == 556
replace educat_level = 11 if sun2020niva == 600 | sun2020niva == 640

label var educat_level "Educational level"
notes educat_level: 1: primary <9y, 2: primary 9 years, 3: upper sec < 2y, 4: upper sec 2y, 5: upper sec 3y, 6: post-sec <2y, 7: post-sec 2y, 8: university 3y, 9: university 4y, 10: university 5y or more, 11: postgraduate
***Cannot see any real differences between the values in sun2000niva and sun2020niva - use same groups****

* higher education current studies
rename hsdelt xx
recode xx (1 2 3 =1), gen(hsdelt2)
label var hsdelt2 "(1,0) registered hi-educ studies (not PhD stud), or not"
rename fodelt yy
recode yy (1 2 3 =1), gen(fodelt2)
label var fodelt2 "(1,0) registered PhD studies, or not"
*drop xx yy
gen hieduc = 1 if hsdelt==1 | fodelt==1
replace hieduc = 0 if mi(hieduc)
label var hieduc "(1,0) registered hi-educ studies (lower or PhD), or not"

* employment status
recode syssstat19 (5 6 = 0), gen(working)
label var working "(1,0) employed and/or entrepreneur, or not"
notes working: Employed or own business, category 1 of syssstat19, or not (categories 5 and 6).

* occupational group
replace agi1ssyk4 = "." if agi1ssyk4 == "****"
gen occgrp = substr(agi1ssyk4, 1, 1)
destring occgrp, replace
label var occgrp "1-digit occupational SSYK code at main employer, if employed"

* studying (getting study income, irrespective of level)
gen stud2 = 1 if stud >0 & !mi(stud)
label var stud2 "(1,0) studying, or not, as indicated by studies income support"

* unemployment
gen unemp = 1 if alosdag > 0
replace unemp = 0 if mi(unemp)
label var unemp "(1,0) if unemployed > 0 days, or not"

* incomes
label var forvers "Income (100 SEK) from employment or business or related support"
label var kapink "Income (100 SEK) from capital"

rename agi1ink ku1ink

keep lopnr educat_level agi1peorgnr seninvar barn0_17 examar hsdelt2 fodelt2 hieduc working occgrp stud2 unemp forvers kapink ku1ink

gen int year=2023
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2023.dta", replace
*******

* foretag_2019
* Contains info about firms that persons are employed in
clear all
import delimited using "C:/Users/teacher/project/data/raw/foretag_2019.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* Change to lower case var names
rename *, lower
* fix sni and the numbers
destring sni2007 medelantalanstallda nettoomsattning foradlingsvarde rorelseresultat summapersonalkostnader, replace
* we note that a few firms have "00000" as industry, which does not
*exist, we replace these with "." for missing values
replace sni2007=. if sni2007==00000
* fix neg values
rename summapersonalkostnader xx
gen summapersonalkostnader = -1*xx
drop xx
* labels etc
rename sni2007 industry
label var industry "5-digit industry of firm"
rename medelantalanstallda firmsize
label var firmsize "Workforce size."
rename nettoomsattning netsales
label var netsales "Net sales, in kSEK"
rename foradlingsvarde vadded
label var vadded "Value added of firm"
rename rorelseresultat profit
label var profit "Earnings before interest and taxes, in kSEK"
rename summapersonalkostnader labcosts
label var labcosts "Total costs for workforce (salaries etc + social fees), in kSEK"
gen int year=2019
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2019.dta", replace
*****

* foretag_2020
* Contains info about firms that persons are employed in
clear all
import delimited using "C:/Users/teacher/project/data/raw/foretag_2020.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* Change to lower case var names
rename *, lower
* fix sni and the numbers
destring sni2007 medelantalanstallda nettoomsattning foradlingsvarde rorelseresultat summapersonalkostnader, replace
* we note that a few firms have "00000" as industry, which does not
*exist, we replace these with "." for missing values
replace sni2007=. if sni2007==00000
* fix neg values
rename summapersonalkostnader xx
gen summapersonalkostnader = -1*xx
drop xx
* labels etc
rename sni2007 industry
label var industry "5-digit industry of firm"
rename medelantalanstallda firmsize
label var firmsize "Workforce size."
rename nettoomsattning netsales
label var netsales "Net sales, in kSEK"
rename foradlingsvarde vadded
label var vadded "Value added of firm"
rename rorelseresultat profit
label var profit "Earnings before interest and taxes, in kSEK"
rename summapersonalkostnader labcosts
label var labcosts "Total costs for workforce (salaries etc + social fees), in kSEK"
gen int year=2020
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2020.dta", replace
*****

* foretag_2021
* Contains info about firms that persons are employed in
clear all
import delimited using "C:/Users/teacher/project/data/raw/foretag_2021.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* Change to lower case var names
rename *, lower
* fix sni and the numbers
destring sni2007 medelantalanstallda nettoomsattning foradlingsvarde rorelseresultat summapersonalkostnader, replace
* we note that a few firms have "00000" as industry, which does not
*exist, we replace these with "." for missing values
replace sni2007=. if sni2007==00000
* fix neg values
rename summapersonalkostnader xx
gen summapersonalkostnader = -1*xx
drop xx
* labels etc
rename sni2007 industry
label var industry "5-digit industry of firm"
rename medelantalanstallda firmsize
label var firmsize "Workforce size."
rename nettoomsattning netsales
label var netsales "Net sales, in kSEK"
rename foradlingsvarde vadded
label var vadded "Value added of firm"
rename rorelseresultat profit
label var profit "Earnings before interest and taxes, in kSEK"
rename summapersonalkostnader labcosts
label var labcosts "Total costs for workforce (salaries etc + social fees), in kSEK"
gen int year=2021
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2021.dta", replace
*****

* foretag_2022
* Contains info about firms that persons are employed in
clear all
import delimited using "C:/Users/teacher/project/data/raw/foretag_2022.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* Change to lower case var names
rename *, lower
* fix sni and the numbers
destring sni2007 medelantalanstallda nettoomsattning foradlingsvarde rorelseresultat summapersonalkostnader, replace
* we note that a few firms have "00000" as industry, which does not
*exist, we replace these with "." for missing values
replace sni2007=. if sni2007==00000
* fix neg values
rename summapersonalkostnader xx
gen summapersonalkostnader = -1*xx
drop xx
* labels etc
rename sni2007 industry
label var industry "5-digit industry of firm"
rename medelantalanstallda firmsize
label var firmsize "Workforce size."
rename nettoomsattning netsales
label var netsales "Net sales, in kSEK"
rename foradlingsvarde vadded
label var vadded "Value added of firm"
rename rorelseresultat profit
label var profit "Earnings before interest and taxes, in kSEK"
rename summapersonalkostnader labcosts
label var labcosts "Total costs for workforce (salaries etc + social fees), in kSEK"
gen int year=2022
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2022.dta", replace
*****

* foretag_2023
* Contains info about firms that persons are employed in
clear all
import delimited using "C:/Users/teacher/project/data/raw/foretag_2023.csv", varnames(1) case(preserve) stringcols(_all) clear
des
* Change to lower case var names
rename *, lower
* fix sni and the numbers
destring sni2007 medelantalanstallda nettoomsattning foradlingsvarde rorelseresultat summapersonalkostnader, replace
* we note that a few firms have "00000" as industry, which does not
*exist, we replace these with "." for missing values
replace sni2007=. if sni2007==00000
* fix neg values
rename summapersonalkostnader xx
gen summapersonalkostnader = -1*xx
drop xx
* labels etc
rename sni2007 industry
label var industry "5-digit industry of firm"
rename medelantalanstallda firmsize
label var firmsize "Workforce size."
rename nettoomsattning netsales
label var netsales "Net sales, in kSEK"
rename foradlingsvarde vadded
label var vadded "Value added of firm"
rename rorelseresultat profit
label var profit "Earnings before interest and taxes, in kSEK"
rename summapersonalkostnader labcosts
label var labcosts "Total costs for workforce (salaries etc + social fees), in kSEK"
gen int year=2023
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2023.dta", replace
*****


*** agi_manad_2023
* Contains monthly pay per person and employer (employer declarations), 2023
clear all
import delimited using "C:/Users/teacher/project/data/raw/agi_manad_2023.csv", varnames(1) case(preserve) stringcols(_all) clear
des
rename *, lower
destring lon, replace
gen manad = real(substr(period, 5, 2))
label var manad "Month"
* yearly pay per person and employer
collapse (sum) lon, by(lopnr peorgnr)
* keep the main employer = the one that pays most
bysort lopnr (lon): keep if _n==1
rename peorgnr agi_peorgnr
rename lon agi_lon
label var agi_peorgnr "Main employer 2023, from monthly declarations"
label var agi_lon "Pay from main employer 2023, SEK"
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_agi_2023.dta", replace
*****


*** migrationer
*
clear all
import delimited using "C:/Users/teacher/project/data/raw/migrationer.csv", varnames(1) case(preserve) stringcols(_all) clear
des

* Change to lower case var names
rename LopNr, lower
rename *, lower

gen migyear = year(date(datum, "YMD"))
label var migyear "Year of immigration/emigration"
drop datum

gen oecd = 1 if inutvland == "NORGE" | inutvland == "DANMARK" | inutvland == "FINLAND" | inutvland == "ISLAND" | inutvland == "TYSKLAND" | inutvland == "FRANKRIKE" | inutvland == "STORBRITANNIEN" | inutvland == "USA" | inutvland == "KANADA" | inutvland == "POLEN" | inutvland == "SPANIEN" | inutvland == "ITALIEN" | inutvland == "NEDERLÄNDERNA" | inutvland == "JAPAN"
replace oecd=0 if mi(oecd) & inutvland!="OKÄNT"
label var oecd "(1,0) if migration is to/from an OECD country"
* some have inutvland == "OKÄNT", these become missing.

rename posttyp xx
encode xx, gen(posttyp)
codebook posttyp
label var posttyp "(1,2) for immigration, or emigration"
drop xx

gen utvoecd = 1 if oecd==1 & posttyp==2
gen invoecd = 1 if oecd==1 & posttyp==1
gen utvnonoecd = 1 if oecd==0 & posttyp==2
gen invnonoecd = 1 if oecd==0 & posttyp==1

replace utvoecd = 0 if mi(utvoecd)
replace invoecd = 0 if mi(invoecd)
replace utvnonoecd = 0 if mi(utvnonoecd)
replace invnonoecd = 0 if mi(invnonoecd)

sort lopnr migyear
collapse (rawsum) utvoecd invoecd utvnonoecd invnonoecd, by(lopnr migyear)

label var utvoecd "(1,0) for emigrating to OECD country"
label var invoecd "(1,0) for immigrating from OECD country"
label var utvnonoecd "(1,0) for emigrating to non-OECD country"
label var invnonoecd "(1,0) for immigrating from non-OECD country"

***In order to merge 1:1 we reshape wide migration/ year for migration***
sort lopnr

reshape wide invnonoecd invoecd utvnonoecd utvoecd, i(lopnr) j(migyear)

***Replace missing values for all new variables to 0, have not found a command for this*****
replace utvoecd2019 = 0 if missing(utvoecd2019)
replace utvoecd2020 = 0 if missing(utvoecd2020)
replace utvoecd2021 = 0 if missing(utvoecd2021)
replace utvoecd2022 = 0 if missing(utvoecd2022)
replace utvoecd2023 = 0 if missing(utvoecd2023)
replace utvoecd2024 = 0 if missing(utvoecd2024)
replace invoecd2019 = 0 if missing(invoecd2019)
replace invoecd2020 = 0 if missing(invoecd2020)
replace invoecd2021 = 0 if missing(invoecd2021)
replace invoecd2022 = 0 if missing(invoecd2022)
replace invoecd2023 = 0 if missing(invoecd2023)
replace invoecd2024 = 0 if missing(invoecd2024)
replace utvnonoecd2019 = 0 if missing(utvnonoecd2019)
replace utvnonoecd2020 = 0 if missing(utvnonoecd2020)
replace utvnonoecd2021 = 0 if missing(utvnonoecd2021)
replace utvnonoecd2022 = 0 if missing(utvnonoecd2022)
replace utvnonoecd2023 = 0 if missing(utvnonoecd2023)
replace utvnonoecd2024 = 0 if missing(utvnonoecd2024)
replace invnonoecd2019 = 0 if missing(invnonoecd2019)
replace invnonoecd2020 = 0 if missing(invnonoecd2020)
replace invnonoecd2021 = 0 if missing(invnonoecd2021)
replace invnonoecd2022 = 0 if missing(invnonoecd2022)
replace invnonoecd2024 = 0 if missing(invnonoecd2024)

duplicates drop

compress
codebook, compact23g
* Comment: info available for most individuals who migrated
sort lopnr
save "C:/Users/teacher/project/data/processed/flawed_stata/se_migrationer.dta", replace
******


****Information about activity spells, municipal activity register****
clear all
import delimited using "C:/Users/teacher/project/data/raw/insatser_kommun.csv", varnames(1) case(preserve) stringcols(_all) clear
rename *, lower
des
destring ar alder, replace

***Youth placement flag: codes F12, F15, F18 AND age under 25 years******
gen youth_kommun=1 if kod1=="F12" | kod2=="F12" | kod3=="F12" | kod4=="F12" | kod5=="F12" | kod6=="F12" | kod7=="F12" | kod8=="F12" | kod1=="F15" | kod2=="F15" | kod3=="F15" | kod4=="F15" | kod5=="F15" | kod6=="F15" | kod7=="F15" | kod8=="F15" | kod1=="F18" | kod2=="F18" | kod3=="F18" | kod4=="F18" | kod5=="F18" | kod6=="F18" | kod7=="F18" | kod8=="F18" & alder < 25
replace youth_kommun=0 if youth_kommun !=1
replace youth_kommun=0 if mi(youth_kommun)

*****Change to fewer categories********
gen catAB=1 if substr(hkod, 1, 1) == "A" | substr(kod1, 1, 1) == "A" | substr(kod2, 1, 1) == "A" | substr(kod3, 1, 1) == "A" | substr(kod3, 1, 1) == " A" | substr(kod4, 1, 1) == "A" | substr(kod5, 1, 1) == "A" | substr(kod6, 1, 1) == "A" | substr(kod7, 1, 1) == "A" | substr(kod8, 1, 1) == "A" | substr(hkod, 1, 1) == "B" | substr(kod1, 1, 1) == "B" | substr(kod2, 1, 1) == "B" | substr(kod3, 1, 1) == "B" | substr(kod4, 1, 1) == "B" | substr(kod5, 1, 1) == "B" | substr(kod6, 1, 1) == "B" | substr(kod7, 1, 1) == "B" | substr(kod8, 1, 1) == "B"

label var catAB "(1,0) job-search support"

gen catCD=1 if substr(hkod, 1, 1) == "C" | substr(kod1, 1, 1) == "C" | substr(kod2, 1, 1) == "C" | substr(kod3, 1, 1) == "C" | substr(kod4, 1, 1) == "C" | substr(kod5, 1, 1) == "C" | substr(kod6, 1, 1) == "C" | substr(kod7, 1, 1) == "C" | substr(kod8, 1, 1) == "C" | substr(hkod, 1, 1) == "D" | substr(kod1, 1, 1) == "D" | substr(kod2, 1, 1) == "D" | substr(kod3, 1, 1) == "D" | substr(kod4, 1, 1) == "D" | substr(kod5, 1, 1) == "D" | substr(kod6, 1, 1) == "D" | substr(kod7, 1, 1) == "D" | substr(kod8, 1, 1) == "D"

label var catCD "(1,0) training"

gen catE=1 if substr(hkod, 1, 1) == "E" | substr(kod1, 1, 1) == "E" | substr(kod2, 1, 1) == "E" | substr(kod3, 1, 1) == "E" | substr(kod4, 1, 1) == "E" | substr(kod5, 1, 1) == "E" | substr(kod6, 1, 1) == "E" | substr(kod7, 1, 1) == "E" | substr(kod8, 1, 1) == "E"
replace catE=0 if substr(hkod, 1, 3) == "E30" | substr(kod1, 1, 3) == "E30" | substr(kod2, 1, 3) == "E30" | substr(kod3, 1, 3) == "E30" | substr(kod4, 1, 3) == "E30" | substr(kod5, 1, 3) == "E30" | substr(kod6, 1, 3) == "E30" | substr(kod7, 1, 3) == "E30" | substr(kod8, 1, 3) == "E30"

label var catE "(1,0) employment subsidy, start-up subsidy E30 not included"

gen catF=1 if substr(hkod, 1, 1) == "F" | substr(kod1, 1, 1) == "F" | substr(kod2, 1, 1) == "F" | substr(kod3, 1, 1) == "F" | substr(kod4, 1, 1) == "F" | substr(kod5, 1, 1) == "F" | substr(kod6, 1, 1) == "F" | substr(kod7, 1, 1) == "F" | substr(kod8, 1, 1) == "F"

label var catF "(1,0) work placement"

gen catHL=1 if substr(hkod, 1, 1) == "H" | substr(kod1, 1, 1) == "H" | substr(kod2, 1, 1) == "H" | substr(kod3, 1, 1) == "H" | substr(kod4, 1, 1) == "H" | substr(kod5, 1, 1) == "H" | substr(kod6, 1, 1) == "H" | substr(kod7, 1, 1) == "H" | substr(kod8, 1, 1) == "H" | substr(hkod, 1, 1) == "L" | substr(kod1, 1, 1) == "L" | substr(kod2, 1, 1) == "L" | substr(kod3, 1, 1) == "L" | substr(kod4, 1, 1) == "L" | substr(kod5, 1, 1) == "L" | substr(kod6, 1, 1) == "L" | substr(kod7, 1, 1) == "L" | substr(kod8, 1, 1) == "L"

label var catHL "(1,0) matching services"

gen catREST=1 if substr(hkod, 1, 1) == "G" | substr(kod1, 1, 1) == "G" | substr(kod2, 1, 1) == "G" | substr(kod3, 1, 1) == "G" | substr(kod4, 1, 1) == "G" | substr(kod5, 1, 1) == "G" | substr(kod6, 1, 1) == "G" | substr(kod7, 1, 1) == "G" | substr(kod8, 1, 1) == "G" | substr(hkod, 1, 1) == "K" | substr(kod1, 1, 1) == "K" | substr(kod2, 1, 1) == "K" | substr(kod3, 1, 1) == "K" | substr(kod4, 1, 1) == "K" | substr(kod5, 1, 1) == "K" | substr(kod6, 1, 1) == "K" | substr(kod7, 1, 1) == "K" | substr(kod8, 1, 1) == "K" | substr(hkod, 1, 1) == "R" | substr(kod1, 1, 1) == "R" | substr(kod2, 1, 1) == "R" | substr(kod3, 1, 1) == "R" | substr(kod4, 1, 1) == "R" | substr(kod5, 1, 1) == "R" | substr(kod6, 1, 1) == "R" | substr(kod7, 1, 1) == "R" | substr(kod8, 1, 1) == "R" | substr(hkod, 1, 1) == "U" | substr(kod1, 1, 1) == "U" | substr(kod2, 1, 1) == "U" | substr(kod3, 1, 1) == "U" | substr(kod4, 1, 1) == "U" | substr(kod5, 1, 1) == "U" | substr(kod6, 1, 1) == "U" | substr(kod7, 1, 1) == "U" | substr(kod8, 1, 1) == "U" | substr(hkod, 1, 1) == "V" | substr(kod1, 1, 1) == "V" | substr(kod2, 1, 1) == "V" | substr(kod3, 1, 1) == "V" | substr(kod4, 1, 1) == "V" | substr(kod5, 1, 1) == "V" | substr(kod6, 1, 1) == "V" | substr(kod7, 1, 1) == "V" | substr(kod8, 1, 1) == "V" | substr(hkod, 1, 1) == "Y" | substr(kod1, 1, 1) == "Y" | substr(kod2, 1, 1) == "Y" | substr(kod3, 1, 1) == "Y" | substr(kod4, 1, 1) == "Y" | substr(kod5, 1, 1) == "Y" | substr(kod6, 1, 1) == "Y" | substr(kod7, 1, 1) == "Y" | substr(kod8, 1, 1) == "Y" | substr(hkod, 1, 1) == "Z" | substr(kod1, 1, 1) == "Z" | substr(kod2, 1, 1) == "Z" | substr(kod3, 1, 1) == "Z" | substr(kod4, 1, 1) == "Z" | substr(kod5, 1, 1) == "Z" | substr(kod6, 1, 1) == "Z" | substr(kod7, 1, 1) == "Z" | substr(kod8, 1, 1) == "Z"

label var catREST "(1,0) other and administrative codes"

****replace with 0 all that are not in the groups****

replace catAB=0 if catAB !=1

replace catCD=0 if catCD !=1

replace catE=0 if catE !=1

replace catF=0 if catF !=1

replace catHL=0 if catHL !=1

replace catREST=0 if catREST !=1

****Drop code variables****
drop hkod kod1 kod2 kod3 kod4 kod5 kod6 kod7 kod8 kod3

***Set cut off age 20 years. prior: activity before age 20, post: at 20 or older***
sort lopnr

gen int ncatAB_prior = 1 if catAB == 1 & alder<20
replace ncatAB_prior = 0 if mi(ncatAB_prior)
gen int ncatAB_post = 1 if catAB == 1 & alder>=20
replace ncatAB_post = 0 if mi(ncatAB_post)

gen int ncatCD_prior = 1 if catCD == 1 & alder<20
replace ncatCD_prior = 0 if mi(ncatCD_prior)
gen int ncatCD_post = 1 if catCD == 1 & alder>=20
replace ncatCD_post = 0 if mi(ncatCD_post)

gen int ncatE_prior = 1 if catE == 1 & alder<20
replace ncatE_prior = 0 if mi(ncatE_prior)
gen int ncatE_post = 1 if catE == 1 & alder>=20
replace ncatE_post = 0 if mi(ncatE_post)

gen int ncatF_prior = 1 if catF == 1 & alder<20
replace ncatF_prior = 0 if mi(ncatF_prior)
gen int ncatF_post = 1 if catF == 1 & alder>=20
replace ncatF_post = 0 if mi(ncatF_post)

gen int ncatHL_prior = 1 if catHL == 1 & alder<20
replace ncatHL_prior = 0 if mi(ncatHL_prior)
gen int ncatHL_post = 1 if catHL == 1 & alder>=20
replace ncatHL_post = 0 if mi(ncatHL_post)

gen int ncatREST_prior = 1 if catREST == 1 & alder<20
replace ncatREST_prior = 0 if mi(ncatREST_prior)
gen int ncatREST_post = 1 if catREST == 1 & alder>=20
replace ncatREST_post = 0 if mi(ncatREST_post)

bys lopnr: egen nncatAB_prior = max(ncatAB_prior)
bys lopnr: egen nncatAB_post = max(ncatAB_post)
bys lopnr: egen nncatCD_prior = max(ncatCD_prior)
bys lopnr: egen nncatCD_post = max(ncatCD_post)
bys lopnr: egen nncatE_prior = max(ncatE_prior)
bys lopnr: egen nncatE_post = max(ncatE_post)
bys lopnr: egen nncatF_prior = max(ncatF_prior)
bys lopnr: egen nncatF_post = max(ncatF_post)
bys lopnr: egen nncatHL_prior = max(ncatHL_prior)
bys lopnr: egen nncatHL_post = max(ncatHL_post)
bys lopnr: egen nncatREST_prior = max(ncatREST_prior)
bys lopnr: egen nncatREST_post = max(ncatREST_post)
bys lopnr: egen youth = max(youth_kommun)

label var nncatAB_prior "(1,0) job-search support, before 20y"
label var nncatAB_post "(1,0) job-search support, 20y or older"
drop catAB ncatAB_post ncatAB_prior

label var nncatCD_prior "(1,0) training, before 20y"
label var nncatCD_post "(1,0) training, 20y or older"
drop catCD ncatCD_post ncatCD_prior

label var nncatE_prior "(1,0) employment subsidy, start-up subsidy E30 not included, before 20y"
label var nncatE_post "(1,0) employment subsidy, start-up subsidy E30 not included, 20y or older"
drop catE ncatE_post ncatE_prior

label var nncatF_prior "(1,0) work placement, before 20y"
label var nncatF_post "(1,0) work placement, 20y or older"
drop catF ncatF_post ncatF_prior

label var nncatHL_prior "(1,0) matching services, before 20y"
label var nncatHL_post "(1,0) matching services, 20y or older"
drop catHL ncatHL_post ncatHL_prior

label var nncatREST_prior "(1,0) other and administrative codes, before 20y"
label var nncatREST_post "(1,0) other and administrative codes, 20y or older"
drop catREST ncatREST_post ncatREST_prior

drop youth_kommun

**In order to merge 1:1 drop the time variables, they are included in the dichotomous variables****
drop ar alder
duplicates drop
compress
codebook, compact

save "C:/Users/teacher/project/data/processed/flawed_stata/se_insatser_kommun.dta", replace


****Information about activity spells, state programme register****
clear all
import delimited using "C:/Users/teacher/project/data/raw/insatser_stat.csv", varnames(1) case(preserve) stringcols(_all) clear
rename *, lower
des
destring ar alder, replace

***Youth placement flag: codes F12, F15, F18 AND age under 25 years******
gen youth_stat=1 if kod1=="F12" | kod2=="F12" | kod3=="F12" | kod4=="F12" | kod5=="F12" | kod6=="F12" | kod7=="F12" | kod8=="F12" | kod9=="F12" | kod10=="F12" | kod1=="F15" | kod2=="F15" | kod3=="F15" | kod4=="F15" | kod5=="F15" | kod6=="F15" | kod7=="F15" | kod8=="F15" | kod9=="F15" | kod10=="F15" | kod1=="F18" | kod2=="F18" | kod3=="F18" | kod4=="F18" | kod5=="F18" | kod6=="F18" | kod7=="F18" | kod8=="F18" | kod9=="F18" | kod10=="F18" & alder < 25
replace youth_stat=0 if youth_stat !=1
replace youth_stat=0 if mi(youth_stat)

*****Change to fewer categories********
gen catAB=1 if substr(hkod, 1, 1) == "A" | substr(kod1, 1, 1) == "A" | substr(kod2, 1, 1) == "A" | substr(kod3, 1, 1) == "A" | substr(kod3, 1, 1) == " A" | substr(kod4, 1, 1) == "A" | substr(kod5, 1, 1) == "A" | substr(kod6, 1, 1) == "A" | substr(kod7, 1, 1) == " A" | substr(kod8, 1, 1) == "A" | substr(kod9, 1, 1) == "A" | substr(kod10, 1, 1) == "A" | substr(hkod, 1, 1) == "B" | substr(kod1, 1, 1) == "B" | substr(kod2, 1, 1) == "B" | substr(kod3, 1, 1) == "B" | substr(kod4, 1, 1) == "B" | substr(kod5, 1, 1) == "B" | substr(kod6, 1, 1) == "B" | substr(kod7, 1, 1) == "B" | substr(kod8, 1, 1) == "B" | substr(kod9, 1, 1) == "B" | substr(kod10, 1, 1) == "B"

label var catAB "(1,0) job-search support"

gen catCD=1 if substr(hkod, 1, 1) == "C" | substr(kod1, 1, 1) == "C" | substr(kod2, 1, 1) == "C" | substr(kod3, 1, 1) == "C" | substr(kod4, 1, 1) == "C" | substr(kod5, 1, 1) == "C" | substr(kod6, 1, 1) == "C" | substr(kod7, 1, 1) == "C" | substr(kod8, 1, 1) == "C" | substr(kod9, 1, 1) == "C" | substr(kod10, 1, 1) == "C" | substr(hkod, 1, 1) == "D" | substr(kod1, 1, 1) == "D" | substr(kod2, 1, 1) == "D" | substr(kod3, 1, 1) == "D" | substr(kod4, 1, 1) == "D" | substr(kod5, 1, 1) == "D" | substr(kod6, 1, 1) == "D" | substr(kod7, 1, 1) == "D" | substr(kod8, 1, 1) == "D" | substr(kod9, 1, 1) == "D" | substr(kod10, 1, 1) == "D"

label var catCD "(1,0) training"

gen catE=0 if substr(hkod, 1, 3) == "E30" | substr(kod1, 1, 3) == "E30" | substr(kod2, 1, 3) == "E30" | substr(kod3, 1, 3) == "E30" | substr(kod4, 1, 3) == "E30" | substr(kod5, 1, 3) == "E30" | substr(kod6, 1, 3) == "E30" | substr(kod7, 1, 3) == "E30" | substr(kod8, 1, 3) == "E30" | substr(kod9, 1, 3) == "E30" | substr(kod10, 1, 3) == "E30"
replace catE=1 if (substr(hkod, 1, 1) == "E" | substr(kod1, 1, 1) == "E" | substr(kod2, 1, 1) == "E" | substr(kod3, 1, 1) == "E" | substr(kod4, 1, 1) == "E" | substr(kod5, 1, 1) == "E" | substr(kod6, 1, 1) == "E" | substr(kod7, 1, 1) == "E" | substr(kod8, 1, 1) == "E" | substr(kod9, 1, 1) == "E" | substr(kod10, 1, 1) == "E") & ar>2016
***OBS!! before 2017 the codes are numeric (old code list), so letter E only from 2017. Important to remember!

label var catE "(1,0) employment subsidy, start-up subsidy E30 not included"

gen catF=1 if substr(hkod, 1, 1) == "F" | substr(kod1, 1, 1) == "F" | substr(kod2, 1, 1) == "F" | substr(kod3, 1, 1) == "F" | substr(kod4, 1, 1) == "F" | substr(kod5, 1, 1) == "F" | substr(kod6, 1, 1) == "F" | substr(kod7, 1, 1) == "F" | substr(kod8, 1, 1) == "F" | substr(kod9, 1, 1) == "F" | substr(kod10, 1, 1) == "F"

label var catF "(1,0) work placement"

gen catHL=1 if substr(hkod, 1, 1) == "H" | substr(kod1, 1, 1) == "H" | substr(kod2, 1, 1) == "H" | substr(kod3, 1, 1) == "H" | substr(kod4, 1, 1) == "H" | substr(kod5, 1, 1) == "H" | substr(kod6, 1, 1) == "H" | substr(kod7, 1, 1) == "H" | substr(kod8, 1, 1) == "H" | substr(kod9, 1, 1) == "H" | substr(kod10, 1, 1) == "H" | substr(hkod, 1, 1) == "L" | substr(kod1, 1, 1) == "L" | substr(kod2, 1, 1) == "L" | substr(kod3, 1, 1) == "L" | substr(kod4, 1, 1) == "L" | substr(kod5, 1, 1) == "L" | substr(kod6, 1, 1) == "L" | substr(kod7, 1, 1) == "L" | substr(kod8, 1, 1) == "L" | substr(kod9, 1, 1) == "L" | substr(kod10, 1, 1) == "L"

label var catHL "(1,0) matching services"

gen catREST=1 if substr(hkod, 1, 1) == "G" | substr(kod1, 1, 1) == "G" | substr(kod2, 1, 1) == "G" | substr(kod3, 1, 1) == "G" | substr(kod4, 1, 1) == "G" | substr(kod5, 1, 1) == "G" | substr(kod6, 1, 1) == "G" | substr(kod7, 1, 1) == "G" | substr(kod8, 1, 1) == "G" | substr(kod9, 1, 1) == "G" | substr(kod10, 1, 1) == "G" | substr(hkod, 1, 1) == "K" | substr(kod1, 1, 1) == "K" | substr(kod2, 1, 1) == "K" | substr(kod3, 1, 1) == "K" | substr(kod4, 1, 1) == "K" | substr(kod5, 1, 1) == "K" | substr(kod6, 1, 1) == "K" | substr(kod7, 1, 1) == "K" | substr(kod8, 1, 1) == "K" | substr(kod9, 1, 1) == "K" | substr(kod10, 1, 1) == "K" | substr(hkod, 1, 1) == "R" | substr(kod1, 1, 1) == "R" | substr(kod2, 1, 1) == "R" | substr(kod3, 1, 1) == "R" | substr(kod4, 1, 1) == "R" | substr(kod5, 1, 1) == "R" | substr(kod6, 1, 1) == "R" | substr(kod7, 1, 1) == "R" | substr(kod8, 1, 1) == "R" | substr(kod9, 1, 1) == "R" | substr(kod10, 1, 1) == "R" | substr(hkod, 1, 1) == "U" | substr(kod1, 1, 1) == "U" | substr(kod2, 1, 1) == "U" | substr(kod3, 1, 1) == "U" | substr(kod4, 1, 1) == "U" | substr(kod5, 1, 1) == "U" | substr(kod6, 1, 1) == "U" | substr(kod7, 1, 1) == "U" | substr(kod8, 1, 1) == "U" | substr(kod9, 1, 1) == "U" | substr(kod10, 1, 1) == "U" | substr(hkod, 1, 1) == "V" | substr(kod1, 1, 1) == "V" | substr(kod2, 1, 1) == "V" | substr(kod3, 1, 1) == "V" | substr(kod4, 1, 1) == "V" | substr(kod5, 1, 1) == "V" | substr(kod6, 1, 1) == "V" | substr(kod7, 1, 1) == "V" | substr(kod8, 1, 1) == "V" | substr(kod9, 1, 1) == "V" | substr(kod10, 1, 1) == "V" | substr(hkod, 1, 1) == "Y" | substr(kod1, 1, 1) == "Y" | substr(kod2, 1, 1) == "Y" | substr(kod3, 1, 1) == "Y" | substr(kod4, 1, 1) == "Y" | substr(kod5, 1, 1) == "Y" | substr(kod6, 1, 1) == "Y" | substr(kod7, 1, 1) == "Y" | substr(kod8, 1, 1) == "Y" | substr(kod9, 1, 1) == "Y" | substr(kod10, 1, 1) == "Y" | substr(hkod, 1, 1) == "Z" | substr(kod1, 1, 1) == "Z" | substr(kod2, 1, 1) == "Z" | substr(kod3, 1, 1) == "Z" | substr(kod4, 1, 1) == "Z" | substr(kod5, 1, 1) == "Z" | substr(kod6, 1, 1) == "Z" | substr(kod7, 1, 1) == "Z" | substr(kod8, 1, 1) == "Z" | substr(kod9, 1, 1) == "Z" | substr(kod10, 1, 1) == "Z"

label var catREST "(1,0) other and administrative codes"

*****Keep only codes starting with digits, i.e. the old numeric code list*****

gen hk= hkod if substr(hkod, 1, 1) == "0" | substr(hkod, 1, 1) == "1" | substr(hkod, 1, 1) == "2" | substr(hkod, 1, 1) == "3" | substr(hkod, 1, 1) == "4" | substr(hkod, 1, 1) == "5" | substr(hkod, 1, 1) == "6" | substr(hkod, 1, 1) == "7" | substr(hkod, 1, 1) == "8" | substr(hkod, 1, 1) == "9"
gen ko1= kod1 if substr(kod1, 1, 1) == "0" | substr(kod1, 1, 1) == "1" | substr(kod1, 1, 1) == "2" | substr(kod1, 1, 1) == "3" | substr(kod1, 1, 1) == "4" | substr(kod1, 1, 1) == "5" | substr(kod1, 1, 1) == "6" | substr(kod1, 1, 1) == "7" | substr(kod1, 1, 1) == "8" | substr(kod1, 1, 1) == "9"
gen ko2= kod2 if substr(kod2, 1, 1) == "0" | substr(kod2, 1, 1) == "1" | substr(kod2, 1, 1) == "2" | substr(kod2, 1, 1) == "3" | substr(kod2, 1, 1) == "4" | substr(kod2, 1, 1) == "5" | substr(kod2, 1, 1) == "6" | substr(kod2, 1, 1) == "7" | substr(kod2, 1, 1) == "8" | substr(kod2, 1, 1) == "9"
gen ko3= kod3 if substr(kod3, 1, 1) == "0" | substr(kod3, 1, 1) == "1" | substr(kod3, 1, 1) == "2" | substr(kod3, 1, 1) == "3" | substr(kod3, 1, 1) == "4" | substr(kod3, 1, 1) == "5" | substr(kod3, 1, 1) == "6" | substr(kod3, 1, 1) == "7" | substr(kod3, 1, 1) == "8" | substr(kod3, 1, 1) == "9"
gen ko4= kod4 if substr(kod4, 1, 1) == "0" | substr(kod4, 1, 1) == "1" | substr(kod4, 1, 1) == "2" | substr(kod4, 1, 1) == "3" | substr(kod4, 1, 1) == "4" | substr(kod4, 1, 1) == "5" | substr(kod4, 1, 1) == "6" | substr(kod4, 1, 1) == "7" | substr(kod4, 1, 1) == "8" | substr(kod4, 1, 1) == "9"
gen ko5= kod5 if substr(kod5, 1, 1) == "0" | substr(kod5, 1, 1) == "1" | substr(kod5, 1, 1) == "2" | substr(kod5, 1, 1) == "3" | substr(kod5, 1, 1) == "4" | substr(kod5, 1, 1) == "5" | substr(kod5, 1, 1) == "6" | substr(kod5, 1, 1) == "7" | substr(kod5, 1, 1) == "8" | substr(kod5, 1, 1) == "9"
gen ko6= kod6 if substr(kod6, 1, 1) == "0" | substr(kod6, 1, 1) == "1" | substr(kod6, 1, 1) == "2" | substr(kod6, 1, 1) == "3" | substr(kod6, 1, 1) == "4" | substr(kod6, 1, 1) == "5" | substr(kod6, 1, 1) == "6" | substr(kod6, 1, 1) == "7" | substr(kod6, 1, 1) == "8" | substr(kod6, 1, 1) == "9"
gen ko7= kod7 if substr(kod7, 1, 1) == "0" | substr(kod7, 1, 1) == "1" | substr(kod7, 1, 1) == "2" | substr(kod7, 1, 1) == "3" | substr(kod7, 1, 1) == "4" | substr(kod7, 1, 1) == "5" | substr(kod7, 1, 1) == "6" | substr(kod7, 1, 1) == "7" | substr(kod7, 1, 1) == "8" | substr(kod7, 1, 1) == "9"
gen ko8= kod8 if substr(kod8, 1, 1) == "0" | substr(kod8, 1, 1) == "1" | substr(kod8, 1, 1) == "2" | substr(kod8, 1, 1) == "3" | substr(kod8, 1, 1) == "4" | substr(kod8, 1, 1) == "5" | substr(kod8, 1, 1) == "6" | substr(kod8, 1, 1) == "7" | substr(kod8, 1, 1) == "8" | substr(kod8, 1, 1) == "9"
gen ko9= kod9 if substr(kod9, 1, 1) == "0" | substr(kod9, 1, 1) == "1" | substr(kod9, 1, 1) == "2" | substr(kod9, 1, 1) == "3" | substr(kod9, 1, 1) == "4" | substr(kod9, 1, 1) == "5" | substr(kod9, 1, 1) == "6" | substr(kod9, 1, 1) == "7" | substr(kod9, 1, 1) == "8" | substr(kod9, 1, 1) == "9"
gen ko10= kod10 if substr(kod10, 1, 1) == "0" | substr(kod10, 1, 1) == "1" | substr(kod10, 1, 1) == "2" | substr(kod10, 1, 1) == "3" | substr(kod10, 1, 1) == "4" | substr(kod10, 1, 1) == "5" | substr(kod10, 1, 1) == "6" | substr(kod10, 1, 1) == "7" | substr(kod10, 1, 1) == "8" | substr(kod10, 1, 1) == "9"

***Keep only the 3 first digits and change to numeric****

gen hvd=substr(hk, 1, 3)
gen k1=substr(ko1, 1, 3)
gen k2=substr(ko2, 1, 3)
gen k3=substr(ko3, 1, 3)
gen k4=substr(ko4, 1, 3)
gen k5=substr(ko5, 1, 3)
gen k6=substr(ko6, 1, 3)
gen k7=substr(ko7, 1, 3)
gen k8=substr(ko8, 1, 3)
gen k9=substr(ko9, 1, 3)
gen k10=substr(ko10, 1, 3)

drop hk ko1 ko2 ko3 ko4 ko5 ko6 ko7 ko8 ko9 ko10

destring hvd k1 k2 k3 k4 k5 k6 k7 k8 k9 k10, replace

***Change missing to 0, otherwise missing codes end up in the groups below****

foreach var of varlist hvd k1 k2 k3 k4 k5 k6 k7 k8 k9 k10 { 
	replace `var' = 0 if mi(`var') 
	}

replace catAB=1 if hvd<200 & hvd !=0 | k1<200 & k1 !=0 | k2<200 & k2 !=0 | k3<200 & k3 !=0 | k4<200 & k4 !=0 | k5<200 & k5 !=0 | k6<200 & k6 !=0 | k7<200 & k7 !=0 | k8<200 & k8 !=0 | k9<200 & k9 !=0 | k10<200 & k10 !=0
replace catAB=0 if catAB !=1

replace catCD=1 if hvd>=200 & hvd<=299 | k1>=200 & k1<=299 | k2>=200 & k2<=299 | k3>=200 & k3<=299 | k4>=200 & k4<=299 | k5>=200 & k5<=299 | k6>=200 & k6>=299 | k7>=200 & k7<=299 | k8>=200 & k8<=299 | k9>=200 & k9<=299 | k10>=200 & k10<=299
replace catCD=0 if catCD !=1

replace catE=1 if hvd>299 & hvd<400 | k1>299 & k1<400 | k2>299 & k2<400 | k3>299 & k3<400 | k4>299 & k4<400 | k5>299 & k5<400 | k6>299 & k6>400 | k7>299 & k7<400 | k8>299 & k8<400 | k9>299 & k9<400 | k10>299 & k10<400
replace catE=0 if catE !=1

replace catF=1 if hvd>399 & hvd<500 | k1>399 & k1<500 | k2>399 & k2<500 | k3>399 & k3<500 | k4>399 & k4<500 | k5>399 & k5<500 | k6>399 & k6>500 | k7>399 & k7<500 | k8>399 & k8<500 | k9>399 & k9<500 | k10>399 & k10<500
replace catF=0 if catF !=1

replace catHL=1 if hvd>499 & hvd<650 | k1>499 & k1<650 | k2>499 & k2<650 | k3>499 & k3<650 | k4>499 & k4<650 | k5>499 & k5<650 | k6>499 & k6>650 | k7>499 & k7<650 | k8>499 & k8<650 | k9>499 & k9<650 | k10>499 & k10<650
replace catHL=0 if catHL !=1

replace catREST=1 if hvd>649 & hvd<1000 | k1>649 & k1<1000 | k2>649 & k2<1000 | k3>549 & k3<1000 | k4>649 & k4<1000 | k5>649 & k5<1000 | k6>649 & k6>1000 | k7>649 & k7<1000 | k8>649 & k8<1000 | k9>649 & k9<1000 | k10>649 & k10<1000
replace catREST=0 if catREST !=1

drop hkod kod1 kod2 kod3 kod4 kod5 kod6 kod7 kod8 kod9 kod10 kod3 hvd k1 k2 k3 k4 k5 k6 k7 k8 k9 k10

***Set cut off age 20 years. prior: activity before age 20, post: at 20 or older***
sort lopnr

gen int ncatAB_prior = 1 if catAB == 1 & alder<20
replace ncatAB_prior = 0 if mi(ncatAB_prior)
gen int ncatAB_post = 1 if catAB == 1 & alder>=20
replace ncatAB_post = 0 if mi(ncatAB_post)

gen int ncatCD_prior = 1 if catCD == 1 & alder<20
replace ncatCD_prior = 0 if mi(ncatCD_prior)
gen int ncatCD_post = 1 if catCD == 1 & alder>=20
replace ncatCD_post = 0 if mi(ncatCD_post)

gen int ncatE_prior = 1 if catE == 1 & alder<20
replace ncatE_prior = 0 if mi(ncatE_prior)
gen int ncatE_post = 1 if catE == 1 & alder>=20
replace ncatE_post = 0 if mi(ncatE_post)

gen int ncatF_prior = 1 if catF == 1 & alder<20
replace ncatF_prior = 0 if mi(ncatF_prior)
gen int ncatF_post = 1 if catF == 1 & alder>=20
replace ncatF_post = 0 if mi(ncatF_post)

gen int ncatHL_prior = 1 if catHL == 1 & alder<20
replace ncatHL_prior = 0 if mi(ncatHL_prior)
gen int ncatHL_post = 1 if catHL == 1 & alder>=20
replace ncatHL_post = 0 if mi(ncatHL_post)

gen int ncatREST_prior = 1 if catREST == 1 & alder<20
replace ncatREST_prior = 0 if mi(ncatREST_prior)
gen int ncatREST_post = 1 if catREST == 1 & alder>=20
replace ncatREST_post = 0 if mi(ncatREST_post)

bys lopnr: egen SnncatAB_prior = max(ncatAB_prior)
bys lopnr: egen SnncatAB_post = max(ncatAB_post)
bys lopnr: egen SnncatCD_prior = max(ncatCD_prior)
bys lopnr: egen SnncatCD_post = max(ncatCD_post)
bys lopnr: egen SnncatE_prior = max(ncatE_prior)
bys lopnr: egen SnncatE_post = max(ncatE_post)
bys lopnr: egen SnncatF_prior = max(ncatF_prior)
bys lopnr: egen SnncatF_post = max(ncatF_post)
bys lopnr: egen SnncatHL_prior = max(ncatHL_prior)
bys lopnr: egen SnncatHL_post = max(ncatHL_post)
bys lopnr: egen SnncatREST_prior = max(ncatREST_prior)
bys lopnr: egen SnncatREST_post = max(ncatREST_post)
bys lopnr: egen Syouth = max(youth_stat)

label var SnncatAB_prior "(1,0) job-search support, before 20y"
label var SnncatAB_post "(1,0) job-search support, 20y or older"
drop catAB ncatAB_post ncatAB_prior

label var SnncatCD_prior "(1,0) training, before 20y"
label var SnncatCD_post "(1,0) training, 20y or older"
drop catCD ncatCD_post ncatCD_prior

label var SnncatE_prior "(1,0) employment subsidy, start-up subsidy E30 not included, before 20y"
label var SnncatE_post "(1,0) employment subsidy, start-up subsidy E30 not included, 20y or older"
drop catE ncatE_post ncatE_prior

label var SnncatF_prior "(1,0) work placement, before 20y"
label var SnncatF_post "(1,0) work placement, 20y or older"
drop catF ncatF_post ncatF_prior

label var SnncatHL_prior "(1,0) matching services, before 20y"
label var SnncatHL_post "(1,0) matching services, 20y or older"
drop catHL ncatHL_post ncatHL_prior

label var SnncatREST_prior "(1,0) other and administrative codes, before 20y"
label var SnncatREST_post "(1,0) other and administrative codes, 20y or older"
drop catREST ncatREST_post ncatREST_prior

drop youth_stat

**In order to merge 1:1 drop the time variables, they are included in the dichotomous variables****
drop ar alder
duplicates drop
compress
codebook, compact

save "C:/Users/teacher/project/data/processed/flawed_stata/se_insatser_stat.dta", replace


*****Appending- all files from LISA 2019-2023***
clear all
use "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2019.dta"

append using "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2020.dta" "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2021.dta" "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2022.dta" "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa2023.dta"

***variables ku1peorgnr agi1peorgnr are the same employer id, for 2019-2020 and 2021-2023, respectively****

***Change educational level to 3-levels variable instead of 11-levels variable*****
rename educat_level x, replace
gen educat_level = 1 if x == 1 | x == 2
replace educat_level = 2 if x == 3 | x == 4 | x == 5
replace educat_level = 3 if x == 6 | x == 7 | x == 8 | x == 9 | x == 10 | x == 11
label var educat_level " Educational level, 3-levels, 1: primary, 2: upper secondary, 3: post-secondary"
rename x educ_level_eleven, replace

compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_lisa_appended.dta", replace

***Append all files from foretag 2019-2023*****
clear all
use "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2019.dta"
append using "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2020.dta" "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2021.dta" "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_2022.dta"
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_foretag_appended.dta", replace

*** agi_manad_2023, firm level (added in April)
* wage bill and share on permanent contracts per firm 2023, for the firm panel
clear all
import delimited using "C:/Users/teacher/project/data/raw/agi_manad_2023.csv", varnames(1) case(preserve) stringcols(_all) clear
des
rename *, lower
destring lon anstform, replace
* a declaration can be sent twice, keep one row per person, employer and month
duplicates drop lopnr peorgnr period, force
* anstform: 1 permanent, 2 fixed-term, 3 hourly. Some are empty, set to 0 so no rows are lost
replace anstform = 0 if missing(anstform)
gen permanent = anstform < 2
label var permanent "(1,0) permanent contract"
collapse (sum) wagebill=lon (mean) permshare=permanent, by(peorgnr)
label var wagebill "Wage bill 2023, SEK"
label var permshare "Share of person-months on a permanent contract"
compress
codebook, compact
save "C:/Users/teacher/project/data/processed/flawed_stata/se_agi_foretag_2023.dta", replace


/* Other datasets to work with:
(merge everything on lopnr and year, the grades, the spells, agi against lisa 2023)



clear all
log close


