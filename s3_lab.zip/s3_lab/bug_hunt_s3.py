"""After Session 3: the full bug hunt on clean_registers_flawed.py, in numbers.

In the lab you found the bugs that show without reading the code (level 1).
Here you go deeper: the documentation (codebook errata), the logic (level 2)
and the rules of the data and the language (level 3). The exercise page on the
course site explains each task; this script is where you put the answers.

Work one cell at a time and USE THE NAMES GIVEN in each TODO: the self-check
looks for them. It computes nothing for you: every answer is a number or a
name you find in YOUR pair's data, so a pasted answer from another pair or a
chatbot does not fit. Check whenever you like:
    uv run check_exercise_s3.py
Before you start: clean_registers_flawed.py must have run on your pair's data
(lab Step 8), so that data/processed/flawed_py/ in your pair folder is full.
Runtime: under 2 seconds. The last cell prints "Exercise done".
"""
# %% ---- CHANGE HERE (only this line) ---------------------------------
# After a change: run this cell again, then the step that uses it.
PAIR = "00"                    # the same pair number as in the lab
# ---------------------------------------------------------------------

# %% Step 0: your pair's folders (done for you)
from pathlib import Path
try:
    import pandas as pd
except ModuleNotFoundError:            # VS Code is using another Python, not the course's .venv
    raise SystemExit("pandas not found: VS Code is not using the course Python. Put this lab "
                     "folder inside na446a-starter, open na446a-starter in VS Code (File > Open "
                     "Folder), choose Python: Select Interpreter > .venv, then Restart. "
                     "See 'Common problems in class' on the Setup page.")

try:                                   # the folder this file sits in
    _HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    _HERE = Path.cwd()
ROOT = _HERE
HOME = ROOT / f"pair_{PAIR}"
if not (HOME / "data").exists():             # unzipped one folder too deep?
    HOME = HOME / f"pair_{PAIR}"
RAW = HOME / "data" / "raw"                  # the raw files, as delivered
FLAWED = HOME / "data" / "processed" / "flawed_py"   # what the flawed script wrote

# %% Task 1 (easy): it runs
# TODO: n_outputs = the number of .csv files in FLAWED (hint: FLAWED.glob("*.csv"))
n_outputs = ...

# %% Task 2 (easy): the level-1 bugs, in numbers
# TODO: ak9_rows_per_person = rows of se_ak9.csv divided by its number of persons
ak9_rows_per_person = ...
# TODO: lisa_years = the sorted list of year labels in se_lisa_appended.csv
lisa_years = ...
# TODO: firm_years = the sorted list of years in se_foretag_appended.csv
firm_years = ...
# TODO: n_mig_missing = the number of persons in se_migrationer.csv with ANY missing value
n_mig_missing = ...

# %% Task 3 (medium): trust but verify the codebook (three errata)
# Run checklist items 1 (names), 6 (categories) and 8 (IDs and keys) on the RAW files.
# TODO: kon_codes = the sorted list of the codes Kon actually takes in persons.csv
kon_codes = ...
# TODO: employer_col_2021 = the name of the employer-id column in lisa_2021.csv
employer_col_2021 = ...
# TODO: missing_id_file = the name of the raw file in which LopNr is missing,
#   and n_missing_id = in how many rows
missing_id_file = ...
n_missing_id = ...
# Your errata (codebook says / data say / how you found it):
# 1: ...
# 2: ...
# 3: ...

# %% Task 4 (medium, level 2): the youth flag in the municipal register
# The comment in the flawed script says: codes F12, F15, F18 AND age under 25.
# TODO: n_youth_flawed = the number of persons with youth == 1 in se_insatser_kommun.csv
n_youth_flawed = ...
# TODO: n_youth_right = the number of persons in insatser_kommun.csv with F12, F15
#   or F18 in any code column (HKod, Kod1 ... Kod8) in a spell at age (Alder) under 25
n_youth_right = ...
# Your answer: which line is wrong, and why does it give more persons? ...

# %% Task 5 (hard, level 3): education after the new code vintage
# TODO: share_educ_missing_2021_flawed = the share of rows in se_lisa2021.csv whose
#   educat_level is missing (a number between 0 and 1)
share_educ_missing_2021_flawed = ...
# TODO: share_educ_missing_2021_right = the share of rows in lisa_2021.csv whose
#   education is really unknown, by the codebook's sentinel codes
share_educ_missing_2021_right = ...
# Your answer: what changed in 2021, and how would you classify so that the
#   next vintage cannot break it? ...

# %% Task 6 (hard, level 3): the firm block "added in April" (the last block)
agi = pd.read_csv(RAW / "agi_manad_2023.csv", dtype=str)
# TODO: n_dropped_by_dedup = the number of rows its
#   drop_duplicates(subset=["lopnr", "peorgnr", "period"]) removes from your data
n_dropped_by_dedup = ...
# TODO: n_exact_copies = how many of the raw rows are exact copies of another row
n_exact_copies = ...
# TODO: permshare_right = the share of person-months on a permanent contract
#   (AnstForm 1), counting only months where the form is reported, after
#   removing the exact copies
permshare_right = ...
# Your answer: which rows does the flawed dedup remove that it should keep, and
#   what does fillna(0) on AnstForm do to the firms' shares? ...

# %% If you finish early (optional)
# Write the smallest set of assert statements that would have stopped the
# flawed script at its first wrong number in each register. Say where each goes.

# %%
print("Exercise done")
