# Session 3 lab: combining data

Synthetic Swedish-style register files (yearly person files, persons, firms, monthly pay), to
combine into one person-year panel: append, check keys, merge, reshape, lag. Then a bug race on
a cleaning script written the way real register code often is.

**All data are synthetic**: made by a random-number generator, with fake ids. No real person or
firm is in them. Even so, the course rule holds: never paste real personal or register data into
a chatbot.

## Get started (5 minutes)

1. Unzip `s3_lab.zip` and put the folder `s3_lab` inside your course folder (`na446a-starter`).
2. **Your pair's data.** Pick a free number 1–30 on the whiteboard, cross it out, and download
   `pair_NN.zip` from the Data page. Unzip it *into* `s3_lab`, so you get a folder `pair_NN` next
   to `s3_lab.py`. Late or absent? Use pair 00: it is already in the folder.
   Offline? `uv run make_synthetic_registers.py --pair NN` makes the same data (about 1 s).
3. Open `na446a-starter` in VS Code (File → Open Folder; the course folder, not `s3_lab` on its
   own), open `s3_lab/s3_lab.py`, set `PAIR = "NN"` in the CHANGE HERE block, and run the cells
   one by one.

## Files

| File | What it is |
|---|---|
| `s3_lab.py` | the lab: fill in the TODOs, cell by cell |
| `check_s3.py` | self-check for the lab; computes the right answers for *your* pair |
| `pair_00/` (and your `pair_NN/`) | the data: `CODEBOOK.md`, `data/raw/` (as delivered, read only), `data/processed/`, `output/` |
| `clean_registers_flawed.py` | the cleaning script for the bug race (Stata users: `clean_registers_flawed.do`) |
| `bug_hunt_s3.py`, `check_exercise_s3.py`, `answers_s3.json` | the exercise after class (text on the course site, Sessions page) |
| `make_synthetic_registers.py` | makes any pair's data again; the self-checks use it |

## Scripts: how long they take and what they print last

The terminal in VS Code starts in `na446a-starter`: type `cd s3_lab` once before these commands,
or open the file and press ▷ (Run Python File) instead.

| Command (from `s3_lab`) | Runtime | Last line printed |
|---|---|---|
| `uv run s3_lab.py` (all cells, when done) | about 1 s | `Lab done` |
| `uv run check_s3.py` (or `check_s3.py NN`) | about 2 s | `N of 8 steps right.` |
| `clean_registers_flawed.py` (after the path fix) | about 2 s | nothing: it writes 20 files to `pair_NN/data/processed/flawed_py/` and a log to `pair_NN/output/` |
| `uv run bug_hunt_s3.py` | under 2 s | `Exercise done` |
| `uv run check_exercise_s3.py` | under 3 s | `N of 6 tasks right.` |
| `uv run make_synthetic_registers.py --pair NN` | about 1 s | `End of generation: 17 files, seed ...` |

## If something goes wrong

- `FileNotFoundError ... pair_NN/data/raw/GENERATED.txt`: the pair folder is not next to
  `s3_lab.py`, or `PAIR` does not match its number. Unzip `pair_NN.zip` inside `s3_lab`.
- The self-check warns that your files are not your pair's data: `PAIR` and the folder you
  unzipped do not match.
- `clean_registers_flawed.py` stops with `FileNotFoundError` or `OSError`: a path was not
  replaced, or it has backslashes. Use forward slashes and end with a slash:
  `C:/Users/you/.../s3_lab/pair_07/`.
- `ModuleNotFoundError: pandas` or `pyarrow`: VS Code uses the wrong interpreter. Select the one
  in your course folder's `.venv` (Cmd/Ctrl+Shift+P → *Python: Select Interpreter*).

## Two rules for this lab

- Mark any line that came from an AI with the comment `# AI:`, and make sure you can explain it.
- The data are synthetic for a reason: real register data never go into a chatbot.
