"""Further topic F2: binary outcomes (who survived the Titanic?).

Optional self-study for NA446A Part II (not examined). Recycled from the HT25
course script (its optional section on limited dependent variables) and
moved to a dataset students already know from Session 2.

What it does, one cell per slide of F2.pdf:
  1. Loads titanic.csv (the Session 2 data, in data/), makes a 0/1 variable
     for women and keeps the passengers whose age is known.
  2. Linear probability model (OLS on a 0/1 outcome), robust standard errors.
  3. Logit: coefficients in log-odds.
  4. Odds ratios.
  5. Average marginal effects, by hand and with get_margeff.
  6. Perfect separation: a category in which nobody survived.
  7. The fix: merge the rare categories.

Run from this folder:   uv run f2_script.py     (or: python f2_script.py)
Needs only the course environment (pandas, numpy, statsmodels): nothing to add.
Runtime: about 2 seconds.
Last printed line (30 Sep 2026): "f2_script.py done: LPM, logit, AME, separation"
"""
# ---- CHANGE HERE (only these lines) ------------------------------------
RHS = "female + C(pclass) + age"      # right-hand side of both models
CAP = 3                               # step 7: 3 or more siblings/spouses = one group
# ------------------------------------------------------------------------

# %% Setup
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

try:                                   # the folder this file sits in
    HERE = Path(__file__).resolve().parent
except NameError:                      # some cell runners do not set __file__
    HERE = Path.cwd()

# %% Step 1: the data, and one stated choice about missing age
t = pd.read_csv(HERE / "data" / "titanic.csv")
t.columns = t.columns.str.lower()                 # PassengerId -> passengerid
t["female"] = (t["sex"] == "female").astype(int)  # 0/1, as Stata's i.female
d = t.dropna(subset=["age"])                      # 177 ages missing: dropped
print("=== Step 1: the data ===")
print(len(t), len(d), round(d["survived"].mean(), 3))

# %% Step 2: the linear probability model (Stata: reg ..., vce(robust))
# OLS on a 0/1 outcome: a coefficient is a change in the probability. The
# error variance depends on the regressors by construction, so use robust
# standard errors (HC1 = Stata's vce(robust)).
lpm = smf.ols(f"survived ~ {RHS}", data=d).fit(
    cov_type="HC1")
p_hat = lpm.fittedvalues
print("\n=== Step 2: linear probability model ===")
print(lpm.params.loc[["female", "C(pclass)[T.3]"]].round(3).to_string())
print((p_hat < 0).sum(), (p_hat > 1).sum())       # predictions below 0, above 1

# %% Steps 3 and 4: logit, in log-odds and as odds ratios
# (Stata: logit survived i.female i.pclass age, then logit, or)
# exp(coefficient): the factor by which the ODDS p/(1-p) change.
logit = smf.logit(f"survived ~ {RHS}", data=d).fit(
    disp=False)                                   # disp=False: no optimiser report
odds_ratio = np.exp(logit.params)
print("\n=== Steps 3 and 4: logit ===")
print(pd.DataFrame({"coef": logit.params.round(3), "se": logit.bse.round(3),
                    "odds ratio": odds_ratio.round(2)}))

# %% Step 5a: average marginal effect of being a woman, by hand
# Predict every passenger's survival probability as a woman and as a man,
# keeping everything else as it is; the AME is the average difference.
p_woman = logit.predict(d.assign(female=1))
p_man = logit.predict(d.assign(female=0))
ame_female = (p_woman - p_man).mean()
# The same for a category: everyone in third class, then everyone in first
ame_third = (logit.predict(d.assign(pclass=3)) - logit.predict(d.assign(pclass=1))).mean()
print("\n=== Step 5a: AME by hand ===")
print("female:", round(ame_female, 3), "| third vs first class:", round(ame_third, 3))

# %% Step 5b: the same with get_margeff (Stata: margins, dydx(*))
# dummy=True asks for the discrete change 0 -> 1 of a 0/1 column. Without it,
# statsmodels uses the derivative, the wrong question for a dummy. For a
# category with three or more levels, get_margeff switches ONE dummy column
# to 1 without switching the others off (for T.3, a second-class passenger
# becomes "second and third class at once"), so do categories by hand (5a).
ame = logit.get_margeff(at="overall", dummy=True)
ame_slope = logit.get_margeff(at="overall")
names = lpm.params.index[1:]                    # the columns, without the intercept
print("\n=== Step 5b: AME with get_margeff ===")
print(pd.DataFrame({"LPM": lpm.params[names],
                    "get_margeff": ame.margeff,
                    "by hand": [np.nan, ame_third, ame_female, np.nan]},
                   index=names).loc[["female", "C(pclass)[T.3]"]].round(3))
print("female without dummy=True:", round(ame_slope.margeff[2], 3))

# %% Check: what does an odds ratio of 12.5 mean?
rates = d.groupby("female")["survived"].mean()
print("\n=== Check: survival rates ===")
print("men", round(rates[0], 3), "| women", round(rates[1], 3),
      "| ratio", round(rates[1] / rates[0], 1),
      "| odds ratio", round((rates[1] / (1 - rates[1])) / (rates[0] / (1 - rates[0])), 1))

# %% Step 6: perfect separation
# Look before you estimate: a category where everyone has the same outcome.
print("\n=== Step 6: perfect separation ===")
print(pd.crosstab(t["sibsp"], t["survived"]).T)
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    sep = smf.logit("survived ~ female + C(sibsp)", data=t).fit(disp=False)
print("warning:", str(caught[-1].message).split(".")[0] if caught else "none")
print(pd.DataFrame({"coef": sep.params, "se": sep.bse})
      .loc[["C(sibsp)[T.5]"]].round(1))

# %% Step 7: the fix, merge the rare categories
t["sibsp_cap"] = t["sibsp"].clip(upper=CAP)       # 3, 4, 5, 8 -> 3
fixed = smf.logit("survived ~ female + C(sibsp_cap)",
                  data=t).fit(disp=False)
print("\n=== Step 7: rare categories merged ===")
print("converged:", fixed.mle_retvals["converged"])
print(pd.DataFrame({"coef": fixed.params, "se": fixed.bse})
      .loc[[f"C(sibsp_cap)[T.{CAP}]"]].round(2))

print("\nf2_script.py done: LPM, logit, AME, separation")
