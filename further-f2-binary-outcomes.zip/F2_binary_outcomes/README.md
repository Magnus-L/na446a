# F2 Binary outcomes: who survived the Titanic?

Optional self-study for NA446A Part II. Not examined.

**What:** a linear probability model and a logit on a 0/1 outcome; the logit read three ways (log-odds, odds ratios, average marginal effects); two traps in `get_margeff`; perfect separation, how to spot it and how to fix it. Data: Session 2's `titanic.csv` (891 passengers), copied into `data/`.

**Prerequisites:** Session 2 (the Titanic intake) and Session 4 (a regression with `smf.ols`).

**Time:** about 60–75 minutes.

## Extra packages

None. Everything uses the course environment (pandas, numpy, statsmodels). Tested with statsmodels 0.15.0, pandas 3.0.6, Python 3.12.

## Files

| File | What |
|---|---|
| `F2.pdf` (source `F2.tex`) | 11 slides: goals, six terms, seven steps with real output, one concept check, readings |
| `f2_script.py` | Reproduces every number on the slides. CHANGE HERE block at the top (the right-hand side; where to cap the rare category) |
| `f2_stata.do`, `f2_stata.log` | The Stata equivalents, run in StataNow 19.5 (`reg ..., vce(robust)`, `logit`, `logit, or`, `margins, dydx(*)`) |
| `data/titanic.csv` | The course copy of the Titanic data |
| `build/f2_output.txt` | The script's printout of 30 Sep 2026, for comparison |

## Run

```bash
uv run further/F2_binary_outcomes/f2_script.py
```

Runtime about 2 seconds. Last printed line: `f2_script.py done: LPM, logit, AME, separation`.

## Two findings worth knowing

- `get_margeff()` without `dummy=True` gives the slope for a 0/1 variable (0.367 for women), not the change from 0 to 1 (0.474).
- For a category with three or more levels, `get_margeff(dummy=True)` switches one dummy column on without switching the others off: third against first class comes out at −0.409, where Stata's `margins` and the three lines by hand give −0.424. The slides teach the by-hand route.

## What changed since HT25

The material comes from the HT25 script's optional section on limited dependent variables (`intro446a.py`, lines 1443–1531), which used a "high wage" dummy made from the wage panel. It now uses data students have already cleaned, adds robust standard errors for the LPM, computes marginal effects by hand, and shows perfect separation on a real empty cell rather than by describing it. The conditional logit (`xtlogit, fe`) is mentioned but not taught.

Build the slides: `python3 ../scripts/check_deck.py F2.tex` (zero overfull boxes on 30 Sep 2026).
