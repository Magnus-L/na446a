* F2 Binary outcomes: the Stata equivalents quoted on the slides.
* Data: data/titanic.csv (the course copy). Run from this folder: do f2_stata.do
* Checked in StataNow 19.5 on 30 Sep 2026 (log: f2_stata.log).
version 19
import delimited using "data/titanic.csv", clear case(lower)
gen female = sex == "female"
reg survived i.female i.pclass age, vce(robust)      // LPM, HC1
logit survived i.female i.pclass age                 // log-odds
logit, or                                            // odds ratios
margins, dydx(*)                                     // AME, discrete change for i.
logit survived i.female i.sibsp                      // perfect separation
gen sibsp_cap = min(sibsp, 3)
logit survived i.female i.sibsp_cap                  // the fix
